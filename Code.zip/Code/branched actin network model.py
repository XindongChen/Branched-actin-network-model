﻿#!/user/bin/python
#-*-coding:UTF-8-*-
#!/user/bin/python
#-*-coding:UTF-8-*-

from numpy import*
import random
import numpy

from abaqus import*
from abaqusConstants import*
from caeModules import*
Mdb()

from part import*
from material import*
from section import*
from assembly import*
from step import*
from interaction import*
from load import*
from mesh import*
from optimization import*
from job import*
from sketch import*
from visualization import*
from connectorBehavior import*
import xlwt
xls = xlwt.Workbook()
sheet = xls.add_sheet('Outputsdata',cell_overwrite_ok=True)
excel_savepath='R:\Google Drive\Models\Outputsdata-36vs100-35-100p-d1'
savepath='R:/Abaqus Results/080/3g-d4'



num_motherfilaments = 36  
num_squre_per_edge = 6
mean_filamentlength = 280
larp = 10
arp_generate_section = 100
l_densityarp1 = 100
l_densityarp2 = 100
l_densityarp3 = 100
l_densityarp4 = 100 
l_densityarp5 = 200 
l_densityarp6 = 200 
l_densityarp7 = 200
l_densityarp8 = 200 
l_densityarp9 = 200 
xy_angle = 35 
xy_angle_std_deviation = 15  
reduced_xyangle =75
xy_arpangle = 90
z_arpangle = 35
space_fis = 36 
space_ais = 31
crosslinkers_possibility = 1 
myModel = mdb.Model(name = 'bafn-1')
mySketch = myModel.ConstrainedSketch(name = 'Sketch-1', sheetSize = 200.0)
myPart = myModel.Part(dimensionality = THREE_D, name = 'filaments', type = DEFORMABLE_BODY)
volumefraction = 0
volumefraction_low = 0.035
volumefraction_high = 0.037
while volumefraction<volumefraction_low or volumefraction>volumefraction_high:
	xmostart1 = []  
	ymostart1 = []  
	num_squares = num_squre_per_edge**2
	num_mo_per_square = int(num_motherfilaments/num_squares)
	num_mo_per_edge = int(num_squre_per_edge*num_mo_per_square)
	l_square = 1000/num_squre_per_edge
	for i in range(num_squre_per_edge): # in vertical y direction
		for j in range(num_squre_per_edge): # in transverse x direction
			for k in range(num_mo_per_square):
				xrandomdata1 = random.uniform(j*l_square,(j+1)*l_square)
				xmostart1.append(xrandomdata1)
	for i in range(num_squre_per_edge): # in vertical y direction
		for j in range(num_mo_per_edge):
			yrandomdata1 = random.uniform(i*l_square,(i+1)*l_square)
			ymostart1.append(yrandomdata1)
	len(xmostart1)
	len(ymostart1)
	print xmostart1
	print ymostart1
	zmostartsample1 = []
	for i in range(1000):
		zstartrandomdata1 = random.gauss(100,50)
		if  0 < zstartrandomdata1 < 200:
			zmostartsample1.append(zstartrandomdata1)
	zmostart1 = random.sample(zmostartsample1, len(xmostart1)) 
	print zmostart1
	lenmo1 = [] 
	for i in range(len(xmostart1)):
		lenrandomdata1 = random.gauss(mean_filamentlength,50)
		lenmo1.append(lenrandomdata1)
	zmoend1 = []
	zmoangles = []
	for i in range(len(xmostart1)):
		zmoangle = random.gauss(0,20)
		zendrandomdata1 = zmostart1[i] + lenmo1[i]*(math.sin(math.radians(zmoangle)))
		while zendrandomdata1<0 or 200<zendrandomdata1:
			zmoangle = random.gauss(0,20)
			zendrandomdata1 = zmostart1[i] + lenmo1[i]*(math.sin(math.radians(zmoangle)))
		else:
			zmoend1.append(zendrandomdata1)
			zmoangles.append(zmoangle)
	zhabs1 = [] 
	for i in range(len(xmostart1)):
		zhdifference1= abs((zmoend1 [i]) - (zmostart1 [i]))
		zhabs1.append(zhdifference1)
	orimosampleplus1 = []  
	for i in range (10000):
		orientationrandomdataplus1= random.gauss(math.radians(xy_angle),math.radians(xy_angle_std_deviation)) 
		if math.radians(180) >= orientationrandomdataplus1 >= 0 :
			orimosampleplus1.append(orientationrandomdataplus1)
	orimosampleminus1 = []  
	for i in range (10000):
		orientationrandomdataminus1= random.gauss(math.radians(-xy_angle),math.radians(xy_angle_std_deviation)) 
		if  math.radians(-180) <= orientationrandomdataminus1 <= 0:
			orimosampleminus1.append(orientationrandomdataminus1)
	orimosample1 = orimosampleplus1 + orimosampleminus1
	random.shuffle(orimosample1)
	orimo1 = random.sample(orimosample1, len(xmostart1))  
	print orimo1
	zanglesabs1 = [] 
	for i in range(len(xmostart1)):
		zangleabs1 = math.asin((zhabs1 [i])/(lenmo1 [i]))   
		zanglesabs1.append(zangleabs1)
	lenmoinxy1 = []   
	for i in range(len(xmostart1)):
		lenprojectedinxy1 = ((lenmo1 [i])*(cos(zanglesabs1 [i])))
		lenmoinxy1.append(lenprojectedinxy1)
	xmoend1 = [] 
	ymoend1 = [] 
	for i in range(len(xmostart1)):
		xendpoint1 = ((xmostart1 [i]) - (lenmoinxy1 [i])*sin(orimo1 [i]))
		xmoend1.append(xendpoint1)
		yendpoint1 = ((ymostart1 [i]) + (lenmoinxy1 [i])*cos(orimo1 [i]))
		ymoend1.append(yendpoint1)
	xvectorlineset1 = []      
	yvectorlineset1 = []     
	zvectorlineset1 = []      
	for i in range(len(xmostart1)):
		xvectorline1 = (xmoend1 [i] - xmostart1 [i])
		xvectorlineset1.append(xvectorline1)
		yvectorline1 = (ymoend1 [i] - ymostart1 [i])
		yvectorlineset1.append(yvectorline1)
		zvectorline1 = (zmoend1 [i] - zmostart1 [i])
		zvectorlineset1.append(zvectorline1)
	arpnumeveset1 = []   
	for i in range(len(xmostart1)):
		arpnumeve1 = int(round((lenmo1[i])/l_densityarp1)) 
		arpnumeveset1.append(arpnumeve1)
	xarpstarts1 = []  
	yarpstarts1 = [] 
	zarpstarts1 = []  
	xarpstartslineset1 = []  
	yarpstartslineset1 = [] 
	zarpstartslineset1 = [] 
	xarpstartseveset1 = []  
	yarpstartseveset1 = []
	zarpstartseveset1 = []
	for i in range(len(arpnumeveset1)):
		for j in range (arpnumeveset1 [i]):
			if arpnumeveset1 [i]>0:
				arp_k = arp_generate_section/lenmo1[i]
				lower_limit = ((j+1.0)/arpnumeveset1[i]) - arp_k 
				upper_limit = (j+1.0)/arpnumeveset1[i]
				t = random.uniform(lower_limit, upper_limit)
				xarpstarteve1 = t*(xvectorlineset1 [i])+(xmostart1 [i])
				yarpstarteve1 = t*(yvectorlineset1 [i])+(ymostart1 [i])
				zarpstarteve1 = t*(zvectorlineset1 [i])+(zmostart1 [i])
				xarpstartseveset1.append(xarpstarteve1)
				yarpstartseveset1.append(yarpstarteve1)
				zarpstartseveset1.append(zarpstarteve1)
		xarpstartslineset1.append(xarpstartseveset1)
		xarpstarts1 = xarpstarts1 + xarpstartseveset1
		xarpstartseveset1 =[]
		yarpstartslineset1.append(yarpstartseveset1)
		yarpstarts1 = yarpstarts1 + yarpstartseveset1
		yarpstartseveset1 =[]
		zarpstartslineset1.append(zarpstartseveset1)
		zarpstarts1 = zarpstarts1 + zarpstartseveset1
		zarpstartseveset1 =[]
	zangles1 = []
	for i in range(len(xmostart1)):
		zangle1 = math.asin((zmoend1[i]-zmostart1[i])/lenmo1[i])
		zangles1.append(zangle1)
	thetaz_arpminset1 = []
	thetaz_arpmaxset1 = []
	for i in range(len(zarpstartslineset1)):
		thetaz_arpmin1 = (zangles1[i] - math.radians(70))
		thetaz_arpmax1 = (zangles1[i] + math.radians(70))
		thetaz_arpminset1.append(thetaz_arpmin1)
		thetaz_arpmaxset1.append(thetaz_arpmax1)
	zarpendseveset1 = []    
	zarpendslineset1 = []  
	deltaz_arpeveset1 = [] 
	deltaz_arplineset1 = []
	zarpends1 = []          
	deltaz_arps1 = []      
	xarpendseveset1 = []    
	xarpendslineset1 = []   
	xarpends1 = []         
	yarpendseveset1 = []  
	yarpendslineset1 = []   
	yarpends1 = []        
	for i in range(len(zarpstartslineset1)):
		deltaz_arpminset1 = larp*(math.sin(thetaz_arpminset1[i]))
		deltaz_arpmaxset1 = larp*(math.sin(thetaz_arpmaxset1[i]))
		for j in range(len(zarpstartslineset1[i])):
			z_arpendmineve1 = (zarpstartslineset1[i][j]) + deltaz_arpminset1
			z_arpendmaxeve1 = (zarpstartslineset1[i][j]) + deltaz_arpmaxset1 
			z_arpendeve1 = random.uniform(z_arpendmineve1, z_arpendmaxeve1)
			deltaz_arpeve1 = abs(z_arpendeve1-zarpstartslineset1[i][j])
			deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
			circle_num=0
			while deltaz_arpeve1 > deltaz_arpstandard and circle_num <10000:
				z_arpendeve1 = random.uniform(z_arpendmineve1, z_arpendmaxeve1)
				deltaz_arpeve1 = abs(z_arpendeve1-zarpstartslineset1[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num+=1
			a_parameter = ((xmoend1[i] - xmostart1[i])**2) + ((ymoend1[i] - ymostart1[i])**2)
			b_parameter = (-2)*(lenmo1[i]*larp*math.cos(math.radians(70)) - ((zmoend1[i] - zmostart1[i])*(z_arpendeve1 - zarpstartslineset1[i][j])))*(xmoend1[i] - xmostart1[i])
			c_parameter = ((lenmo1[i]*larp*math.cos(math.radians(70)) - ((zmoend1[i] - zmostart1[i])*(z_arpendeve1 - zarpstartslineset1[i][j])))**2) - (((larp)**2)-((z_arpendeve1 - zarpstartslineset1[i][j])**2))*((ymoend1[i] - ymostart1[i])**2)
			x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset1[i][j]
			x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset1[i][j]
			x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
			x_arpendeve1 = random.choice(x_arpendsmall_big)
			a =lenmo1[i]*larp*math.cos(math.radians(70))
			b = x_arpendeve1 - (xarpstartslineset1[i][j])
			c = xmoend1[i] - xmostart1[i]
			d = z_arpendeve1 - zarpstartslineset1[i][j]
			e = zmoend1[i] - zmostart1[i]
			g = ymoend1[i] - ymostart1[i]
			f = (a - b*c - d*e)/g
			h = abs(b/f) # tan(delta_x/delta_y)求arp与前进方向的角度
			count = 0
			while f < 0 or math.tan(xy_arpangle*pi/180)< h and count < 10000:   
				z_arpendeve1 = random.uniform(z_arpendmineve1, z_arpendmaxeve1) 
				deltaz_arpeve1 = abs(z_arpendeve1-zarpstartslineset1[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num=0
				while deltaz_arpeve1 > deltaz_arpstandard and circle_num <10000:
					z_arpendeve1 = random.uniform(z_arpendmineve1, z_arpendmaxeve1) 
					deltaz_arpeve1 = abs(z_arpendeve1-zarpstartslineset1[i][j])
					deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
					circle_num+=1
				a_parameter = ((xmoend1[i] - xmostart1[i])**2) + ((ymoend1[i] - ymostart1[i])**2)
				b_parameter = (-2)*(lenmo1[i]*larp*math.cos(math.radians(70)) - ((zmoend1[i] - zmostart1[i])*(z_arpendeve1 - zarpstartslineset1[i][j])))*(xmoend1[i] - xmostart1[i])
				c_parameter = ((lenmo1[i]*larp*math.cos(math.radians(70)) - ((zmoend1[i] - zmostart1[i])*(z_arpendeve1 - zarpstartslineset1[i][j])))**2) - (((larp)**2)-((z_arpendeve1 - zarpstartslineset1[i][j])**2))*((ymoend1[i] - ymostart1[i])**2)
				x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset1[i][j]
				x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset1[i][j]
				x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
				x_arpendeve1 = random.choice(x_arpendsmall_big)
				a =lenmo1[i]*larp*math.cos(math.radians(70))
				b = x_arpendeve1 - (xarpstartslineset1[i][j])
				c = xmoend1[i] - xmostart1[i]
				d = z_arpendeve1 - zarpstartslineset1[i][j]
				g = ymoend1[i] - ymostart1[i]
				f = (a - b*c - d*e)/g
				h = abs(b/f)
				count+=1
			zarpendseveset1.append(z_arpendeve1)
			deltaz_arpeve1 = z_arpendeve1 - (zarpstartslineset1[i][j])
			deltaz_arpeveset1.append(deltaz_arpeve1)
			xarpendseveset1.append(x_arpendeve1)
			y_arpendeve1 = ((lenmo1[i]*larp*math.cos(math.radians(70)) - ((zmoend1[i] - zmostart1[i])*(deltaz_arpeve1)))-(xmoend1[i] - xmostart1[i])*(x_arpendeve1-xarpstartslineset1[i][j]))/(ymoend1[i] - ymostart1[i])+yarpstartslineset1[i][j]
			yarpendseveset1.append(y_arpendeve1)
		zarpendslineset1.append(zarpendseveset1)
		deltaz_arplineset1.append(deltaz_arpeveset1)
		zarpends1 = zarpends1 + zarpendseveset1
		deltaz_arps1 = deltaz_arps1 + deltaz_arpeveset1
		zarpendseveset1 = []
		deltaz_arpeveset1 = []
		xarpendslineset1.append(xarpendseveset1)
		xarpends1 = xarpends1 + xarpendseveset1
		xarpendseveset1 = []
		yarpendslineset1.append(yarpendseveset1)
		yarpends1 = yarpends1 + yarpendseveset1
		yarpendseveset1 = []
	del_arps1 = []
	for i in range(len(zarpends1)):
		if zarpends1[i] >= 200 or zarpends1[i] <= 0: 
			del_arp1 = i
			del_arps1.append(del_arp1)
	del_arps1.reverse() 
	for i in del_arps1:
		del xarpstarts1[i] 
		del yarpstarts1[i]
		del zarpstarts1[i]
		del xarpends1[i]
		del yarpends1[i]
		del zarpends1[i]
		del deltaz_arps1[i]
	del_arps1_80_90degree = [] 
	for i in range(len(zarpends1)):
		delta_x = xarpends1[i]- xarpstarts1[i]
		delta_y = yarpends1[i]- yarpstarts1[i]
		length_xy = (delta_x**2 + delta_y**2)**0.5
		sin_xy = delta_x/length_xy
		abs_sin_xy = abs(sin_xy)
		limit_value = math.sin(math.radians(reduced_xyangle))
		if abs_sin_xy > limit_value:
			del_arp1_80_90degree = i
			del_arps1_80_90degree.append(del_arp1_80_90degree)
	numb_del_arps1_80_90degree = int(2*len(del_arps1_80_90degree)/3) 
	del_2third_arps1_80_90degree = random.sample(del_arps1_80_90degree, numb_del_arps1_80_90degree)
	del_2third_arps1_80_90degree.sort()
	del_2third_arps1_80_90degree.reverse()
	for i in del_2third_arps1_80_90degree:
		del xarpstarts1[i] 
		del yarpstarts1[i]
		del zarpstarts1[i]
		del xarpends1[i]
		del yarpends1[i]
		del zarpends1[i]
		del deltaz_arps1[i]	
	lendaus1 = [] 
	for i in range(len(xarpends1)):
		lendau1 = random.gauss(mean_filamentlength,50)
		lendaus1.append(lendau1)
	lenratios_dau1_arp1 = []
	for i in range(len(lendaus1)):
		lenratio_dau1_arp = (lendaus1[i])/(larp)
		deltaz_dau1 = (deltaz_arps1[i])*(lenratio_dau1_arp)
		z_dau1 = deltaz_dau1 + (zarpends1[i])
		if z_dau1 > 200:
			z_dau1 = 200
			lenratio_dau1_arp = (z_dau1 - zarpends1[i])/(deltaz_arps1[i])
			lenratios_dau1_arp1.append(lenratio_dau1_arp)
		elif z_dau1 < 0:
			z_dau1 = 0
			lenratio_dau1_arp = (z_dau1 - zarpends1[i])/(deltaz_arps1[i])
			lenratios_dau1_arp1.append(lenratio_dau1_arp)
		else:
			lenratios_dau1_arp1.append(lenratio_dau1_arp)
	x_dauends1 = [] 
	y_dauends1 = []
	z_dauends1 = [] 
	for i in range(len(lenratios_dau1_arp1)):
		z_dauend1 = (lenratios_dau1_arp1[i])*(deltaz_arps1[i]) + (zarpends1[i])
		x_dauend1 = (lenratios_dau1_arp1[i])*(xarpends1[i] - xarpstarts1[i]) + (xarpends1[i])
		y_dauend1 = (lenratios_dau1_arp1[i])*(yarpends1[i] - yarpstarts1[i]) + (yarpends1[i])
		x_dauends1.append(x_dauend1)
		y_dauends1.append(y_dauend1)
		z_dauends1.append(z_dauend1)
	x_daustarts1 = xarpends1[:] 
	y_daustarts1 = yarpends1[:] 
	z_daustarts1 = zarpends1[:]
	xvector_dauset1 = []     
	yvector_dauset1 = []     
	zvector_dauset1 = []     
	for i in range(len(x_daustarts1)):
		xvector_dau1 = (x_dauends1 [i] - x_daustarts1 [i])
		xvector_dauset1.append(xvector_dau1)
		yvector_dau1 = (y_dauends1 [i] - y_daustarts1[i])
		yvector_dauset1.append(yvector_dau1)
		zvector_dau1 = (z_dauends1 [i] - z_daustarts1[i])
		zvector_dauset1.append(zvector_dau1)
	len_dauset1 = []
	for i in range(len(xvector_dauset1)):
		len_dau1 = (xvector_dauset1[i]**2 + yvector_dauset1[i]**2 + zvector_dauset1[i]**2)**0.5
		len_dauset1.append(len_dau1)
	del_daus1 = []
	for i in range(len(len_dauset1)):
		if len_dauset1[i]<100:
			del_dau=i
			del_daus1.append(del_dau)
	del_daus1.reverse()	
	for i in del_daus1: # to delete the filaments, whoes length are under 100, and the corresponding arps
		del len_dauset1[i]
		del x_daustarts1[i]
		del y_daustarts1[i]
		del z_daustarts1[i]
		del x_dauends1[i]
		del y_dauends1[i]
		del z_dauends1[i]
		del xarpstarts1[i] 
		del yarpstarts1[i]
		del zarpstarts1[i]
		del xarpends1[i]
		del yarpends1[i]
		del zarpends1[i]
		del xvector_dauset1[i]
		del yvector_dauset1[i]
		del zvector_dauset1[i]
	arpnumeveset2 = []    
	for i in range(len(x_daustarts1)):
		arpnumeve2 = int(round((len_dauset1[i])/l_densityarp2))  
		arpnumeveset2.append(arpnumeve2)
	xarpstarts2 = [] 
	yarpstarts2 = []  
	zarpstarts2 = [] 
	xarpstartslineset2 = [] 
	yarpstartslineset2 = [] 
	zarpstartslineset2 = [] 
	xarpstartseveset2 = []   
	yarpstartseveset2 = []  
	zarpstartseveset2 = []  
	for i in range(len(arpnumeveset2)):
		for j in range (arpnumeveset2[i]):
			if arpnumeveset2[i]>0:
				arp_k = arp_generate_section/len_dauset1[i]
				lower_limit = (j+1.0)/arpnumeveset2[i] - arp_k
				upper_limit = (j+1.0)/arpnumeveset2[i]
				t = random.uniform(lower_limit, upper_limit)
				xarpstarteve2 = t*(xvector_dauset1 [i])+(x_daustarts1 [i])
				yarpstarteve2 = t*(yvector_dauset1 [i])+(y_daustarts1 [i])
				zarpstarteve2 = t*(zvector_dauset1 [i])+(z_daustarts1 [i])
				xarpstartseveset2.append(xarpstarteve2)
				yarpstartseveset2.append(yarpstarteve2)
				zarpstartseveset2.append(zarpstarteve2)
		xarpstartslineset2.append(xarpstartseveset2)
		xarpstarts2 = xarpstarts2 + xarpstartseveset2
		xarpstartseveset2 =[]
		yarpstartslineset2.append(yarpstartseveset2)
		yarpstarts2 = yarpstarts2 + yarpstartseveset2
		yarpstartseveset2 =[]
		zarpstartslineset2.append(zarpstartseveset2)
		zarpstarts2 = zarpstarts2 + zarpstartseveset2
		zarpstartseveset2 =[]
	zangles2 = []
	for i in range(len(x_daustarts1)):
		zangle2 = math.asin(zvector_dauset1[i]/len_dauset1[i])
		zangles2.append(zangle2)
	thetaz_arpminset2 = []
	thetaz_arpmaxset2 = []
	for i in range(len(zarpstartslineset2)):
		thetaz_arpmin2 = (zangles2[i] - math.radians(70))
		thetaz_arpmax2 = (zangles2[i] + math.radians(70))
		thetaz_arpminset2.append(thetaz_arpmin2)
		thetaz_arpmaxset2.append(thetaz_arpmax2)
	larp = 10
	zarpendseveset2 = []    
	zarpendslineset2 = []  
	deltaz_arpeveset2 = []  
	deltaz_arplineset2 = [] 
	zarpends2 = []          
	deltaz_arps2 = []      
	xarpendseveset2 = []   
	xarpendslineset2 = []  
	xarpends2 = []         
	yarpendseveset2 = []  
	yarpendslineset2 = []  
	yarpends2 = [] 
	for i in range(len(zarpstartslineset2)):
		deltaz_arpminset2 = larp*(math.sin(thetaz_arpminset2[i]))
		deltaz_arpmaxset2 = larp*(math.sin(thetaz_arpmaxset2[i]))
		for j in range(len(zarpstartslineset2[i])):
			z_arpendmineve2 = (zarpstartslineset2[i][j]) + deltaz_arpminset2 
			z_arpendmaxeve2 = (zarpstartslineset2[i][j]) + deltaz_arpmaxset2 
			z_arpendeve2 = random.uniform(z_arpendmineve2, z_arpendmaxeve2)
			deltaz_arpeve2 = abs(z_arpendeve2-zarpstartslineset2[i][j])
			deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
			circle_num=0
			while deltaz_arpeve2 > deltaz_arpstandard and circle_num <10000:
				z_arpendeve2 = random.uniform(z_arpendmineve2, z_arpendmaxeve2) 
				deltaz_arpeve2 = abs(z_arpendeve2-zarpstartslineset2[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num+=1
			a_parameter = ((xvector_dauset1[i])**2) + ((yvector_dauset1[i])**2)
			b_parameter = (-2)*(len_dauset1[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset1[i])*(z_arpendeve2 - zarpstartslineset2[i][j])))*(xvector_dauset1[i])
			c_parameter = ((len_dauset1[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset1[i])*(z_arpendeve2 - zarpstartslineset2[i][j])))**2) - (((larp)**2)-((z_arpendeve2 - zarpstartslineset2[i][j])**2))*((yvector_dauset1[i])**2)
			x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset2[i][j]
			x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset2[i][j]
			x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
			x_arpendeve2 = random.choice(x_arpendsmall_big)
			a = len_dauset1[i]*larp*math.cos(math.radians(70))
			b = x_arpendeve2 - (xarpstartslineset2[i][j])
			c = xvector_dauset1[i]
			d = z_arpendeve2 - zarpstartslineset2[i][j]
			e = zvector_dauset1[i]
			g = yvector_dauset1[i]
			f = (a - b*c - d*e)/g
			h = abs(b/f)  
			count = 0
			while f < 0 or math.tan(xy_arpangle*pi/180)< h and count <10000: 
				z_arpendeve2 = random.uniform(z_arpendmineve2, z_arpendmaxeve2)
				deltaz_arpeve2 = abs(z_arpendeve2-zarpstartslineset2[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num=0
				while deltaz_arpeve2 > deltaz_arpstandard and circle_num <10000:
					z_arpendeve2 = random.uniform(z_arpendmineve2, z_arpendmaxeve2) 
					deltaz_arpeve2 = abs(z_arpendeve2-zarpstartslineset2[i][j])
					deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
					circle_num+=1
				a_parameter = ((xvector_dauset1[i])**2) + ((yvector_dauset1[i])**2)
				b_parameter = (-2)*(len_dauset1[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset1[i])*(z_arpendeve2 - zarpstartslineset2[i][j])))*(xvector_dauset1[i])
				c_parameter = ((len_dauset1[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset1[i])*(z_arpendeve2 - zarpstartslineset2[i][j])))**2) - (((larp)**2)-((z_arpendeve2 - zarpstartslineset2[i][j])**2))*((yvector_dauset1[i])**2)
				x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset2[i][j]
				x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset2[i][j]
				x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
				x_arpendeve2 = random.choice(x_arpendsmall_big)
				a = len_dauset1[i]*larp*math.cos(math.radians(70))
				b = x_arpendeve2 - (xarpstartslineset2[i][j])
				c = xvector_dauset1[i]
				d = z_arpendeve2 - zarpstartslineset2[i][j]
				e = zvector_dauset1[i]
				g = yvector_dauset1[i]
				f = (a - b*c - d*e)/g
				h = abs(b/f)  
				count+=1
			zarpendseveset2.append(z_arpendeve2)
			deltaz_arpeve2 = z_arpendeve2 - (zarpstartslineset2[i][j])
			deltaz_arpeveset2.append(deltaz_arpeve2)
			xarpendseveset2.append(x_arpendeve2)
			y_arpendeve2 = ((len_dauset1[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset1[i])*(deltaz_arpeve2)))-(xvector_dauset1[i])*(x_arpendeve2-xarpstartslineset2[i][j]))/(yvector_dauset1[i])+yarpstartslineset2[i][j]
			yarpendseveset2.append(y_arpendeve2)
		zarpendslineset2.append(zarpendseveset2)
		deltaz_arplineset2.append(deltaz_arpeveset2)
		zarpends2 = zarpends2 + zarpendseveset2
		deltaz_arps2 = deltaz_arps2 + deltaz_arpeveset2
		zarpendseveset2 = []
		deltaz_arpeveset2 = []
		xarpendslineset2.append(xarpendseveset2)
		xarpends2 = xarpends2 + xarpendseveset2
		xarpendseveset2 = []
		yarpendslineset2.append(yarpendseveset2)
		yarpends2 = yarpends2 + yarpendseveset2
		yarpendseveset2 = []
	del_arps2 = []
	for i in range(len(zarpends2)):
		if zarpends2[i] >= 200 or zarpends2[i] <= 0 or yarpends2[i]-yarpstarts2[i]< 0:
			del_arp2 = i
			del_arps2.append(del_arp2)
	del_arps2.reverse() 
	for i in del_arps2:
		del xarpstarts2[i] 
		del yarpstarts2[i]
		del zarpstarts2[i]
		del xarpends2[i]
		del yarpends2[i]
		del zarpends2[i]
		del deltaz_arps2[i]
	del_arps2_80_90degree = [] 
	for i in range(len(zarpends2)):
		delta_x = xarpends2[i]- xarpstarts2[i]
		delta_y = yarpends2[i]- yarpstarts2[i]
		length_xy = (delta_x**2 + delta_y**2)**0.5
		sin_xy = delta_x/length_xy
		abs_sin_xy = abs(sin_xy)
		limit_value = math.sin(math.radians(reduced_xyangle))
		if abs_sin_xy > limit_value:
			del_arp2_80_90degree = i
			del_arps2_80_90degree.append(del_arp2_80_90degree)
	numb_del_arps2_80_90degree = int(2*len(del_arps2_80_90degree)/3)
	del_2third_arps2_80_90degree = random.sample(del_arps2_80_90degree, numb_del_arps2_80_90degree)
	del_2third_arps2_80_90degree.sort()
	del_2third_arps2_80_90degree.reverse()
	for i in del_2third_arps2_80_90degree:
		del xarpstarts2[i] 
		del yarpstarts2[i]
		del zarpstarts2[i]
		del xarpends2[i]
		del yarpends2[i]
		del zarpends2[i]
		del deltaz_arps2[i]	
	lendaus2 = [] 
	for i in range(len(xarpends2)):
		lendau2 = random.gauss(mean_filamentlength,50)
		lendaus2.append(lendau2)
	print len(lendaus2)
	print len(deltaz_arps2)
	print len(zarpends2)
	lenratios_dau2_arp2 = []
	for i in range(len(lendaus2)):
		lenratio_dau2_arp = (lendaus2[i])/(larp)
		deltaz_dau2 = (deltaz_arps2[i])*(lenratio_dau2_arp)
		z_dau2 = deltaz_dau2 + (zarpends2[i])
		if z_dau2 > 200:
			z_dau2 = 200
			lenratio_dau2_arp = (z_dau2 - zarpends2[i])/(deltaz_arps2[i])
			lenratios_dau2_arp2.append(lenratio_dau2_arp)
		elif z_dau2 < 0:
			z_dau2 = 0
			lenratio_dau2_arp = (z_dau2 - zarpends2[i])/(deltaz_arps2[i])
			lenratios_dau2_arp2.append(lenratio_dau2_arp)
		else:
			lenratios_dau2_arp2.append(lenratio_dau2_arp)
	x_dauends2 = [] 
	y_dauends2 = []
	z_dauends2 = []
	for i in range(len(lenratios_dau2_arp2)):
		z_dauend2 = (lenratios_dau2_arp2[i])*(deltaz_arps2[i]) + (zarpends2[i])
		x_dauend2 = (lenratios_dau2_arp2[i])*(xarpends2[i] - xarpstarts2[i]) + (xarpends2[i])
		y_dauend2 = (lenratios_dau2_arp2[i])*(yarpends2[i] - yarpstarts2[i]) + (yarpends2[i])
		x_dauends2.append(x_dauend2)
		y_dauends2.append(y_dauend2)
		z_dauends2.append(z_dauend2)
	x_daustarts2 = xarpends2[:] 
	y_daustarts2 = yarpends2[:]
	z_daustarts2 = zarpends2[:] 
	xvector_dauset2 = []     
	yvector_dauset2 = [] 
	zvector_dauset2 = []
	for i in range(len(x_daustarts2)):
		xvector_dau2 = (x_dauends2 [i] - x_daustarts2 [i])
		xvector_dauset2.append(xvector_dau2)
		yvector_dau2 = (y_dauends2 [i] - y_daustarts2[i])
		yvector_dauset2.append(yvector_dau2)
		zvector_dau2 = (z_dauends2 [i] - z_daustarts2[i])
		zvector_dauset2.append(zvector_dau2)
	len_dauset2 = []
	for i in range(len(xvector_dauset2)):
		len_dau2 = (xvector_dauset2[i]**2 + yvector_dauset2[i]**2 + zvector_dauset2[i]**2)**0.5
		len_dauset2.append(len_dau2)
	del_daus2 = []
	for i in range(len(len_dauset2)):
		if len_dauset2[i]<100:
			del_dau=i
			del_daus2.append(del_dau)
	del_daus2.reverse()	
	for i in del_daus2: # to delete the filaments, whoes length are under 100, and the corresponding arps
		del len_dauset2[i]
		del x_daustarts2[i]
		del y_daustarts2[i]
		del z_daustarts2[i]
		del x_dauends2[i]
		del y_dauends2[i]
		del z_dauends2[i]
		del xarpstarts2[i] 
		del yarpstarts2[i]
		del zarpstarts2[i]
		del xarpends2[i]
		del yarpends2[i]
		del zarpends2[i]
		del xvector_dauset2[i]
		del yvector_dauset2[i]
		del zvector_dauset2[i]
	arpnumeveset3 = []  
	for i in range(len(x_daustarts2)):
		arpnumeve3 = int(round((len_dauset2[i])/l_densityarp3))
		arpnumeveset3.append(arpnumeve3)
	xarpstarts3 = []  
	yarpstarts3 = []  
	zarpstarts3 = []
	xarpstartslineset3 = []  
	yarpstartslineset3 = []  
	zarpstartslineset3 = []
	xarpstartseveset3 = [] 
	yarpstartseveset3 = [] 
	zarpstartseveset3 = [] 
	for i in range(len(arpnumeveset3)):
		for j in range (arpnumeveset3[i]):
			if arpnumeveset3[i]>0:
				arp_k = arp_generate_section/len_dauset2[i]
				lower_limit = (j+1.0)/arpnumeveset3[i] - arp_k
				upper_limit = (j+1.0)/arpnumeveset3[i]
				t = random.uniform(lower_limit, upper_limit)
				xarpstarteve3 = t*(xvector_dauset2 [i])+(x_daustarts2 [i])
				yarpstarteve3 = t*(yvector_dauset2 [i])+(y_daustarts2 [i])
				zarpstarteve3 = t*(zvector_dauset2 [i])+(z_daustarts2 [i])
				xarpstartseveset3.append(xarpstarteve3)
				yarpstartseveset3.append(yarpstarteve3)
				zarpstartseveset3.append(zarpstarteve3)
		xarpstartslineset3.append(xarpstartseveset3)
		xarpstarts3 = xarpstarts3 + xarpstartseveset3
		xarpstartseveset3 =[]
		yarpstartslineset3.append(yarpstartseveset3)
		yarpstarts3 = yarpstarts3 + yarpstartseveset3
		yarpstartseveset3 =[]
		zarpstartslineset3.append(zarpstartseveset3)
		zarpstarts3 = zarpstarts3 + zarpstartseveset3
		zarpstartseveset3 =[]
	zangles3 = []
	for i in range(len(x_daustarts2)):
		zangle3 = math.asin(zvector_dauset2[i]/len_dauset2[i])
		zangles3.append(zangle3)
	thetaz_arpminset3 = []
	thetaz_arpmaxset3 = []
	for i in range(len(zarpstartslineset3)):
		thetaz_arpmin3 = (zangles3[i] - math.radians(70))
		thetaz_arpmax3 = (zangles3[i] + math.radians(70))
		thetaz_arpminset3.append(thetaz_arpmin3)
		thetaz_arpmaxset3.append(thetaz_arpmax3)
	larp = 10
	zarpendseveset3 = []   
	zarpendslineset3 = []  
	deltaz_arpeveset3 = [] 
	deltaz_arplineset3 = [] 
	zarpends3 = []        
	deltaz_arps3 = []     
	xarpendseveset3 = []   
	xarpendslineset3 = [] 
	xarpends3 = []         
	yarpendseveset3 = []   
	yarpendslineset3 = []  
	yarpends3 = []         
	for i in range(len(zarpstartslineset3)):
		deltaz_arpminset3 = larp*(math.sin(thetaz_arpminset3[i]))
		deltaz_arpmaxset3 = larp*(math.sin(thetaz_arpmaxset3[i]))
		for j in range(len(zarpstartslineset3[i])):
			z_arpendmineve3 = (zarpstartslineset3[i][j]) + deltaz_arpminset3 
			z_arpendmaxeve3 = (zarpstartslineset3[i][j]) + deltaz_arpmaxset3 
			z_arpendeve3 = random.uniform(z_arpendmineve3, z_arpendmaxeve3)
			deltaz_arpeve3 = abs(z_arpendeve3-zarpstartslineset3[i][j])
			deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
			circle_num=0
			while deltaz_arpeve3 > deltaz_arpstandard and circle_num <10000:
				z_arpendeve3 = random.uniform(z_arpendmineve3, z_arpendmaxeve3) 
				deltaz_arpeve3 = abs(z_arpendeve3-zarpstartslineset3[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num+=1
			a_parameter = ((xvector_dauset2[i])**2) + ((yvector_dauset2[i])**2)
			b_parameter = (-2)*(len_dauset2[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset2[i])*(z_arpendeve3 - zarpstartslineset3[i][j])))*(xvector_dauset2[i])
			c_parameter = ((len_dauset2[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset2[i])*(z_arpendeve3 - zarpstartslineset3[i][j])))**2) - (((larp)**2)-((z_arpendeve3 - zarpstartslineset3[i][j])**2))*((yvector_dauset2[i])**2)
			x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset3[i][j]
			x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset3[i][j]
			x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
			x_arpendeve3 = random.choice(x_arpendsmall_big)
			a = len_dauset2[i]*larp*math.cos(math.radians(70))
			b = x_arpendeve3 - (xarpstartslineset3[i][j])
			c = xvector_dauset2[i]
			d = z_arpendeve3 - zarpstartslineset3[i][j]
			e = zvector_dauset2[i]
			g = yvector_dauset2[i]
			f = (a - b*c - d*e)/g
			h = abs(b/f)   
			count = 0
			while f < 0 or math.tan(xy_arpangle*pi/180)< h and count <10000:  
				z_arpendeve3 = random.uniform(z_arpendmineve3, z_arpendmaxeve3) 
				deltaz_arpeve3 = abs(z_arpendeve3-zarpstartslineset3[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num=0
				while deltaz_arpeve3 > deltaz_arpstandard and circle_num <10000:
					z_arpendeve3 = random.uniform(z_arpendmineve3, z_arpendmaxeve3)
					deltaz_arpeve3 = abs(z_arpendeve3-zarpstartslineset3[i][j])
					deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
					circle_num+=1
				a_parameter = ((xvector_dauset2[i])**2) + ((yvector_dauset2[i])**2)
				b_parameter = (-2)*(len_dauset2[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset2[i])*(z_arpendeve3 - zarpstartslineset3[i][j])))*(xvector_dauset2[i])
				c_parameter = ((len_dauset2[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset2[i])*(z_arpendeve3 - zarpstartslineset3[i][j])))**2) - (((larp)**2)-((z_arpendeve3 - zarpstartslineset3[i][j])**2))*((yvector_dauset2[i])**2)
				x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset3[i][j]
				x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset3[i][j]
				x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
				x_arpendeve3 = random.choice(x_arpendsmall_big)
				a = len_dauset2[i]*larp*math.cos(math.radians(70))
				b = x_arpendeve3 - (xarpstartslineset3[i][j])
				c = xvector_dauset2[i]
				d = z_arpendeve3 - zarpstartslineset3[i][j]
				e = zvector_dauset2[i]
				g = yvector_dauset2[i]
				f = (a - b*c - d*e)/g
				h = abs(b/f)  
				count+=1
			zarpendseveset3.append(z_arpendeve3)
			deltaz_arpeve3 = z_arpendeve3 - (zarpstartslineset3[i][j])
			deltaz_arpeveset3.append(deltaz_arpeve3)
			xarpendseveset3.append(x_arpendeve3)
			y_arpendeve3 = ((len_dauset2[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset2[i])*(deltaz_arpeve3)))-(xvector_dauset2[i])*(x_arpendeve3-xarpstartslineset3[i][j]))/(yvector_dauset2[i])+yarpstartslineset3[i][j]
			yarpendseveset3.append(y_arpendeve3)
		zarpendslineset3.append(zarpendseveset3)
		deltaz_arplineset3.append(deltaz_arpeveset3)
		zarpends3 = zarpends3 + zarpendseveset3
		deltaz_arps3 = deltaz_arps3 + deltaz_arpeveset3
		zarpendseveset3 = []
		deltaz_arpeveset3 = []
		xarpendslineset3.append(xarpendseveset3)
		xarpends3 = xarpends3 + xarpendseveset3
		xarpendseveset3 = []
		yarpendslineset3.append(yarpendseveset3)
		yarpends3 = yarpends3 + yarpendseveset3
		yarpendseveset3 = []
	del_arps3 = [] 
	for i in range(len(zarpends3)):
		if zarpends3[i] >= 200 or zarpends3[i] <= 0 or yarpends3[i]-yarpstarts3[i]< 0:
			del_arp3 = i
			del_arps3.append(del_arp3)
	del_arps3.reverse() 
	for i in del_arps3:
		del xarpstarts3[i]
		del yarpstarts3[i]
		del zarpstarts3[i]
		del xarpends3[i]
		del yarpends3[i]
		del zarpends3[i]
		del deltaz_arps3[i]
	del_arps3_80_90degree = [] 
	for i in range(len(zarpends3)):
		delta_x = xarpends3[i]- xarpstarts3[i]
		delta_y = yarpends3[i]- yarpstarts3[i]
		length_xy = (delta_x**2 + delta_y**2)**0.5
		sin_xy = delta_x/length_xy
		abs_sin_xy = abs(sin_xy)
		limit_value = math.sin(math.radians(reduced_xyangle))
		if abs_sin_xy > limit_value:
			del_arp3_80_90degree = i
			del_arps3_80_90degree.append(del_arp3_80_90degree)
	numb_del_arps3_80_90degree = int(2*len(del_arps3_80_90degree)/3) ### 删除2/3的与前进方向呈现80-90度的arps
	del_2third_arps3_80_90degree = random.sample(del_arps3_80_90degree, numb_del_arps3_80_90degree)
	del_2third_arps3_80_90degree.sort()
	del_2third_arps3_80_90degree.reverse()
	for i in del_2third_arps3_80_90degree:
		del xarpstarts3[i] 
		del yarpstarts3[i]
		del zarpstarts3[i]
		del xarpends3[i]
		del yarpends3[i]
		del zarpends3[i]
		del deltaz_arps3[i]
	lendaus3 = [] 
	for i in range(len(xarpends3)):
		lendau3 = random.gauss(mean_filamentlength,50)
		lendaus3.append(lendau3)
	print len(lendaus3)
	print len(deltaz_arps3)
	print len(zarpends3)
	lenratios_dau3_arp3 = [] 
	for i in range(len(lendaus3)):
		lenratio_dau3_arp = (lendaus3[i])/(larp)
		deltaz_dau3 = (deltaz_arps3[i])*(lenratio_dau3_arp)
		z_dau3 = deltaz_dau3 + (zarpends3[i])
		if z_dau3 > 200:
			z_dau3 = 200
			lenratio_dau3_arp = (z_dau3 - zarpends3[i])/(deltaz_arps3[i])
			lenratios_dau3_arp3.append(lenratio_dau3_arp)
		elif z_dau3 < 0:
			z_dau3 = 0
			lenratio_dau3_arp = (z_dau3 - zarpends3[i])/(deltaz_arps3[i])
			lenratios_dau3_arp3.append(lenratio_dau3_arp)
		else:
			lenratios_dau3_arp3.append(lenratio_dau3_arp)
	x_dauends3 = [] 
	y_dauends3 = [] 
	z_dauends3 = [] 
	for i in range(len(lenratios_dau3_arp3)):
		z_dauend3 = (lenratios_dau3_arp3[i])*(deltaz_arps3[i]) + (zarpends3[i])
		x_dauend3 = (lenratios_dau3_arp3[i])*(xarpends3[i] - xarpstarts3[i]) + (xarpends3[i])
		y_dauend3 = (lenratios_dau3_arp3[i])*(yarpends3[i] - yarpstarts3[i]) + (yarpends3[i])
		x_dauends3.append(x_dauend3)
		y_dauends3.append(y_dauend3)
		z_dauends3.append(z_dauend3)
	x_daustarts3 = xarpends3[:] 
	y_daustarts3 = yarpends3[:] 
	z_daustarts3 = zarpends3[:] 
	xvector_dauset3 = []     
	yvector_dauset3 = []     
	zvector_dauset3 = []     
	for i in range(len(x_daustarts3)):
		xvector_dau3 = (x_dauends3[i] - x_daustarts3[i])
		xvector_dauset3.append(xvector_dau3)
		yvector_dau3 = (y_dauends3[i] - y_daustarts3[i])
		yvector_dauset3.append(yvector_dau3)
		zvector_dau3 = (z_dauends3[i] - z_daustarts3[i])
		zvector_dauset3.append(zvector_dau3)
	len_dauset3 = []
	for i in range(len(xvector_dauset3)):
		len_dau3 = (xvector_dauset3[i]**2 + yvector_dauset3[i]**2 + zvector_dauset3[i]**2)**0.5
		len_dauset3.append(len_dau3)
	del_daus3 = []
	for i in range(len(len_dauset3)):
		if len_dauset3[i]<100:
			del_dau=i
			del_daus3.append(del_dau)
	del_daus3.reverse()	
	for i in del_daus3:
		del len_dauset3[i]
		del x_daustarts3[i]
		del y_daustarts3[i]
		del z_daustarts3[i]
		del x_dauends3[i]
		del y_dauends3[i]
		del z_dauends3[i]
		del xarpstarts3[i] 
		del yarpstarts3[i]
		del zarpstarts3[i]
		del xarpends3[i]
		del yarpends3[i]
		del zarpends3[i]
		del xvector_dauset3[i]
		del yvector_dauset3[i]
		del zvector_dauset3[i]
	len(x_dauends1)
	len(xarpstarts1)
	len(x_dauends2)
	len(xarpstarts2)
	len(x_dauends3)
	len(xarpstarts3)
	arpnumeveset4 = []   
	for i in range(len(x_daustarts3)):
		arpnumeve4 = int(round((len_dauset3[i])/l_densityarp4))  
		arpnumeveset4.append(arpnumeve4)
	xarpstarts4 = [] 
	yarpstarts4 = [] 
	zarpstarts4 = [] 
	xarpstartslineset4 = []  
	yarpstartslineset4 = []  
	zarpstartslineset4 = []  
	xarpstartseveset4 = []  
	yarpstartseveset4 = []   
	zarpstartseveset4 = []   
	for i in range(len(arpnumeveset4)):
		for j in range (arpnumeveset4[i]):
			if arpnumeveset4[i]>0:
				arp_k = arp_generate_section/len_dauset3[i]
				lower_limit = (j+1.0)/arpnumeveset4[i] - arp_k
				upper_limit = (j+1.0)/arpnumeveset4[i]
				t = random.uniform(lower_limit, upper_limit)
				xarpstarteve4 = t*(xvector_dauset3 [i])+(x_daustarts3 [i])
				yarpstarteve4 = t*(yvector_dauset3 [i])+(y_daustarts3 [i])
				zarpstarteve4 = t*(zvector_dauset3 [i])+(z_daustarts3 [i])
				xarpstartseveset4.append(xarpstarteve4)
				yarpstartseveset4.append(yarpstarteve4)
				zarpstartseveset4.append(zarpstarteve4)
		xarpstartslineset4.append(xarpstartseveset4)
		xarpstarts4 = xarpstarts4 + xarpstartseveset4
		xarpstartseveset4 =[]
		yarpstartslineset4.append(yarpstartseveset4)
		yarpstarts4 = yarpstarts4 + yarpstartseveset4
		yarpstartseveset4 =[]
		zarpstartslineset4.append(zarpstartseveset4)
		zarpstarts4 = zarpstarts4 + zarpstartseveset4
		zarpstartseveset4 =[]
	zangles4 = []
	for i in range(len(x_daustarts3)):
		zangle4 = math.asin(zvector_dauset3[i]/len_dauset3[i])
		zangles4.append(zangle4)
	thetaz_arpminset4 = []
	thetaz_arpmaxset4 = []
	for i in range(len(zarpstartslineset4)):
		thetaz_arpmin4 = (zangles4[i] - math.radians(70))
		thetaz_arpmax4 = (zangles4[i] + math.radians(70))
		thetaz_arpminset4.append(thetaz_arpmin4)
		thetaz_arpmaxset4.append(thetaz_arpmax4)
	zarpendseveset4 = []   
	zarpendslineset4 = []   
	deltaz_arpeveset4 = []  
	deltaz_arplineset4 = [] 
	zarpends4 = []       
	deltaz_arps4 = []      
	xarpendseveset4 = []   
	xarpendslineset4 = []  
	xarpends4 = []         
	yarpendseveset4 = []   
	yarpendslineset4 = []  
	yarpends4 = []         
	for i in range(len(zarpstartslineset4)):
		deltaz_arpminset4 = larp*(math.sin(thetaz_arpminset4[i]))
		deltaz_arpmaxset4 = larp*(math.sin(thetaz_arpmaxset4[i]))
		for j in range(len(zarpstartslineset4[i])):
			z_arpendmineve4 = (zarpstartslineset4[i][j]) + deltaz_arpminset4 
			z_arpendmaxeve4 = (zarpstartslineset4[i][j]) + deltaz_arpmaxset4 
			z_arpendeve4 = random.uniform(z_arpendmineve4, z_arpendmaxeve4) 
			deltaz_arpeve4 = abs(z_arpendeve4-zarpstartslineset4[i][j])
			deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
			circle_num=0
			while deltaz_arpeve4 > deltaz_arpstandard and circle_num <10000:
				z_arpendeve4 = random.uniform(z_arpendmineve4, z_arpendmaxeve4) 
				deltaz_arpeve4 = abs(z_arpendeve4-zarpstartslineset4[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num+=1
			a_parameter = ((xvector_dauset3[i])**2) + ((yvector_dauset3[i])**2)
			b_parameter = (-2)*(len_dauset3[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset3[i])*(z_arpendeve4 - zarpstartslineset4[i][j])))*(xvector_dauset3[i])
			c_parameter = ((len_dauset3[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset3[i])*(z_arpendeve4 - zarpstartslineset4[i][j])))**2) - (((larp)**2)-((z_arpendeve4 - zarpstartslineset4[i][j])**2))*((yvector_dauset3[i])**2)
			x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset4[i][j]
			x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset4[i][j]
			x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
			x_arpendeve4 = random.choice(x_arpendsmall_big)
			a = len_dauset3[i]*larp*math.cos(math.radians(70))
			b = x_arpendeve4 - (xarpstartslineset4[i][j])
			c = xvector_dauset3[i]
			d = z_arpendeve4 - zarpstartslineset4[i][j]
			e = zvector_dauset3[i]
			g = yvector_dauset3[i]
			f = (a - b*c - d*e)/g
			h = abs(b/f)  
			count = 0
			while f < 0 or math.tan(xy_arpangle*pi/180)< h and count <10000:  
				z_arpendeve4 = random.uniform(z_arpendmineve4, z_arpendmaxeve4) 
				deltaz_arpeve4 = abs(z_arpendeve4-zarpstartslineset4[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num=0
				while deltaz_arpeve4 > deltaz_arpstandard and circle_num <10000:
					z_arpendeve4 = random.uniform(z_arpendmineve4, z_arpendmaxeve4)
					deltaz_arpeve4 = abs(z_arpendeve4-zarpstartslineset4[i][j])
					deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
					circle_num+=1
				a_parameter = ((xvector_dauset3[i])**2) + ((yvector_dauset3[i])**2)
				b_parameter = (-2)*(len_dauset3[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset3[i])*(z_arpendeve4 - zarpstartslineset4[i][j])))*(xvector_dauset3[i])
				c_parameter = ((len_dauset3[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset3[i])*(z_arpendeve4 - zarpstartslineset4[i][j])))**2) - (((larp)**2)-((z_arpendeve4 - zarpstartslineset4[i][j])**2))*((yvector_dauset3[i])**2)
				x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset4[i][j]
				x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset4[i][j]
				x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
				x_arpendeve4 = random.choice(x_arpendsmall_big)
				a = len_dauset3[i]*larp*math.cos(math.radians(70))
				b = x_arpendeve4 - (xarpstartslineset4[i][j])
				c = xvector_dauset3[i]
				d = z_arpendeve4 - zarpstartslineset4[i][j]
				e = zvector_dauset3[i]
				g = yvector_dauset3[i]
				f = (a - b*c - d*e)/g
				h = abs(b/f)  
				count+=1
			zarpendseveset4.append(z_arpendeve4)
			deltaz_arpeve4 = z_arpendeve4 - (zarpstartslineset4[i][j])
			deltaz_arpeveset4.append(deltaz_arpeve4)
			xarpendseveset4.append(x_arpendeve4)
			y_arpendeve4 = ((len_dauset3[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset3[i])*(deltaz_arpeve4)))-(xvector_dauset3[i])*(x_arpendeve4-xarpstartslineset4[i][j]))/(yvector_dauset3[i])+yarpstartslineset4[i][j]
			yarpendseveset4.append(y_arpendeve4)
		zarpendslineset4.append(zarpendseveset4)
		deltaz_arplineset4.append(deltaz_arpeveset4)
		zarpends4 = zarpends4 + zarpendseveset4
		deltaz_arps4 = deltaz_arps4 + deltaz_arpeveset4
		zarpendseveset4 = []
		deltaz_arpeveset4 = []
		xarpendslineset4.append(xarpendseveset4)
		xarpends4 = xarpends4 + xarpendseveset4
		xarpendseveset4 = []
		yarpendslineset4.append(yarpendseveset4)
		yarpends4 = yarpends4 + yarpendseveset4
		yarpendseveset4 = []
	del_arps4 = [] 
	for i in range(len(zarpends4)):
		if zarpends4[i] >= 200 or zarpends4[i] <= 0 or yarpends4[i]-yarpstarts4[i]< 0:
			del_arp4 = i
			del_arps4.append(del_arp4)
	del_arps4.reverse() 
	for i in del_arps4:
		del xarpstarts4[i]
		del yarpstarts4[i]
		del zarpstarts4[i]
		del xarpends4[i]
		del yarpends4[i]
		del zarpends4[i]
		del deltaz_arps4[i]
	del_arps4_80_90degree = []
	for i in range(len(zarpends4)):
		delta_x = xarpends4[i]- xarpstarts4[i]
		delta_y = yarpends4[i]- yarpstarts4[i]
		length_xy = (delta_x**2 + delta_y**2)**0.5
		sin_xy = delta_x/length_xy
		abs_sin_xy = abs(sin_xy)
		limit_value = math.sin(math.radians(reduced_xyangle))
		if abs_sin_xy > limit_value:
			del_arp4_80_90degree = i
			del_arps4_80_90degree.append(del_arp4_80_90degree)
	numb_del_arps4_80_90degree = int(2*len(del_arps4_80_90degree)/3) 
	del_2third_arps4_80_90degree = random.sample(del_arps4_80_90degree, numb_del_arps4_80_90degree)
	del_2third_arps4_80_90degree.sort()
	del_2third_arps4_80_90degree.reverse()
	for i in del_2third_arps4_80_90degree:
		del xarpstarts4[i]
		del yarpstarts4[i]
		del zarpstarts4[i]
		del xarpends4[i]
		del yarpends4[i]
		del zarpends4[i]
		del deltaz_arps4[i]
	lendaus4 = [] 
	for i in range(len(xarpends4)):
		lendau4 = random.gauss(mean_filamentlength,50)
		lendaus4.append(lendau4)
	print len(lendaus4)
	print len(deltaz_arps4)
	print len(zarpends4)
	lenratios_dau4_arp4 = [] 
	for i in range(len(lendaus4)):
		lenratio_dau4_arp = (lendaus4[i])/(larp)
		deltaz_dau4 = (deltaz_arps4[i])*(lenratio_dau4_arp)
		z_dau4 = deltaz_dau4 + (zarpends4[i])
		if z_dau4 > 200:
			z_dau4 = 200
			lenratio_dau4_arp = (z_dau4 - zarpends4[i])/(deltaz_arps4[i])
			lenratios_dau4_arp4.append(lenratio_dau4_arp)
		elif z_dau4 < 0:
			z_dau4 = 0
			lenratio_dau4_arp = (z_dau4 - zarpends4[i])/(deltaz_arps4[i])
			lenratios_dau4_arp4.append(lenratio_dau4_arp)
		else:
			lenratios_dau4_arp4.append(lenratio_dau4_arp)
	x_dauends4 = []
	y_dauends4 = []
	z_dauends4 = []
	for i in range(len(lenratios_dau4_arp4)):
		z_dauend4 = (lenratios_dau4_arp4[i])*(deltaz_arps4[i]) + (zarpends4[i])
		x_dauend4 = (lenratios_dau4_arp4[i])*(xarpends4[i] - xarpstarts4[i]) + (xarpends4[i])
		y_dauend4 = (lenratios_dau4_arp4[i])*(yarpends4[i] - yarpstarts4[i]) + (yarpends4[i])
		x_dauends4.append(x_dauend4)
		y_dauends4.append(y_dauend4)
		z_dauends4.append(z_dauend4)
	x_daustarts4 = xarpends4[:] 
	y_daustarts4 = yarpends4[:]
	z_daustarts4 = zarpends4[:] 
	xvector_dauset4 = []    
	yvector_dauset4 = []     
	zvector_dauset4 = []     
	for i in range(len(x_daustarts4)):
		xvector_dau4 = (x_dauends4[i] - x_daustarts4[i])
		xvector_dauset4.append(xvector_dau4)
		yvector_dau4 = (y_dauends4[i] - y_daustarts4[i])
		yvector_dauset4.append(yvector_dau4)
		zvector_dau4 = (z_dauends4[i] - z_daustarts4[i])
		zvector_dauset4.append(zvector_dau4)
	len_dauset4 = []
	for i in range(len(xvector_dauset4)):
		len_dau4 = (xvector_dauset4[i]**2 + yvector_dauset4[i]**2 + zvector_dauset4[i]**2)**0.5
		len_dauset4.append(len_dau4)
	del_daus4 = []
	for i in range(len(len_dauset4)):
		if len_dauset4[i]<100:
			del_dau=i
			del_daus4.append(del_dau)
	del_daus4.reverse()	
	for i in del_daus4: 
		del len_dauset4[i]
		del x_daustarts4[i]
		del y_daustarts4[i]
		del z_daustarts4[i]
		del x_dauends4[i]
		del y_dauends4[i]
		del z_dauends4[i]
		del xarpstarts4[i] 
		del yarpstarts4[i]
		del zarpstarts4[i]
		del xarpends4[i]
		del yarpends4[i]
		del zarpends4[i]
		del xvector_dauset4[i]
		del yvector_dauset4[i]
		del zvector_dauset4[i]
	arpnumeveset5 = []   
	for i in range(len(x_daustarts4)):
		arpnumeve5 = int(round((len_dauset4[i])/l_densityarp5))  # to calculate the number of arps along each mother actin filaments
		arpnumeveset5.append(arpnumeve5)
	xarpstarts5 = [] 
	yarpstarts5 = [] 
	zarpstarts5 = []  
	xarpstartslineset5 = []  
	yarpstartslineset5 = []  
	zarpstartslineset5 = [] 
	xarpstartseveset5 = []  
	yarpstartseveset5 = []  
	zarpstartseveset5 = []  
	for i in range(len(arpnumeveset5)):
		for j in range (arpnumeveset5[i]):
			if arpnumeveset5[i]>0:
				arp_k = arp_generate_section/len_dauset4[i]
				lower_limit = (j+1.0)/arpnumeveset5[i] - arp_k
				upper_limit = (j+1.0)/arpnumeveset5[i]
				t = random.uniform(lower_limit, upper_limit)
				xarpstarteve5 = t*(xvector_dauset4 [i])+(x_daustarts4 [i])
				yarpstarteve5 = t*(yvector_dauset4 [i])+(y_daustarts4 [i])
				zarpstarteve5 = t*(zvector_dauset4 [i])+(z_daustarts4 [i])
				xarpstartseveset5.append(xarpstarteve5)
				yarpstartseveset5.append(yarpstarteve5)
				zarpstartseveset5.append(zarpstarteve5)
		xarpstartslineset5.append(xarpstartseveset5)
		xarpstarts5 = xarpstarts5 + xarpstartseveset5
		xarpstartseveset5 =[]
		yarpstartslineset5.append(yarpstartseveset5)
		yarpstarts5 = yarpstarts5 + yarpstartseveset5
		yarpstartseveset5 =[]
		zarpstartslineset5.append(zarpstartseveset5)
		zarpstarts5 = zarpstarts5 + zarpstartseveset5
		zarpstartseveset5 =[]
	zangles5 = []
	for i in range(len(x_daustarts4)):
		zangle5 = math.asin(zvector_dauset4[i]/len_dauset4[i])
		zangles5.append(zangle5)
	thetaz_arpminset5 = []
	thetaz_arpmaxset5 = []
	for i in range(len(zarpstartslineset5)):
		thetaz_arpmin5 = (zangles5[i] - math.radians(70))
		thetaz_arpmax5 = (zangles5[i] + math.radians(70))
		thetaz_arpminset5.append(thetaz_arpmin5)
		thetaz_arpmaxset5.append(thetaz_arpmax5)
	zarpendseveset5 = []    
	zarpendslineset5 = []  
	deltaz_arpeveset5 = []  
	deltaz_arplineset5 = []
	zarpends5 = []          
	deltaz_arps5 = []     
	xarpendseveset5 = []    
	xarpendslineset5 = []   
	xarpends5 = []        
	yarpendseveset5 = []   
	yarpendslineset5 = []   
	yarpends5 = []         
	for i in range(len(zarpstartslineset5)):
		deltaz_arpminset5 = larp*(math.sin(thetaz_arpminset5[i]))
		deltaz_arpmaxset5 = larp*(math.sin(thetaz_arpmaxset5[i]))
		for j in range(len(zarpstartslineset5[i])):
			z_arpendmineve5 = (zarpstartslineset5[i][j]) + deltaz_arpminset5 
			z_arpendmaxeve5 = (zarpstartslineset5[i][j]) + deltaz_arpmaxset5 
			z_arpendeve5 = random.uniform(z_arpendmineve5, z_arpendmaxeve5) 
			deltaz_arpeve5 = abs(z_arpendeve5-zarpstartslineset5[i][j])
			deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
			circle_num=0
			while deltaz_arpeve5 > deltaz_arpstandard and circle_num <10000:
				z_arpendeve5 = random.uniform(z_arpendmineve5, z_arpendmaxeve5) 
				deltaz_arpeve5 = abs(z_arpendeve5-zarpstartslineset5[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num+=1
			a_parameter = ((xvector_dauset4[i])**2) + ((yvector_dauset4[i])**2)
			b_parameter = (-2)*(len_dauset4[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset4[i])*(z_arpendeve5 - zarpstartslineset5[i][j])))*(xvector_dauset4[i])
			c_parameter = ((len_dauset4[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset4[i])*(z_arpendeve5 - zarpstartslineset5[i][j])))**2) - (((larp)**2)-((z_arpendeve5 - zarpstartslineset5[i][j])**2))*((yvector_dauset4[i])**2)
			x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset5[i][j]
			x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset5[i][j]
			x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
			x_arpendeve5 = random.choice(x_arpendsmall_big)
			a = len_dauset4[i]*larp*math.cos(math.radians(70))
			b = x_arpendeve5 - (xarpstartslineset5[i][j])
			c = xvector_dauset4[i]
			d = z_arpendeve5 - zarpstartslineset5[i][j]
			e = zvector_dauset4[i]
			g = yvector_dauset4[i]
			f = (a - b*c - d*e)/g
			h = abs(b/f)  
			count = 0
			while f < 0 or math.tan(xy_arpangle*pi/180)< h and count <10000: 
				z_arpendeve5 = random.uniform(z_arpendmineve5, z_arpendmaxeve5) 
				deltaz_arpeve5 = abs(z_arpendeve5-zarpstartslineset5[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num=0
				while deltaz_arpeve5 > deltaz_arpstandard and circle_num <10000:
					z_arpendeve5 = random.uniform(z_arpendmineve5, z_arpendmaxeve5) # 母杆i上第j个Arp的z坐标
					deltaz_arpeve5 = abs(z_arpendeve5-zarpstartslineset5[i][j])
					deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
					circle_num+=1
				a_parameter = ((xvector_dauset4[i])**2) + ((yvector_dauset4[i])**2)
				b_parameter = (-2)*(len_dauset4[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset4[i])*(z_arpendeve5 - zarpstartslineset5[i][j])))*(xvector_dauset4[i])
				c_parameter = ((len_dauset4[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset4[i])*(z_arpendeve5 - zarpstartslineset5[i][j])))**2) - (((larp)**2)-((z_arpendeve5 - zarpstartslineset5[i][j])**2))*((yvector_dauset4[i])**2)
				x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset5[i][j]
				x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset5[i][j]
				x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
				x_arpendeve5 = random.choice(x_arpendsmall_big)
				a = len_dauset4[i]*larp*math.cos(math.radians(70))
				b = x_arpendeve5 - (xarpstartslineset5[i][j])
				c = xvector_dauset4[i]
				d = z_arpendeve5 - zarpstartslineset5[i][j]
				e = zvector_dauset4[i]
				g = yvector_dauset4[i]
				f = (a - b*c - d*e)/g
				h = abs(b/f)  
				count+=1
			zarpendseveset5.append(z_arpendeve5)
			deltaz_arpeve5 = z_arpendeve5 - (zarpstartslineset5[i][j])
			deltaz_arpeveset5.append(deltaz_arpeve5)
			xarpendseveset5.append(x_arpendeve5)
			y_arpendeve5 = ((len_dauset4[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset4[i])*(deltaz_arpeve5)))-(xvector_dauset4[i])*(x_arpendeve5-xarpstartslineset5[i][j]))/(yvector_dauset4[i])+yarpstartslineset5[i][j]
			yarpendseveset5.append(y_arpendeve5)
		zarpendslineset5.append(zarpendseveset5)
		deltaz_arplineset5.append(deltaz_arpeveset5)
		zarpends5 = zarpends5 + zarpendseveset5
		deltaz_arps5 = deltaz_arps5 + deltaz_arpeveset5
		zarpendseveset5 = []
		deltaz_arpeveset5 = []
		xarpendslineset5.append(xarpendseveset5)
		xarpends5 = xarpends5 + xarpendseveset5
		xarpendseveset5 = []
		yarpendslineset5.append(yarpendseveset5)
		yarpends5 = yarpends5 + yarpendseveset5
		yarpendseveset5 = []
	del_arps5 = []
	for i in range(len(zarpends5)):
		if zarpends5[i] >= 200 or zarpends5[i] <= 0 or yarpends5[i]-yarpstarts5[i]< 0:
			del_arp5 = i
			del_arps5.append(del_arp5)
	del_arps5.reverse()
	for i in del_arps5:
		del xarpstarts5[i] 
		del yarpstarts5[i]
		del zarpstarts5[i]
		del xarpends5[i]
		del yarpends5[i]
		del zarpends5[i]
		del deltaz_arps5[i]
	del_arps5_80_90degree = [] 
	for i in range(len(zarpends5)):
		delta_x = xarpends5[i]- xarpstarts5[i]
		delta_y = yarpends5[i]- yarpstarts5[i]
		length_xy = (delta_x**2 + delta_y**2)**0.5
		sin_xy = delta_x/length_xy
		abs_sin_xy = abs(sin_xy)
		limit_value = math.sin(math.radians(reduced_xyangle))
		if abs_sin_xy > limit_value:
			del_arp5_80_90degree = i
			del_arps5_80_90degree.append(del_arp5_80_90degree)
	numb_del_arps5_80_90degree = int(2*len(del_arps5_80_90degree)/3) 
	del_2third_arps5_80_90degree = random.sample(del_arps5_80_90degree, numb_del_arps5_80_90degree)
	del_2third_arps5_80_90degree.sort()
	del_2third_arps5_80_90degree.reverse()
	for i in del_2third_arps5_80_90degree:
		del xarpstarts5[i]
		del yarpstarts5[i]
		del zarpstarts5[i]
		del xarpends5[i]
		del yarpends5[i]
		del zarpends5[i]
		del deltaz_arps5[i]
	lendaus5 = [] 
	for i in range(len(xarpends5)):
		lendau5 = random.gauss(mean_filamentlength,50)
		lendaus5.append(lendau5)
	print len(lendaus5)
	print len(deltaz_arps5)
	print len(zarpends5)
	lenratios_dau5_arp5 = [] 
	for i in range(len(lendaus5)):
		lenratio_dau5_arp = (lendaus5[i])/(larp)
		deltaz_dau5 = (deltaz_arps5[i])*(lenratio_dau5_arp)
		z_dau5 = deltaz_dau5 + (zarpends5[i])
		if z_dau5 > 200:
			z_dau5 = 200
			lenratio_dau5_arp = (z_dau5 - zarpends5[i])/(deltaz_arps5[i])
			lenratios_dau5_arp5.append(lenratio_dau5_arp)
		elif z_dau5 < 0:
			z_dau5 = 0
			lenratio_dau5_arp = (z_dau5 - zarpends5[i])/(deltaz_arps5[i])
			lenratios_dau5_arp5.append(lenratio_dau5_arp)
		else:
			lenratios_dau5_arp5.append(lenratio_dau5_arp)
	x_dauends5 = []
	y_dauends5 = [] 
	z_dauends5 = [] 
	for i in range(len(lenratios_dau5_arp5)):
		z_dauend5 = (lenratios_dau5_arp5[i])*(deltaz_arps5[i]) + (zarpends5[i])
		x_dauend5 = (lenratios_dau5_arp5[i])*(xarpends5[i] - xarpstarts5[i]) + (xarpends5[i])
		y_dauend5 = (lenratios_dau5_arp5[i])*(yarpends5[i] - yarpstarts5[i]) + (yarpends5[i])
		x_dauends5.append(x_dauend5)
		y_dauends5.append(y_dauend5)
		z_dauends5.append(z_dauend5)
	x_daustarts5 = xarpends5[:]
	y_daustarts5 = yarpends5[:] 
	z_daustarts5 = zarpends5[:] 
	xvector_dauset5 = []     
	yvector_dauset5 = []     
	zvector_dauset5 = []    
	for i in range(len(x_daustarts5)):
		xvector_dau5 = (x_dauends5[i] - x_daustarts5[i])
		xvector_dauset5.append(xvector_dau5)
		yvector_dau5 = (y_dauends5[i] - y_daustarts5[i])
		yvector_dauset5.append(yvector_dau5)
		zvector_dau5 = (z_dauends5[i] - z_daustarts5[i])
		zvector_dauset5.append(zvector_dau5)
	len_dauset5 = []
	for i in range(len(xvector_dauset5)):
		len_dau5 = (xvector_dauset5[i]**2 + yvector_dauset5[i]**2 + zvector_dauset5[i]**2)**0.5
		len_dauset5.append(len_dau5)
	del_daus5 = []
	for i in range(len(len_dauset5)):
		if len_dauset5[i]<100:
			del_dau=i
			del_daus5.append(del_dau)
	del_daus5.reverse()	
	for i in del_daus5: # to delete the filaments, whoes length are under 100, and the corresponding arps
		del len_dauset5[i]
		del x_daustarts5[i]
		del y_daustarts5[i]
		del z_daustarts5[i]
		del x_dauends5[i]
		del y_dauends5[i]
		del z_dauends5[i]
		del xarpstarts5[i] 
		del yarpstarts5[i]
		del zarpstarts5[i]
		del xarpends5[i]
		del yarpends5[i]
		del zarpends5[i]
		del xvector_dauset5[i]
		del yvector_dauset5[i]
		del zvector_dauset5[i]
	arpnumeveset6 = []   
	for i in range(len(x_daustarts5)):
		arpnumeve6 = int(round((len_dauset5[i])/l_densityarp6)) 
		arpnumeveset6.append(arpnumeve6)
	xarpstarts6 = [] 
	yarpstarts6 = []  
	zarpstarts6 = [] 
	xarpstartslineset6 = [] 
	yarpstartslineset6 = [] 
	zarpstartslineset6 = [] 
	xarpstartseveset6 = []  
	yarpstartseveset6 = [] 
	zarpstartseveset6 = []  
	for i in range(len(arpnumeveset6)):
		for j in range (arpnumeveset6[i]):
			if arpnumeveset6[i]>0:
				arp_k = arp_generate_section/len_dauset5[i]
				lower_limit = (j+1.0)/arpnumeveset6[i] - arp_k
				upper_limit = (j+1.0)/arpnumeveset6[i]
				t = random.uniform(lower_limit, upper_limit)
				xarpstarteve6 = t*(xvector_dauset5 [i])+(x_daustarts5 [i])
				yarpstarteve6 = t*(yvector_dauset5 [i])+(y_daustarts5 [i])
				zarpstarteve6 = t*(zvector_dauset5 [i])+(z_daustarts5 [i])
				xarpstartseveset6.append(xarpstarteve6)
				yarpstartseveset6.append(yarpstarteve6)
				zarpstartseveset6.append(zarpstarteve6)
		xarpstartslineset6.append(xarpstartseveset6)
		xarpstarts6 = xarpstarts6 + xarpstartseveset6
		xarpstartseveset6 =[]
		yarpstartslineset6.append(yarpstartseveset6)
		yarpstarts6 = yarpstarts6 + yarpstartseveset6
		yarpstartseveset6 =[]
		zarpstartslineset6.append(zarpstartseveset6)
		zarpstarts6 = zarpstarts6 + zarpstartseveset6
		zarpstartseveset6 =[]
	zangles6 = []
	for i in range(len(x_daustarts5)):
		zangle6 = math.asin(zvector_dauset5[i]/len_dauset5[i])
		zangles6.append(zangle6)
	thetaz_arpminset6 = []
	thetaz_arpmaxset6 = []
	for i in range(len(zarpstartslineset6)):
		thetaz_arpmin6 = (zangles6[i] - math.radians(70))
		thetaz_arpmax6 = (zangles6[i] + math.radians(70))
		thetaz_arpminset6.append(thetaz_arpmin6)
		thetaz_arpmaxset6.append(thetaz_arpmax6)
	zarpendseveset6 = []  
	zarpendslineset6 = []   
	deltaz_arpeveset6 = [] 
	deltaz_arplineset6 = [] 
	zarpends6 = []    
	deltaz_arps6 = []    
	xarpendseveset6 = []    
	xarpendslineset6 = []   
	xarpends6 = []        
	yarpendseveset6 = []  
	yarpendslineset6 = []   
	yarpends6 = []      
	for i in range(len(zarpstartslineset6)):
		deltaz_arpminset6 = larp*(math.sin(thetaz_arpminset6[i]))
		deltaz_arpmaxset6 = larp*(math.sin(thetaz_arpmaxset6[i]))
		for j in range(len(zarpstartslineset6[i])):
			z_arpendmineve6 = (zarpstartslineset6[i][j]) + deltaz_arpminset6 
			z_arpendmaxeve6 = (zarpstartslineset6[i][j]) + deltaz_arpmaxset6 
			z_arpendeve6 = random.uniform(z_arpendmineve6, z_arpendmaxeve6) 
			deltaz_arpeve6 = abs(z_arpendeve6-zarpstartslineset6[i][j])
			deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
			circle_num=0
			while deltaz_arpeve6 > deltaz_arpstandard and circle_num <10000:
				z_arpendeve6 = random.uniform(z_arpendmineve6, z_arpendmaxeve6) 
				deltaz_arpeve6 = abs(z_arpendeve6-zarpstartslineset6[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num+=1
			a_parameter = ((xvector_dauset5[i])**2) + ((yvector_dauset5[i])**2)
			b_parameter = (-2)*(len_dauset5[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset5[i])*(z_arpendeve6 - zarpstartslineset6[i][j])))*(xvector_dauset5[i])
			c_parameter = ((len_dauset5[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset5[i])*(z_arpendeve6 - zarpstartslineset6[i][j])))**2) - (((larp)**2)-((z_arpendeve6 - zarpstartslineset6[i][j])**2))*((yvector_dauset5[i])**2)
			x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset6[i][j]
			x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset6[i][j]
			x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
			x_arpendeve6 = random.choice(x_arpendsmall_big)
			a = len_dauset5[i]*larp*math.cos(math.radians(70))
			b = x_arpendeve6 - (xarpstartslineset6[i][j])
			c = xvector_dauset5[i]
			d = z_arpendeve6 - zarpstartslineset6[i][j]
			e = zvector_dauset5[i]
			g = yvector_dauset5[i]
			f = (a - b*c - d*e)/g
			h = abs(b/f)   
			count = 0
			while f < 0 or math.tan(xy_arpangle*pi/180)< h and count <10000: 
				z_arpendeve6 = random.uniform(z_arpendmineve6, z_arpendmaxeve6) 
				deltaz_arpeve6 = abs(z_arpendeve6-zarpstartslineset6[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num=0
				while deltaz_arpeve6 > deltaz_arpstandard and circle_num <10000:
					z_arpendeve6 = random.uniform(z_arpendmineve6, z_arpendmaxeve6) 
					deltaz_arpeve6 = abs(z_arpendeve6-zarpstartslineset6[i][j])
					deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
					circle_num+=1
				a_parameter = ((xvector_dauset5[i])**2) + ((yvector_dauset5[i])**2)
				b_parameter = (-2)*(len_dauset5[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset5[i])*(z_arpendeve6 - zarpstartslineset6[i][j])))*(xvector_dauset5[i])
				c_parameter = ((len_dauset5[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset5[i])*(z_arpendeve6 - zarpstartslineset6[i][j])))**2) - (((larp)**2)-((z_arpendeve6 - zarpstartslineset6[i][j])**2))*((yvector_dauset5[i])**2)
				x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset6[i][j]
				x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset6[i][j]
				x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
				x_arpendeve6 = random.choice(x_arpendsmall_big)
				a = len_dauset5[i]*larp*math.cos(math.radians(70))
				b = x_arpendeve6 - (xarpstartslineset6[i][j])
				c = xvector_dauset5[i]
				d = z_arpendeve6 - zarpstartslineset6[i][j]
				e = zvector_dauset5[i]
				g = yvector_dauset5[i]
				f = (a - b*c - d*e)/g
				h = abs(b/f)   
				count+=1
			zarpendseveset6.append(z_arpendeve6)
			deltaz_arpeve6 = z_arpendeve6 - (zarpstartslineset6[i][j])
			deltaz_arpeveset6.append(deltaz_arpeve6)
			xarpendseveset6.append(x_arpendeve6)
			y_arpendeve6 = ((len_dauset5[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset5[i])*(deltaz_arpeve6)))-(xvector_dauset5[i])*(x_arpendeve6-xarpstartslineset6[i][j]))/(yvector_dauset5[i])+yarpstartslineset6[i][j]
			yarpendseveset6.append(y_arpendeve6)
		zarpendslineset6.append(zarpendseveset6)
		deltaz_arplineset6.append(deltaz_arpeveset6)
		zarpends6 = zarpends6 + zarpendseveset6
		deltaz_arps6 = deltaz_arps6 + deltaz_arpeveset6
		zarpendseveset6 = []
		deltaz_arpeveset6 = []
		xarpendslineset6.append(xarpendseveset6)
		xarpends6 = xarpends6 + xarpendseveset6
		xarpendseveset6 = []
		yarpendslineset6.append(yarpendseveset6)
		yarpends6 = yarpends6 + yarpendseveset6
		yarpendseveset6 = []
	del_arps6 = [] 
	for i in range(len(zarpends6)):
		if zarpends6[i] >= 200 or zarpends6[i] <= 0 or yarpends6[i]-yarpstarts6[i]< 0:
			del_arp6 = i
			del_arps6.append(del_arp6)
	del_arps6.reverse() 
	for i in del_arps6:
		del xarpstarts6[i] 
		del yarpstarts6[i]
		del zarpstarts6[i]
		del xarpends6[i]
		del yarpends6[i]
		del zarpends6[i]
		del deltaz_arps6[i]
	del_arps6_80_90degree = [] 
	for i in range(len(zarpends6)):
		delta_x = xarpends6[i]- xarpstarts6[i]
		delta_y = yarpends6[i]- yarpstarts6[i]
		length_xy = (delta_x**2 + delta_y**2)**0.5
		sin_xy = delta_x/length_xy
		abs_sin_xy = abs(sin_xy)
		limit_value = math.sin(math.radians(reduced_xyangle))
		if abs_sin_xy > limit_value:
			del_arp6_80_90degree = i
			del_arps6_80_90degree.append(del_arp6_80_90degree)
	numb_del_arps6_80_90degree = int(2*len(del_arps6_80_90degree)/3) 
	del_2third_arps6_80_90degree = random.sample(del_arps6_80_90degree, numb_del_arps6_80_90degree)
	del_2third_arps6_80_90degree.sort()
	del_2third_arps6_80_90degree.reverse()
	for i in del_2third_arps6_80_90degree:
		del xarpstarts6[i]
		del yarpstarts6[i]
		del zarpstarts6[i]
		del xarpends6[i]
		del yarpends6[i]
		del zarpends6[i]
		del deltaz_arps6[i]
	lendaus6 = [] 
	for i in range(len(xarpends6)):
		lendau6 = random.gauss(mean_filamentlength,50)
		lendaus6.append(lendau6)
	print len(lendaus6)
	print len(deltaz_arps6)
	print len(zarpends6)
	lenratios_dau6_arp6 = [] 
	for i in range(len(lendaus6)):
		lenratio_dau6_arp = (lendaus6[i])/(larp)
		deltaz_dau6 = (deltaz_arps6[i])*(lenratio_dau6_arp)
		z_dau6 = deltaz_dau6 + (zarpends6[i])
		if z_dau6 > 200:
			z_dau6 = 200
			lenratio_dau6_arp = (z_dau6 - zarpends6[i])/(deltaz_arps6[i])
			lenratios_dau6_arp6.append(lenratio_dau6_arp)
		elif z_dau6 < 0:
			z_dau6 = 0
			lenratio_dau6_arp = (z_dau6 - zarpends6[i])/(deltaz_arps6[i])
			lenratios_dau6_arp6.append(lenratio_dau6_arp)
		else:
			lenratios_dau6_arp6.append(lenratio_dau6_arp)
	x_dauends6 = [] 
	y_dauends6 = [] 
	z_dauends6 = [] 
	for i in range(len(lenratios_dau6_arp6)):
		z_dauend6 = (lenratios_dau6_arp6[i])*(deltaz_arps6[i]) + (zarpends6[i])
		x_dauend6 = (lenratios_dau6_arp6[i])*(xarpends6[i] - xarpstarts6[i]) + (xarpends6[i])
		y_dauend6 = (lenratios_dau6_arp6[i])*(yarpends6[i] - yarpstarts6[i]) + (yarpends6[i])
		x_dauends6.append(x_dauend6)
		y_dauends6.append(y_dauend6)
		z_dauends6.append(z_dauend6)
	x_daustarts6 = xarpends6[:] 
	y_daustarts6 = yarpends6[:] 
	z_daustarts6 = zarpends6[:] 
	xvector_dauset6 = []     
	yvector_dauset6 = []    
	zvector_dauset6 = []     
	for i in range(len(x_daustarts6)):
		xvector_dau6 = (x_dauends6[i] - x_daustarts6[i])
		xvector_dauset6.append(xvector_dau6)
		yvector_dau6 = (y_dauends6[i] - y_daustarts6[i])
		yvector_dauset6.append(yvector_dau6)
		zvector_dau6 = (z_dauends6[i] - z_daustarts6[i])
		zvector_dauset6.append(zvector_dau6)
	len_dauset6 = []
	for i in range(len(xvector_dauset6)):
		len_dau6 = (xvector_dauset6[i]**2 + yvector_dauset6[i]**2 + zvector_dauset6[i]**2)**0.5
		len_dauset6.append(len_dau6)
	del_daus6 = []
	for i in range(len(len_dauset6)):
		if len_dauset6[i]<100:
			del_dau=i
			del_daus6.append(del_dau)
	del_daus6.reverse()	
	for i in del_daus6: 
		del len_dauset6[i]
		del x_daustarts6[i]
		del y_daustarts6[i]
		del z_daustarts6[i]
		del x_dauends6[i]
		del y_dauends6[i]
		del z_dauends6[i]
		del xarpstarts6[i] 
		del yarpstarts6[i]
		del zarpstarts6[i]
		del xarpends6[i]
		del yarpends6[i]
		del zarpends6[i]
		del xvector_dauset6[i]
		del yvector_dauset6[i]
		del zvector_dauset6[i]
	arpnumeveset7 = []   
	for i in range(len(x_daustarts6)):
		arpnumeve7 = int(round((len_dauset6[i])/l_densityarp7)) 
		arpnumeveset7.append(arpnumeve7)
	xarpstarts7 = []  
	yarpstarts7 = []  
	zarpstarts7 = [] 
	xarpstartslineset7 = []  
	yarpstartslineset7 = [] 
	zarpstartslineset7 = [] 
	xarpstartseveset7 = []   
	yarpstartseveset7 = [] 
	zarpstartseveset7 = []   
	for i in range(len(arpnumeveset7)):
		for j in range (arpnumeveset7[i]):
			if arpnumeveset7[i]>0:
				arp_k = arp_generate_section/len_dauset6[i]
				lower_limit = (j+1.0)/arpnumeveset7[i] - arp_k
				upper_limit = (j+1.0)/arpnumeveset7[i]
				t = random.uniform(lower_limit, upper_limit)
				xarpstarteve7 = t*(xvector_dauset6 [i])+(x_daustarts6 [i])
				yarpstarteve7 = t*(yvector_dauset6 [i])+(y_daustarts6 [i])
				zarpstarteve7 = t*(zvector_dauset6 [i])+(z_daustarts6 [i])
				xarpstartseveset7.append(xarpstarteve7)
				yarpstartseveset7.append(yarpstarteve7)
				zarpstartseveset7.append(zarpstarteve7)
		xarpstartslineset7.append(xarpstartseveset7)
		xarpstarts7 = xarpstarts7 + xarpstartseveset7
		xarpstartseveset7 =[]
		yarpstartslineset7.append(yarpstartseveset7)
		yarpstarts7 = yarpstarts7 + yarpstartseveset7
		yarpstartseveset7 =[]
		zarpstartslineset7.append(zarpstartseveset7)
		zarpstarts7 = zarpstarts7 + zarpstartseveset7
		zarpstartseveset7 =[]
	zangles7 = []
	for i in range(len(x_daustarts6)):
		zangle7 = math.asin(zvector_dauset6[i]/len_dauset6[i])
		zangles7.append(zangle7)
	thetaz_arpminset7 = []
	thetaz_arpmaxset7 = []
	for i in range(len(zarpstartslineset7)):
		thetaz_arpmin7 = (zangles7[i] - math.radians(70))
		thetaz_arpmax7 = (zangles7[i] + math.radians(70))
		thetaz_arpminset7.append(thetaz_arpmin7)
		thetaz_arpmaxset7.append(thetaz_arpmax7)
	zarpendseveset7 = []    
	zarpendslineset7 = []  
	deltaz_arpeveset7 = []  
	deltaz_arplineset7 = [] 
	zarpends7 = []          
	deltaz_arps7 = []      
	xarpendseveset7 = []   
	xarpendslineset7 = []   
	xarpends7 = []         
	yarpendseveset7 = []   
	yarpendslineset7 = []  
	yarpends7 = []        
	for i in range(len(zarpstartslineset7)):
		deltaz_arpminset7 = larp*(math.sin(thetaz_arpminset7[i]))
		deltaz_arpmaxset7 = larp*(math.sin(thetaz_arpmaxset7[i]))
		for j in range(len(zarpstartslineset7[i])):
			z_arpendmineve7 = (zarpstartslineset7[i][j]) + deltaz_arpminset7 
			z_arpendmaxeve7 = (zarpstartslineset7[i][j]) + deltaz_arpmaxset7 
			z_arpendeve7 = random.uniform(z_arpendmineve7, z_arpendmaxeve7)
			deltaz_arpeve7 = abs(z_arpendeve7-zarpstartslineset7[i][j])
			deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
			circle_num=0
			while deltaz_arpeve7 > deltaz_arpstandard and circle_num <10000:
				z_arpendeve7 = random.uniform(z_arpendmineve7, z_arpendmaxeve7)
				deltaz_arpeve7 = abs(z_arpendeve7-zarpstartslineset7[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num+=1
			a_parameter = ((xvector_dauset6[i])**2) + ((yvector_dauset6[i])**2)
			b_parameter = (-2)*(len_dauset6[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset6[i])*(z_arpendeve7 - zarpstartslineset7[i][j])))*(xvector_dauset6[i])
			c_parameter = ((len_dauset6[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset6[i])*(z_arpendeve7 - zarpstartslineset7[i][j])))**2) - (((larp)**2)-((z_arpendeve7 - zarpstartslineset7[i][j])**2))*((yvector_dauset6[i])**2)
			x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset7[i][j]
			x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset7[i][j]
			x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
			x_arpendeve7 = random.choice(x_arpendsmall_big)
			a = len_dauset6[i]*larp*math.cos(math.radians(70))
			b = x_arpendeve7 - (xarpstartslineset7[i][j])
			c = xvector_dauset6[i]
			d = z_arpendeve7 - zarpstartslineset7[i][j]
			e = zvector_dauset6[i]
			g = yvector_dauset6[i]
			f = (a - b*c - d*e)/g
			h = abs(b/f)   
			count = 0
			while f < 0 or math.tan(xy_arpangle*pi/180)< h and count <10000:  
				z_arpendeve7 = random.uniform(z_arpendmineve7, z_arpendmaxeve7) 
				deltaz_arpeve7 = abs(z_arpendeve7-zarpstartslineset7[i][j])
				deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
				circle_num=0
				while deltaz_arpeve7 > deltaz_arpstandard and circle_num <10000:
					z_arpendeve7 = random.uniform(z_arpendmineve7, z_arpendmaxeve7) 
					deltaz_arpeve7 = abs(z_arpendeve7-zarpstartslineset7[i][j])
					deltaz_arpstandard = larp*math.sin(z_arpangle*pi/180)
					circle_num+=1
				a_parameter = ((xvector_dauset6[i])**2) + ((yvector_dauset6[i])**2)
				b_parameter = (-2)*(len_dauset6[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset6[i])*(z_arpendeve7 - zarpstartslineset7[i][j])))*(xvector_dauset6[i])
				c_parameter = ((len_dauset6[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset6[i])*(z_arpendeve7 - zarpstartslineset7[i][j])))**2) - (((larp)**2)-((z_arpendeve7 - zarpstartslineset7[i][j])**2))*((yvector_dauset6[i])**2)
				x_arpendsmall = ((-b_parameter)-(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset7[i][j]
				x_arpendbig = ((-b_parameter)+(((b_parameter)**2 - 4*a_parameter*c_parameter)**(0.5)))/(2*a_parameter) + xarpstartslineset7[i][j]
				x_arpendsmall_big = [x_arpendsmall, x_arpendbig]
				x_arpendeve7 = random.choice(x_arpendsmall_big)
				a = len_dauset6[i]*larp*math.cos(math.radians(70))
				b = x_arpendeve7 - (xarpstartslineset7[i][j])
				c = xvector_dauset6[i]
				d = z_arpendeve7 - zarpstartslineset7[i][j]
				e = zvector_dauset6[i]
				g = yvector_dauset6[i]
				f = (a - b*c - d*e)/g
				h = abs(b/f)    
				count+=1
			zarpendseveset7.append(z_arpendeve7)
			deltaz_arpeve7 = z_arpendeve7 - (zarpstartslineset7[i][j])
			deltaz_arpeveset7.append(deltaz_arpeve7)
			xarpendseveset7.append(x_arpendeve7)
			y_arpendeve7 = ((len_dauset6[i]*larp*math.cos(math.radians(70)) - ((zvector_dauset6[i])*(deltaz_arpeve7)))-(xvector_dauset6[i])*(x_arpendeve7-xarpstartslineset7[i][j]))/(yvector_dauset6[i])+yarpstartslineset7[i][j]
			yarpendseveset7.append(y_arpendeve7)
		zarpendslineset7.append(zarpendseveset7)
		deltaz_arplineset7.append(deltaz_arpeveset7)
		zarpends7 = zarpends7 + zarpendseveset7
		deltaz_arps7 = deltaz_arps7 + deltaz_arpeveset7
		zarpendseveset7 = []
		deltaz_arpeveset7 = []
		xarpendslineset7.append(xarpendseveset7)
		xarpends7 = xarpends7 + xarpendseveset7
		xarpendseveset7 = []
		yarpendslineset7.append(yarpendseveset7)
		yarpends7 = yarpends7 + yarpendseveset7
		yarpendseveset7 = []
	del_arps7 = [] 
	for i in range(len(zarpends7)):
		if zarpends7[i] >= 200 or zarpends7[i] <= 0 or yarpends7[i]-yarpstarts7[i]< 0:
			del_arp7 = i
			del_arps7.append(del_arp7)
	del_arps7.reverse() 
	for i in del_arps7:
		del xarpstarts7[i]
		del yarpstarts7[i]
		del zarpstarts7[i]
		del xarpends7[i]
		del yarpends7[i]
		del zarpends7[i]
		del deltaz_arps7[i]
	del_arps7_80_90degree = [] 
	for i in range(len(zarpends7)):
		delta_x = xarpends7[i]- xarpstarts7[i]
		delta_y = yarpends7[i]- yarpstarts7[i]
		length_xy = (delta_x**2 + delta_y**2)**0.5
		sin_xy = delta_x/length_xy
		abs_sin_xy = abs(sin_xy)
		limit_value = math.sin(math.radians(reduced_xyangle))
		if abs_sin_xy > limit_value:
			del_arp7_80_90degree = i
			del_arps7_80_90degree.append(del_arp7_80_90degree)
	numb_del_arps7_80_90degree = int(2*len(del_arps7_80_90degree)/3) 
	del_2third_arps7_80_90degree = random.sample(del_arps7_80_90degree, numb_del_arps7_80_90degree)
	del_2third_arps7_80_90degree.sort()
	del_2third_arps7_80_90degree.reverse()
	for i in del_2third_arps7_80_90degree:
		del xarpstarts7[i] 
		del yarpstarts7[i]
		del zarpstarts7[i]
		del xarpends7[i]
		del yarpends7[i]
		del zarpends7[i]
		del deltaz_arps7[i]
	lendaus7 = []
	for i in range(len(xarpends7)):
		lendau7 = random.gauss(mean_filamentlength,50)
		lendaus7.append(lendau7)
	print len(lendaus7)
	print len(deltaz_arps7)
	print len(zarpends7)
	lenratios_dau7_arp7 = [] 
	for i in range(len(lendaus7)):
		lenratio_dau7_arp = (lendaus7[i])/(larp)
		deltaz_dau7 = (deltaz_arps7[i])*(lenratio_dau7_arp)
		z_dau7 = deltaz_dau7 + (zarpends7[i])
		if z_dau7 > 200:
			z_dau7 = 200
			lenratio_dau7_arp = (z_dau7 - zarpends7[i])/(deltaz_arps7[i])
			lenratios_dau7_arp7.append(lenratio_dau7_arp)
		elif z_dau7 < 0:
			z_dau7 = 0
			lenratio_dau7_arp = (z_dau7 - zarpends7[i])/(deltaz_arps7[i])
			lenratios_dau7_arp7.append(lenratio_dau7_arp)
		else:
			lenratios_dau7_arp7.append(lenratio_dau7_arp)
	x_dauends7 = [] 
	y_dauends7 = [] 
	z_dauends7 = [] 
	for i in range(len(lenratios_dau7_arp7)):
		z_dauend7 = (lenratios_dau7_arp7[i])*(deltaz_arps7[i]) + (zarpends7[i])
		x_dauend7 = (lenratios_dau7_arp7[i])*(xarpends7[i] - xarpstarts7[i]) + (xarpends7[i])
		y_dauend7 = (lenratios_dau7_arp7[i])*(yarpends7[i] - yarpstarts7[i]) + (yarpends7[i])
		x_dauends7.append(x_dauend7)
		y_dauends7.append(y_dauend7)
		z_dauends7.append(z_dauend7)
	x_daustarts7 = xarpends7[:] 
	y_daustarts7 = yarpends7[:]
	z_daustarts7 = zarpends7[:]
	xvector_dauset7 = []    
	yvector_dauset7 = []    
	zvector_dauset7 = []    
	for i in range(len(x_daustarts7)):
		xvector_dau7 = (x_dauends7[i] - x_daustarts7[i])
		xvector_dauset7.append(xvector_dau7)
		yvector_dau7 = (y_dauends7[i] - y_daustarts7[i])
		yvector_dauset7.append(yvector_dau7)
		zvector_dau7 = (z_dauends7[i] - z_daustarts7[i])
		zvector_dauset7.append(zvector_dau7)
	len_dauset7 = []
	for i in range(len(xvector_dauset7)):
		len_dau7 = (xvector_dauset7[i]**2 + yvector_dauset7[i]**2 + zvector_dauset7[i]**2)**0.5
		len_dauset7.append(len_dau7)
	del_daus7 = []
	for i in range(len(len_dauset7)):
		if len_dauset7[i]<100:
			del_dau=i
			del_daus7.append(del_dau)
	del_daus7.reverse()	
	for i in del_daus7: 
		del len_dauset7[i]
		del x_daustarts7[i]
		del y_daustarts7[i]
		del z_daustarts7[i]
		del x_dauends7[i]
		del y_dauends7[i]
		del z_dauends7[i]
		del xarpstarts7[i] 
		del yarpstarts7[i]
		del zarpstarts7[i]
		del xarpends7[i]
		del yarpends7[i]
		del zarpends7[i]
		del xvector_dauset7[i]
		del yvector_dauset7[i]
		del zvector_dauset7[i]
	xstarts_filaments_element1 = xmostart1 + x_daustarts1 + x_daustarts2 + x_daustarts3# + x_daustarts4
	xends_filaments_element1 = xmoend1 + x_dauends1 + x_dauends2 + x_dauends3# + x_dauends4
	ystarts_filaments_element1 = ymostart1 + y_daustarts1 + y_daustarts2 + y_daustarts3# + y_daustarts4
	yends_filaments_element1 = ymoend1 + y_dauends1 + y_dauends2 + y_dauends3# + y_dauends4
	zstarts_filaments_element1 = zmostart1 + z_daustarts1 + z_daustarts2 + z_daustarts3# + z_daustarts4
	zends_filaments_element1 = zmoend1 + z_dauends1 + z_dauends2 + z_dauends3# + z_dauends4
	xstarts_arps_element1 = xarpstarts1 + xarpstarts2 + xarpstarts3# + xarpstarts4
	xends_arps_element1 = xarpends1 + xarpends2 + xarpends3# + xarpends4
	ystarts_arps_element1 = yarpstarts1 + yarpstarts2 + yarpstarts3# + yarpstarts4
	yends_arps_element1 = yarpends1 + yarpends2 + yarpends3# + yarpends4
	zstarts_arps_element1 = zarpstarts1 + zarpstarts2 + zarpstarts3# + zarpstarts4
	zends_arps_element1 = zarpends1 + zarpends2 + zarpends3# + zarpends4 
	filaments_length_element1=[]
	filaments_yorientation_element1=[]
	for i in range(len(xstarts_filaments_element1)):
		filament_length_element1= ((xends_filaments_element1[i]-xstarts_filaments_element1[i])**2 + (yends_filaments_element1[i]-ystarts_filaments_element1[i])**2 + (zends_filaments_element1[i]-zstarts_filaments_element1[i])**2)**0.5
		filaments_length_element1.append(filament_length_element1)
		delta_x = xends_filaments_element1[i]-xstarts_filaments_element1[i]
		delta_y = yends_filaments_element1[i]-ystarts_filaments_element1[i]
		delta_z = zstarts_filaments_element1[i]-zstarts_filaments_element1[i] # we need the refletion in xy-plane, so the delta_z have to be zero.
		len_fl = (delta_x**2 + delta_y**2 + delta_z**2)**0.5
		cos_angle_yorientation = (delta_x*0+delta_y*1+delta_z*0)/(len_fl*1)
		if delta_x >=0:
			filament_yorientation_element1 = math.acos(cos_angle_yorientation)*180/3.1415926
			filaments_yorientation_element1.append(filament_yorientation_element1)
		else:
			filament_yorientation_element1 = -math.acos(cos_angle_yorientation)*180/3.1415926
			filaments_yorientation_element1.append(filament_yorientation_element1)
	filaments_totallength_element1=sum(filaments_length_element1)*0.001  # length of all filaments
	filaments_averagelength_element1=filaments_totallength_element1/(len(filaments_length_element1))
	volumefraction=filaments_totallength_element1*1000*(3.1415926*(3.5**2))/(1000*1000*200)
print filaments_totallength_element1
print filaments_averagelength_element1
print filaments_length_element1
print filaments_yorientation_element1
xstarts_filaments_element2 = xstarts_filaments_element1[:]
xends_filaments_element2 = xends_filaments_element1[:]
ystarts_filaments_element2 = [y-1000 for y in ystarts_filaments_element1]
yends_filaments_element2 = [y-1000 for y in yends_filaments_element1]
zstarts_filaments_element2 = zstarts_filaments_element1[:]
zends_filaments_element2 = zends_filaments_element1[:]
xstarts_arps_element2 = xstarts_arps_element1[:]
xends_arps_element2 = xends_arps_element1[:]
ystarts_arps_element2 = [y-1000 for y in ystarts_arps_element1]
yends_arps_element2 = [y-1000 for y in yends_arps_element1]
zstarts_arps_element2 = zstarts_arps_element1[:]
zends_arps_element2 = zends_arps_element1[:]
xstarts_filaments_element3 = [x+1000 for x in xstarts_filaments_element1]
xends_filaments_element3 = [x+1000 for x in xends_filaments_element1]
ystarts_filaments_element3 = [y-1000 for y in ystarts_filaments_element1]
yends_filaments_element3 = [y-1000 for y in yends_filaments_element1]
zstarts_filaments_element3 = zstarts_filaments_element1[:]
zends_filaments_element3 = zends_filaments_element1[:]
xstarts_arps_element3 = [x+1000 for x in xstarts_arps_element1]
xends_arps_element3 = [x+1000 for x in xends_arps_element1]
ystarts_arps_element3 = [y-1000 for y in ystarts_arps_element1]
yends_arps_element3 = [y-1000 for y in yends_arps_element1]
zstarts_arps_element3 = zstarts_arps_element1[:]
zends_arps_element3 = zends_arps_element1[:]
xstarts_filaments_element4 = [x+1000 for x in xstarts_filaments_element1]
xends_filaments_element4 = [x+1000 for x in xends_filaments_element1]
ystarts_filaments_element4 = ystarts_filaments_element1[:]
yends_filaments_element4 = yends_filaments_element1[:]
zstarts_filaments_element4 = zstarts_filaments_element1[:]
zends_filaments_element4 = zends_filaments_element1[:]
xstarts_arps_element4 = [x+1000 for x in xstarts_arps_element1]
xends_arps_element4 = [x+1000 for x in xends_arps_element1]
ystarts_arps_element4 = ystarts_arps_element1[:]
yends_arps_element4 = yends_arps_element1[:]
zstarts_arps_element4 = zstarts_arps_element1[:]
zends_arps_element4 = zends_arps_element1[:]
xstarts_filaments_element5 = [x+1000 for x in xstarts_filaments_element1]
xends_filaments_element5 = [x+1000 for x in xends_filaments_element1]
ystarts_filaments_element5 = [y+1000 for y in ystarts_filaments_element1]
yends_filaments_element5 = [y+1000 for y in yends_filaments_element1]
zstarts_filaments_element5 = zstarts_filaments_element1[:]
zends_filaments_element5 = zends_filaments_element1[:]
xstarts_arps_element5 = [x+1000 for x in xstarts_arps_element1]
xends_arps_element5 = [x+1000 for x in xends_arps_element1]
ystarts_arps_element5 = [y+1000 for y in ystarts_arps_element1]
yends_arps_element5 = [y+1000 for y in yends_arps_element1]
zstarts_arps_element5 = zstarts_arps_element1[:]
zends_arps_element5 = zends_arps_element1[:]
xstarts_filaments_element6 = xstarts_filaments_element1[:]
xends_filaments_element6 = xends_filaments_element1[:]
ystarts_filaments_element6 = [y+1000 for y in ystarts_filaments_element1]
yends_filaments_element6 = [y+1000 for y in yends_filaments_element1]
zstarts_filaments_element6 = zstarts_filaments_element1[:]
zends_filaments_element6 = zends_filaments_element1[:]
xstarts_arps_element6 = xstarts_arps_element1[:]
xends_arps_element6 = xends_arps_element1[:]
ystarts_arps_element6 = [y+1000 for y in ystarts_arps_element1]
yends_arps_element6 = [y+1000 for y in yends_arps_element1]
zstarts_arps_element6 = zstarts_arps_element1[:]
zends_arps_element6 = zends_arps_element1[:]
xstarts_filaments_element7 = [x-1000 for x in xstarts_filaments_element1]
xends_filaments_element7 = [x-1000 for x in xends_filaments_element1]
ystarts_filaments_element7 = [y+1000 for y in ystarts_filaments_element1]
yends_filaments_element7 = [y+1000 for y in yends_filaments_element1]
zstarts_filaments_element7 = zstarts_filaments_element1[:]
zends_filaments_element7 = zends_filaments_element1[:]
xstarts_arps_element7 = [x-1000 for x in xstarts_arps_element1]
xends_arps_element7 = [x-1000 for x in xends_arps_element1]
ystarts_arps_element7 = [y+1000 for y in ystarts_arps_element1]
yends_arps_element7 = [y+1000 for y in yends_arps_element1]
zstarts_arps_element7 = zstarts_arps_element1[:]
zends_arps_element7 = zends_arps_element1[:]
xstarts_filaments_element8 = [x-1000 for x in xstarts_filaments_element1]
xends_filaments_element8 = [x-1000 for x in xends_filaments_element1]
ystarts_filaments_element8 = ystarts_filaments_element1[:]
yends_filaments_element8 = yends_filaments_element1[:]
zstarts_filaments_element8 = zstarts_filaments_element1[:]
zends_filaments_element8 = zends_filaments_element1[:]
xstarts_arps_element8 = [x-1000 for x in xstarts_arps_element1]
xends_arps_element8 = [x-1000 for x in xends_arps_element1]
ystarts_arps_element8 = ystarts_arps_element1[:]
yends_arps_element8 = yends_arps_element1[:]
zstarts_arps_element8 = zstarts_arps_element1[:]
zends_arps_element8 = zends_arps_element1[:]
xstarts_filaments_element9 = [x-1000 for x in xstarts_filaments_element1]
xends_filaments_element9 = [x-1000 for x in xends_filaments_element1]
ystarts_filaments_element9 = [y-1000 for y in ystarts_filaments_element1]
yends_filaments_element9 = [y-1000 for y in yends_filaments_element1]
zstarts_filaments_element9 = zstarts_filaments_element1[:]
zends_filaments_element9 = zends_filaments_element1[:]
xstarts_arps_element9 = [x-1000 for x in xstarts_arps_element1]
xends_arps_element9 = [x-1000 for x in xends_arps_element1]
ystarts_arps_element9 = [y-1000 for y in ystarts_arps_element1]
yends_arps_element9 = [y-1000 for y in yends_arps_element1]
zstarts_arps_element9 = zstarts_arps_element1[:]
zends_arps_element9 = zends_arps_element1[:]
x_flinestarts1_9s = xstarts_filaments_element1 + xstarts_filaments_element2 + xstarts_filaments_element3 + xstarts_filaments_element4 + xstarts_filaments_element5 + xstarts_filaments_element6 +\
					xstarts_filaments_element7 + xstarts_filaments_element8 + xstarts_filaments_element9
y_flinestarts1_9s = ystarts_filaments_element1 + ystarts_filaments_element2 + ystarts_filaments_element3 + ystarts_filaments_element4 + ystarts_filaments_element5 + ystarts_filaments_element6 +\
					ystarts_filaments_element7 + ystarts_filaments_element8 + ystarts_filaments_element9
z_flinestarts1_9s = zstarts_filaments_element1 + zstarts_filaments_element2 + zstarts_filaments_element3 + zstarts_filaments_element4 + zstarts_filaments_element5 + zstarts_filaments_element6 +\
					zstarts_filaments_element7 + zstarts_filaments_element8 + zstarts_filaments_element9
x_flineends1_9s = xends_filaments_element1 + xends_filaments_element2 + xends_filaments_element3 + xends_filaments_element4 + xends_filaments_element5 + xends_filaments_element6 +\
				  xends_filaments_element7 + xends_filaments_element8 + xends_filaments_element9
y_flineends1_9s = yends_filaments_element1 + yends_filaments_element2 + yends_filaments_element3 + yends_filaments_element4 + yends_filaments_element5 + yends_filaments_element6 +\
				  yends_filaments_element7 + yends_filaments_element8 + yends_filaments_element9
z_flineends1_9s = zends_filaments_element1 + zends_filaments_element2 + zends_filaments_element3 + zends_filaments_element4 + zends_filaments_element5 + zends_filaments_element6 +\
				  zends_filaments_element7 + zends_filaments_element8 + zends_filaments_element9
x_arplinestarts1_9s = xstarts_arps_element1 + xstarts_arps_element2 + xstarts_arps_element3 + xstarts_arps_element4 + xstarts_arps_element5 + xstarts_arps_element6 +\
					  xstarts_arps_element7 + xstarts_arps_element8 + xstarts_arps_element9						  
y_arplinestarts1_9s = ystarts_arps_element1 + ystarts_arps_element2 + ystarts_arps_element3 + ystarts_arps_element4 + ystarts_arps_element5 + ystarts_arps_element6 +\
					  ystarts_arps_element7 + ystarts_arps_element8 + ystarts_arps_element9
z_arplinestarts1_9s = zstarts_arps_element1 + zstarts_arps_element2 + zstarts_arps_element3 + zstarts_arps_element4 + zstarts_arps_element5 + zstarts_arps_element6 +\
					  zstarts_arps_element7 + zstarts_arps_element8 + zstarts_arps_element9
x_arplineends1_9s = xends_arps_element1 + xends_arps_element2 + xends_arps_element3 + xends_arps_element4 + xends_arps_element5 + xends_arps_element6 +\
					xends_arps_element7 + xends_arps_element8 + xends_arps_element9
y_arplineends1_9s = yends_arps_element1 + yends_arps_element2 + yends_arps_element3 + yends_arps_element4 + yends_arps_element5 + yends_arps_element6 +\
					yends_arps_element7 + yends_arps_element8 + yends_arps_element9
z_arplineends1_9s = zends_arps_element1 + zends_arps_element2 + zends_arps_element3 + zends_arps_element4 + zends_arps_element5 + zends_arps_element6 +\
					zends_arps_element7 + zends_arps_element8 + zends_arps_element9
x_flinestarts2_9s = x_flinestarts1_9s[:]
y_flinestarts2_9s = y_flinestarts1_9s[:]
z_flinestarts2_9s = z_flinestarts1_9s[:]
x_flineends2_9s = x_flineends1_9s[:]
y_flineends2_9s = y_flineends1_9s[:]
z_flineends2_9s = z_flineends1_9s[:]
x_flinestarts3_9s = x_flinestarts2_9s[:]
y_flinestarts3_9s = y_flinestarts2_9s[:]
z_flinestarts3_9s = z_flinestarts2_9s[:]
x_flineends3_9s = x_flineends2_9s[:]
y_flineends3_9s = y_flineends2_9s[:]
z_flineends3_9s = z_flineends2_9s[:]
delta_x_flines2_9s = []
delta_y_flines2_9s = []
delta_z_flines2_9s = []
for i in range(len(x_flinestarts1_9s)):
	delta_x_fline2_9s = x_flineends2_9s[i] - x_flinestarts2_9s[i] 
	delta_y_fline2_9s = y_flineends2_9s[i] - y_flinestarts2_9s[i]
	delta_z_fline2_9s = z_flineends2_9s[i] - z_flinestarts2_9s[i]
	delta_x_flines2_9s.append(delta_x_fline2_9s)
	delta_y_flines2_9s.append(delta_y_fline2_9s)
	delta_z_flines2_9s.append(delta_z_fline2_9s)
len_lines2_9s = [] 
for i in range(len(delta_x_flines2_9s)):
	len_line2_9s = (delta_x_flines2_9s[i]**2 + delta_y_flines2_9s[i]**2 + delta_z_flines2_9s[i]**2)**0.5 
	len_lines2_9s.append(len_line2_9s)
delta_x_flines3_9s = delta_x_flines2_9s[:]
delta_y_flines3_9s = delta_y_flines2_9s[:]
delta_z_flines3_9s = delta_z_flines2_9s[:]
len_lines3_9s = len_lines2_9s[:]
x_filinestarts1_9s = []
y_filinestarts1_9s = [] 
z_filinestarts1_9s = [] 
x_filineends1_9s = []
y_filineends1_9s = []
z_filineends1_9s = [] 
fl_index_fistarts = [] 
fl_index_fiends = [] 
x_ailinestarts1_9s = [] 
y_ailinestarts1_9s = []
z_ailinestarts1_9s = []
x_ailineends1_9s = []
y_ailineends1_9s = [] 
z_ailineends1_9s = [] 
fl_index_aistarts = [] 
fl_index_aiends = [] 
x_etlinestarts1_9s = [] 
y_etlinestarts1_9s = []
z_etlinestarts1_9s = [] 
x_etlineends1_9s = [] 
y_etlineends1_9s = [] 
z_etlineends1_9s = [] 
fl_index_etstarts = []
fl_index_etends = []
for i in range(len(len_lines2_9s)):
	for j in range(len(len_lines3_9s)):	
		if i < j:
			theta_lines = (delta_x_flines2_9s[i]*delta_x_flines3_9s[j]+delta_y_flines2_9s[i]*delta_y_flines3_9s[j]+delta_z_flines2_9s[i]*delta_z_flines3_9s[j])/((len_lines2_9s[i])*(len_lines3_9s[j]))
			k = theta_lines
			a = (delta_x_flines2_9s[i])*(delta_x_flines3_9s[j])+(delta_y_flines2_9s[i])*(delta_y_flines3_9s[j])+(delta_z_flines2_9s[i])*(delta_z_flines3_9s[j])
			bi = delta_x_flines2_9s[i]*(x_flinestarts2_9s[i]-x_flinestarts3_9s[j])+delta_y_flines2_9s[i]*(y_flinestarts2_9s[i]-y_flinestarts3_9s[j])\
			+delta_z_flines2_9s[i]*(z_flinestarts2_9s[i]-z_flinestarts3_9s[j])
			bj = delta_x_flines2_9s[j]*(x_flinestarts3_9s[j]-x_flinestarts2_9s[i])+delta_y_flines2_9s[j]*(y_flinestarts3_9s[j]-y_flinestarts2_9s[i])\
			+delta_z_flines2_9s[j]*(z_flinestarts3_9s[j]-z_flinestarts2_9s[i])
			t = (a*bi+bj*len_lines2_9s[i])/(len_lines2_9s[i]*len_lines3_9s[j]-(a**2))
			s = (a*t+bi)/len_lines2_9s[i]
			if math.cos(math.radians(100)) <= k < math.cos(math.radians(70.1)): 
				if 0<=s<=1 and 0<=t<=1:  
					x_fipoint1_9s = s*delta_x_flines2_9s[i]+x_flinestarts2_9s[i] # x-start coordinate
					y_fipoint1_9s = s*delta_y_flines2_9s[i]+y_flinestarts2_9s[i] # y-start coordinate
					z_fipoint1_9s = s*delta_z_flines2_9s[i]+z_flinestarts2_9s[i] # z-start coordinate
					x_fipoint2_9s = t*delta_x_flines3_9s[j]+x_flinestarts3_9s[j] # x-end coordinate
					y_fipoint2_9s = t*delta_y_flines3_9s[j]+y_flinestarts3_9s[j] # y-end coordinate
					z_fipoint2_9s = t*delta_z_flines3_9s[j]+z_flinestarts3_9s[j] # z-end coordinate
					delta_x_fi = x_fipoint2_9s - x_fipoint1_9s
					delta_y_fi = y_fipoint2_9s - y_fipoint1_9s
					delta_z_fi = z_fipoint2_9s - z_fipoint1_9s
					r = ((delta_x_fi**2)+(delta_y_fi**2)+(delta_z_fi**2))**0.5
					if 30<=r<=150:
						x_filinestarts1_9s.append(x_fipoint1_9s)
						y_filinestarts1_9s.append(y_fipoint1_9s)
						z_filinestarts1_9s.append(z_fipoint1_9s)
						x_filineends1_9s.append(x_fipoint2_9s)
						y_filineends1_9s.append(y_fipoint2_9s)
						z_filineends1_9s.append(z_fipoint2_9s)
						fl_index_fistart = i
						fl_index_fiend = j
						fl_index_fistarts.append(fl_index_fistart)
						fl_index_fiends.append(fl_index_fiend)
					elif r<30:
						a_coef = len_lines3_9s[j]**2
						b_coef = 2*(delta_x_fi*delta_x_flines3_9s[j] + delta_y_fi*delta_y_flines3_9s[j] + delta_z_fi*delta_z_flines3_9s[j])
						c_coef = r**2-30**2
						p=numpy.poly1d([a_coef,b_coef,c_coef])
						roots_k = p.r
						root_k1 = roots_k[0]
						root_k2 = roots_k[1]
						k1_online = t+root_k1 # for to judge if the point is on the line of flinestarts3_9s[j]
						k2_online = t+root_k2 # for to judge if the point is on the line of flinestarts3_9s[j]
						if 0<=k1_online<=1:
							x_fipoint2_9s = (t+root_k1)*delta_x_flines3_9s[j]+x_flinestarts3_9s[j] # x-end coordinate
							y_fipoint2_9s = (t+root_k1)*delta_y_flines3_9s[j]+y_flinestarts3_9s[j] # y-end coordinate
							z_fipoint2_9s = (t+root_k1)*delta_z_flines3_9s[j]+z_flinestarts3_9s[j] # z-end coordinate
							x_filinestarts1_9s.append(x_fipoint1_9s)
							y_filinestarts1_9s.append(y_fipoint1_9s)
							z_filinestarts1_9s.append(z_fipoint1_9s)
							x_filineends1_9s.append(x_fipoint2_9s)
							y_filineends1_9s.append(y_fipoint2_9s)
							z_filineends1_9s.append(z_fipoint2_9s)
							fl_index_fistart = i
							fl_index_fiend = j
							fl_index_fistarts.append(fl_index_fistart)
							fl_index_fiends.append(fl_index_fiend)
						elif 0<=k2_online<=1:
							x_fipoint2_9s = (t+root_k2)*delta_x_flines3_9s[j]+x_flinestarts3_9s[j] # x-end coordinate
							y_fipoint2_9s = (t+root_k2)*delta_y_flines3_9s[j]+y_flinestarts3_9s[j] # y-end coordinate
							z_fipoint2_9s = (t+root_k2)*delta_z_flines3_9s[j]+z_flinestarts3_9s[j] # z-end coordinate
							x_filinestarts1_9s.append(x_fipoint1_9s)
							y_filinestarts1_9s.append(y_fipoint1_9s)
							z_filinestarts1_9s.append(z_fipoint1_9s)
							x_filineends1_9s.append(x_fipoint2_9s)
							y_filineends1_9s.append(y_fipoint2_9s)
							z_filineends1_9s.append(z_fipoint2_9s)
							fl_index_fistart = i
							fl_index_fiend = j
							fl_index_fistarts.append(fl_index_fistart)
							fl_index_fiends.append(fl_index_fiend)
						else:
							a=1
					else:
						a=1
			elif abs(k - math.cos(math.radians(70)))>10e-5:
				if 0<=s<=1 and 0<=t<=1: 
					x_aipoint1_9s = s*delta_x_flines2_9s[i]+x_flinestarts2_9s[i]
					y_aipoint1_9s = s*delta_y_flines2_9s[i]+y_flinestarts2_9s[i]
					z_aipoint1_9s = s*delta_z_flines2_9s[i]+z_flinestarts2_9s[i]
					x_aipoint2_9s = t*delta_x_flines3_9s[j]+x_flinestarts3_9s[j]
					y_aipoint2_9s = t*delta_y_flines3_9s[j]+y_flinestarts3_9s[j]
					z_aipoint2_9s = t*delta_z_flines3_9s[j]+z_flinestarts3_9s[j]
					delta_x_ai = x_aipoint2_9s - x_aipoint1_9s
					delta_y_ai = y_aipoint2_9s - y_aipoint1_9s
					delta_z_ai = z_aipoint2_9s - z_aipoint1_9s
					r = ((delta_x_ai**2)+(delta_y_ai**2)+(delta_z_ai**2))**0.5
					if 24<=r<=40:
						x_ailinestarts1_9s.append(x_aipoint1_9s)
						y_ailinestarts1_9s.append(y_aipoint1_9s)
						z_ailinestarts1_9s.append(z_aipoint1_9s)
						x_ailineends1_9s.append(x_aipoint2_9s)
						y_ailineends1_9s.append(y_aipoint2_9s)
						z_ailineends1_9s.append(z_aipoint2_9s)
						fl_index_aistart = i
						fl_index_aiend = j
						fl_index_aistarts.append(fl_index_aistart)
						fl_index_aiends.append(fl_index_aiend)
					elif r<24:
						a_coef = len_lines3_9s[j]**2
						b_coef = 2*(delta_x_ai*delta_x_flines3_9s[j] + delta_y_ai*delta_y_flines3_9s[j] + delta_z_ai*delta_z_flines3_9s[j])
						c_coef = r**2-24**2
						p=numpy.poly1d([a_coef,b_coef,c_coef])
						roots_k = p.r
						root_k1 = roots_k[0]
						root_k2 = roots_k[1]
						k1_online = t+root_k1 # for to judge if the point is on the line of flinestarts3_9s[j]
						k2_online = t+root_k2 # for to judge if the point is on the line of flinestarts3_9s[j]
						if 0<=k1_online<=1:
							x_aipoint2_9s = (t+root_k1)*delta_x_flines3_9s[j]+x_flinestarts3_9s[j] # x-end coordinate
							y_aipoint2_9s = (t+root_k1)*delta_y_flines3_9s[j]+y_flinestarts3_9s[j] # y-end coordinate
							z_aipoint2_9s = (t+root_k1)*delta_z_flines3_9s[j]+z_flinestarts3_9s[j] # z-end coordinate
							x_ailinestarts1_9s.append(x_aipoint1_9s)
							y_ailinestarts1_9s.append(y_aipoint1_9s)
							z_ailinestarts1_9s.append(z_aipoint1_9s)
							x_ailineends1_9s.append(x_aipoint2_9s)
							y_ailineends1_9s.append(y_aipoint2_9s)
							z_ailineends1_9s.append(z_aipoint2_9s)
							fl_index_aistart = i
							fl_index_aiend = j
							fl_index_aistarts.append(fl_index_aistart)
							fl_index_aiends.append(fl_index_aiend)
						elif 0<=k2_online<=1:
							x_aipoint2_9s = (t+root_k2)*delta_x_flines3_9s[j]+x_flinestarts3_9s[j] # x-end coordinate
							y_aipoint2_9s = (t+root_k2)*delta_y_flines3_9s[j]+y_flinestarts3_9s[j] # y-end coordinate
							z_aipoint2_9s = (t+root_k2)*delta_z_flines3_9s[j]+z_flinestarts3_9s[j] # z-end coordinate
							x_ailinestarts1_9s.append(x_aipoint1_9s)
							y_ailinestarts1_9s.append(y_aipoint1_9s)
							z_ailinestarts1_9s.append(z_aipoint1_9s)
							x_ailineends1_9s.append(x_aipoint2_9s)
							y_ailineends1_9s.append(y_aipoint2_9s)
							z_ailineends1_9s.append(z_aipoint2_9s)
							fl_index_aistart = i
							fl_index_aiend = j
							fl_index_aistarts.append(fl_index_aistart)
							fl_index_aiends.append(fl_index_aiend)
						else:
							a=1
					else:
						a=1
			else:
				a=1
			if 0<=s<=1 and 0<=t<=1: # for the entanglement points
				x_etpoint1_9s = s*delta_x_flines2_9s[i]+x_flinestarts2_9s[i]
				y_etpoint1_9s = s*delta_y_flines2_9s[i]+y_flinestarts2_9s[i]
				z_etpoint1_9s = s*delta_z_flines2_9s[i]+z_flinestarts2_9s[i]
				x_etpoint2_9s = t*delta_x_flines3_9s[j]+x_flinestarts3_9s[j]
				y_etpoint2_9s = t*delta_y_flines3_9s[j]+y_flinestarts3_9s[j]
				z_etpoint2_9s = t*delta_z_flines3_9s[j]+z_flinestarts3_9s[j]
				delta_x_et = x_etpoint2_9s - x_etpoint1_9s
				delta_y_et = y_etpoint2_9s - y_etpoint1_9s
				delta_z_et = z_etpoint2_9s - z_etpoint1_9s
				r = ((delta_x_et**2)+(delta_y_et**2)+(delta_z_et**2))**0.5
				if r<=7:
					x_etlinestarts1_9s.append(x_etpoint1_9s)
					y_etlinestarts1_9s.append(y_etpoint1_9s)
					z_etlinestarts1_9s.append(z_etpoint1_9s)
					x_etlineends1_9s.append(x_etpoint2_9s)
					y_etlineends1_9s.append(y_etpoint2_9s)
					z_etlineends1_9s.append(z_etpoint2_9s)
					fl_index_etstart = i
					fl_index_etend = j
					fl_index_etstarts.append(fl_index_etstart)
					fl_index_etends.append(fl_index_etend)
				else:
					a=1
			else:
				a=1
		else:
			a=2
for i in range(len(fl_index_fistarts)):
	start_i = fl_index_fistarts[i] 
	end_i = fl_index_fiends[i] 
	s_delta_xplus_fline2_9s = x_flineends2_9s[start_i] - x_filinestarts1_9s[i] # the x-distance from the filamin start point to the end of filament
	s_delta_yplus_fline2_9s = y_flineends2_9s[start_i] - y_filinestarts1_9s[i] # the y-distance from the filamin start point to the end of filament
	s_delta_zplus_fline2_9s = z_flineends2_9s[start_i] - z_filinestarts1_9s[i] # the z-distance from the filamin start point to the end of filament
	s_delta_plus_fline2_9s = (s_delta_xplus_fline2_9s**2 + s_delta_yplus_fline2_9s**2 + s_delta_zplus_fline2_9s**2)**0.5 # the distance from the filamin start point to the end of filament
	num_startplus = int(s_delta_plus_fline2_9s/space_fis) 
	s_delta_xminus_fline2_9s = x_flinestarts2_9s[start_i] - x_filinestarts1_9s[i] # the x-distance from the filamin start point to the start of filament
	s_delta_yminus_fline2_9s = y_flinestarts2_9s[start_i] - y_filinestarts1_9s[i] # the y-distance from the filamin start point to the start of filament
	s_delta_zminus_fline2_9s = z_flinestarts2_9s[start_i] - z_filinestarts1_9s[i] # the z-distance from the filamin start point to the start of filament
	s_delta_minus_fline2_9s = (s_delta_xminus_fline2_9s**2 + s_delta_yminus_fline2_9s**2 + s_delta_zminus_fline2_9s**2)**0.5 
	num_startminus = int(s_delta_minus_fline2_9s/space_fis) 
	e_delta_xplus_fline2_9s = x_flineends2_9s[end_i] - x_filineends1_9s[i] # the x-distance from the filamin end point to the end of filament
	e_delta_yplus_fline2_9s = y_flineends2_9s[end_i] - y_filineends1_9s[i] # the y-distance from the filamin end point to the end of filament
	e_delta_zplus_fline2_9s = z_flineends2_9s[end_i] - z_filineends1_9s[i] # the z-distance from the filamin end point to the end of filament
	e_delta_plus_fline2_9s = (e_delta_xplus_fline2_9s**2 + e_delta_yplus_fline2_9s**2 + e_delta_zplus_fline2_9s**2)**0.5  # the distance from the filamin end point to the end of filament
	num_endplus = int(e_delta_plus_fline2_9s/space_fis)
	e_delta_xminus_fline2_9s = x_flinestarts2_9s[end_i] - x_filineends1_9s[i] # the x-distance from the filamin end point to the start of filament
	e_delta_yminus_fline2_9s = y_flinestarts2_9s[end_i] - y_filineends1_9s[i] # the y-distance from the filamin end point to the start of filament
	e_delta_zminus_fline2_9s = z_flinestarts2_9s[end_i] - z_filineends1_9s[i] # the z-distance from the filamin end point to the start of filament
	e_delta_minus_fline2_9s = (e_delta_xminus_fline2_9s**2 + e_delta_yminus_fline2_9s**2 + e_delta_zminus_fline2_9s**2)**0.5  # the distance from the filamin end point to the start of filament
	num_endminus = int(e_delta_minus_fline2_9s/space_fis) 
	list_num_plus = [num_startplus, num_endplus] 
	list_num_plus.sort()
	num_plus = list_num_plus[0]
	list_num_minus = [num_startminus, num_endminus]
	list_num_minus.sort()
	num_minus = list_num_minus[0]
	k_plus_s = []
	k_minus_s = []
	for j in range(num_plus+1):
		if j > 0:
			k_plus = j
			k_plus_s.append(k_plus)
	for j in range(num_minus+1):
		if j > 0:
			k_minus = -j
			k_minus_s.append(k_minus)
	k_minus_plus_s = k_minus_s + k_plus_s
	space_fi_sfactor_fl = ((space_fis**2)/(len_lines2_9s[start_i]**2))**0.5 # the factor of 36 distance in the start filament
	space_fi_efactor_fl = ((space_fis**2)/(len_lines2_9s[end_i]**2))**0.5 # the factor of 36 distance in the end filament
	for j in k_minus_plus_s:
		x_fi_start = x_filinestarts1_9s[i] + j*space_fi_sfactor_fl * delta_x_flines2_9s[start_i] # to add 36nm in x direction toward the plus end of the start filament
		y_fi_start = y_filinestarts1_9s[i] + j*space_fi_sfactor_fl * delta_y_flines2_9s[start_i] # to add 36nm in y direction toward the plus end of the start filament
		z_fi_start = z_filinestarts1_9s[i] + j*space_fi_sfactor_fl * delta_z_flines2_9s[start_i] # to add 36nm in y direction toward the plus end of the start filament
		x_fi_end = x_filineends1_9s[i] + j*space_fi_efactor_fl * delta_x_flines2_9s[end_i] # to add 36nm in x direction toward the plus end of the end filament
		y_fi_end = y_filineends1_9s[i] + j*space_fi_efactor_fl * delta_y_flines2_9s[end_i] # to add 36nm in y direction toward the plus end of the end filament
		z_fi_end = z_filineends1_9s[i] + j*space_fi_efactor_fl * delta_z_flines2_9s[end_i] # to add 36nm in y direction toward the plus end of the end filament
		r = ((x_fi_end-x_fi_start)**2 + (y_fi_end-y_fi_start)**2 + (z_fi_end-z_fi_start)**2)**0.5
		if 36<r<=150:
			x_filinestarts1_9s.append(x_fi_start)
			y_filinestarts1_9s.append(y_fi_start)
			z_filinestarts1_9s.append(z_fi_start)
			x_filineends1_9s.append(x_fi_end)
			y_filineends1_9s.append(y_fi_end)
			z_filineends1_9s.append(z_fi_end)
for i in range(len(fl_index_aistarts)):
	start_i = fl_index_aistarts[i] 
	end_i = fl_index_aiends[i] 
	s_delta_xplus_fline2_9s = x_flineends2_9s[start_i] - x_ailinestarts1_9s[i] # the x-distance from the actinin start point to the end of filament
	s_delta_yplus_fline2_9s = y_flineends2_9s[start_i] - y_ailinestarts1_9s[i] # the y-distance from the actinin start point to the end of filament
	s_delta_zplus_fline2_9s = z_flineends2_9s[start_i] - z_ailinestarts1_9s[i] # the z-distance from the actinin start point to the end of filament
	s_delta_plus_fline2_9s = (s_delta_xplus_fline2_9s**2 + s_delta_yplus_fline2_9s**2 + s_delta_zplus_fline2_9s**2)**0.5 # the distance from the actinin start point to the end of filament
	num_startplus = int(s_delta_plus_fline2_9s/space_ais) 
	s_delta_xminus_fline2_9s = x_flinestarts2_9s[start_i] - x_ailinestarts1_9s[i] # the x-distance from the actinin start point to the start of filament
	s_delta_yminus_fline2_9s = y_flinestarts2_9s[start_i] - y_ailinestarts1_9s[i] # the y-distance from the actinin start point to the start of filament
	s_delta_zminus_fline2_9s = z_flinestarts2_9s[start_i] - z_ailinestarts1_9s[i] # the z-distance from the actinin start point to the start of filament
	s_delta_minus_fline2_9s = (s_delta_xminus_fline2_9s**2 + s_delta_yminus_fline2_9s**2 + s_delta_zminus_fline2_9s**2)**0.5 # the distance from the actinin start point to the start of filament
	num_startminus = int(s_delta_minus_fline2_9s/space_ais) 
	e_delta_xplus_fline2_9s = x_flineends2_9s[end_i] - x_ailineends1_9s[i] # the x-distance from the actinin end point to the end of filament
	e_delta_yplus_fline2_9s = y_flineends2_9s[end_i] - y_ailineends1_9s[i] # the y-distance from the actinin end point to the end of filament
	e_delta_zplus_fline2_9s = z_flineends2_9s[end_i] - z_ailineends1_9s[i] # the z-distance from the actinin end point to the end of filament
	e_delta_plus_fline2_9s = (e_delta_xplus_fline2_9s**2 + e_delta_yplus_fline2_9s**2 + e_delta_zplus_fline2_9s**2)**0.5  # the distance from the actinin end point to the end of filament
	num_endplus = int(e_delta_plus_fline2_9s/space_ais) 
	e_delta_xminus_fline2_9s = x_flinestarts2_9s[end_i] - x_ailineends1_9s[i] # the x-distance from the actinin end point to the start of filament
	e_delta_yminus_fline2_9s = y_flinestarts2_9s[end_i] - y_ailineends1_9s[i] # the y-distance from the actinin end point to the start of filament
	e_delta_zminus_fline2_9s = z_flinestarts2_9s[end_i] - z_ailineends1_9s[i] # the z-distance from the actinin end point to the start of filament
	e_delta_minus_fline2_9s = (e_delta_xminus_fline2_9s**2 + e_delta_yminus_fline2_9s**2 + e_delta_zminus_fline2_9s**2)**0.5  # the distance from the actinin end point to the start of filament
	num_endminus = int(e_delta_minus_fline2_9s/space_ais) 
	list_num_plus = [num_startplus, num_endplus] 
	list_num_plus.sort()
	num_plus = list_num_plus[0]
	list_num_minus = [num_startminus, num_endminus]
	list_num_minus.sort()
	num_minus = list_num_minus[0]
	k_plus_s = []
	k_minus_s = []
	for j in range(num_plus+1):
		if j > 0:
			k_plus = j
			k_plus_s.append(k_plus)
	
	for j in range(num_minus+1):
		if j > 0:
			k_minus = -j
			k_minus_s.append(k_minus)		
	k_minus_plus_s = k_minus_s + k_plus_s
	space_ai_sfactor_fl = ((space_ais**2)/(len_lines2_9s[start_i]**2))**0.5 # the factor of 36 distance in the start filament
	space_ai_efactor_fl = ((space_ais**2)/(len_lines2_9s[end_i]**2))**0.5 # the factor of 36 distance in the end filament
	for j in k_minus_plus_s:
		x_ai_start = x_ailinestarts1_9s[i] + j*space_ai_sfactor_fl * delta_x_flines2_9s[start_i] # to add 36nm in x direction toward the plus end of the start filament
		y_ai_start = y_ailinestarts1_9s[i] + j*space_ai_sfactor_fl * delta_y_flines2_9s[start_i] # to add 36nm in y direction toward the plus end of the start filament
		z_ai_start = z_ailinestarts1_9s[i] + j*space_ai_sfactor_fl * delta_z_flines2_9s[start_i] # to add 36nm in y direction toward the plus end of the start filament
		x_ai_end = x_ailineends1_9s[i] + j*space_ai_efactor_fl * delta_x_flines2_9s[end_i] # to add 36nm in x direction toward the plus end of the end filament
		y_ai_end = y_ailineends1_9s[i] + j*space_ai_efactor_fl * delta_y_flines2_9s[end_i] # to add 36nm in y direction toward the plus end of the end filament
		z_ai_end = z_ailineends1_9s[i] + j*space_ai_efactor_fl * delta_z_flines2_9s[end_i] # to add 36nm in y direction toward the plus end of the end filament
		r = ((x_ai_end-x_ai_start)**2 + (y_ai_end-y_ai_start)**2 + (z_ai_end-z_ai_start)**2)**0.5
		if 18<r<=36:
			x_ailinestarts1_9s.append(x_ai_start)
			y_ailinestarts1_9s.append(y_ai_start)
			z_ailinestarts1_9s.append(z_ai_start)
			x_ailineends1_9s.append(x_ai_end)
			y_ailineends1_9s.append(y_ai_end)
			z_ailineends1_9s.append(z_ai_end)
for i in range(len(x_flinestarts1_9s)):
	if y_flineends1_9s[i] >= y_flinestarts1_9s[i]: # 判断和确定区间
		y_big = y_flineends1_9s[i]+0
		y_small = y_flinestarts1_9s[i]+0
	else:
		y_big = y_flinestarts1_9s[i]+0
		y_small = y_flineends1_9s[i]+0
	if x_flineends1_9s[i] >= x_flinestarts1_9s[i]:
		x_big = x_flineends1_9s[i]+0
		x_small = x_flinestarts1_9s[i]+0
	else:
		x_big = x_flinestarts1_9s[i]+0
		x_small = x_flineends1_9s[i]+0
	delta_x = x_flineends1_9s[i] - x_flinestarts1_9s[i]
	delta_y = y_flineends1_9s[i] - y_flinestarts1_9s[i]
	delta_z = z_flineends1_9s[i] - z_flinestarts1_9s[i]
	y_x0000 = delta_y*(0-x_flinestarts1_9s[i])/delta_x+y_flinestarts1_9s[i] 
	y_x1000 = delta_y*(1000-x_flinestarts1_9s[i])/delta_x+y_flinestarts1_9s[i] 
	x_y0000 = delta_x*(0-y_flinestarts1_9s[i])/delta_y+x_flinestarts1_9s[i] 
	x_y1000 = delta_x*(1000-y_flinestarts1_9s[i])/delta_y+x_flinestarts1_9s[i] 
	if 0 < x_flinestarts1_9s[i] < 1000 and 0 < y_flinestarts1_9s[i] < 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000:
			z_flineends1_9s[i] = delta_z*(0-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
			x_flineends1_9s[i] = 0
			y_flineends1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000: 
			z_flineends1_9s[i] = delta_z*(1000-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
			x_flineends1_9s[i] = 1000
			y_flineends1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000: 
			z_flineends1_9s[i] = delta_z*(0-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
			y_flineends1_9s[i] = 0
			x_flineends1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_flineends1_9s[i] = delta_z*(1000-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
			y_flineends1_9s[i] = 1000
			x_flineends1_9s[i] = x_y1000
		else:
			a=1
	elif  0 < x_flineends1_9s[i] <= 1000 and 0 < y_flineends1_9s[i] < 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000: 
			z_flinestarts1_9s[i] = delta_z*(0-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
			x_flinestarts1_9s[i] = 0
			y_flinestarts1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000:
			z_flinestarts1_9s[i] = delta_z*(1000-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
			x_flinestarts1_9s[i] = 1000
			y_flinestarts1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000: 
			z_flinestarts1_9s[i] = delta_z*(0-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
			y_flinestarts1_9s[i] = 0
			x_flinestarts1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_flinestarts1_9s[i] = delta_z*(1000-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
			y_flinestarts1_9s[i] = 1000
			x_flinestarts1_9s[i] = x_y1000
		else:
			a=1
	elif x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000 and y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000: 
		z_flinestarts1_9s_z = delta_z*(0-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
		z_flineends1_9s_z = delta_z*(0-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
		y_flinestarts1_9s[i] = 0
		x_flinestarts1_9s[i] = x_y0000
		z_flinestarts1_9s[i] = z_flinestarts1_9s_z
		x_flineends1_9s[i] = 0
		y_flineends1_9s[i] = y_x0000
		z_flineends1_9s[i] = z_flineends1_9s_z
	elif y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000 and x_small <= x_y1000 <= x_big and  0<= x_y1000 <=1000: 
		z_flineends1_9s_z = delta_z*(1000-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
		z_flinestarts1_9s_z = delta_z*(0-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
		x_flinestarts1_9s[i] = 0
		y_flinestarts1_9s[i] = y_x0000
		z_flinestarts1_9s[i] = z_flinestarts1_9s_z
		y_flineends1_9s[i] = 1000
		x_flineends1_9s[i] = x_y1000
		z_flineends1_9s[i] = z_flineends1_9s_z
	elif x_small <= x_y1000 <= x_big and 0<= x_y1000 <=1000 and y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000: 
		z_flinestarts1_9s_z = delta_z*(1000-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
		z_flineends1_9s_z = delta_z*(1000-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
		y_flinestarts1_9s[i] = 1000
		x_flinestarts1_9s[i] = x_y1000
		z_flinestarts1_9s[i] = z_flinestarts1_9s_z
		x_flineends1_9s[i] = 1000
		y_flineends1_9s[i] = y_x1000
		z_flineends1_9s[i] = z_flineends1_9s_z
	elif y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000 and x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000: 
		z_flinestarts1_9s_z = delta_z*(1000-x_flinestarts1_9s[i])/delta_x+z_flinestarts1_9s[i]
		z_flineends1_9s_z = delta_z*(0-y_flinestarts1_9s[i])/delta_y+z_flinestarts1_9s[i]
		x_flinestarts1_9s[i] = 1000
		y_flinestarts1_9s[i] = y_x1000
		z_flinestarts1_9s[i] = z_flinestarts1_9s_z
		y_flineends1_9s[i] = 0
		x_flineends1_9s[i] = x_y0000
		z_flineends1_9s[i] = z_flineends1_9s_z
	else:
		a=1
tolerance=10e-5
num_fscenter = [] 
for i in range(len(x_flinestarts1_9s)):
	if 0-tolerance<=x_flinestarts1_9s[i]<=1000+tolerance and 0-tolerance<=y_flinestarts1_9s[i]<=1000+tolerance and 0-tolerance<=z_flinestarts1_9s[i]<=200+tolerance and 0-tolerance<=x_flineends1_9s[i]<=1000+tolerance and 0-tolerance<=y_flineends1_9s[i]<=1000+tolerance and 0-tolerance<=z_flineends1_9s[i]<=200+tolerance:
		num_fcenter = i
		num_fscenter.append(num_fcenter)
x_filamentstarts = []
y_filamentstarts = []
z_filamentstarts = []
x_filamentends = []
y_filamentends = []
z_filamentends = []
for i in num_fscenter:
	x_filamentstart = x_flinestarts1_9s[i]
	y_filamentstart = y_flinestarts1_9s[i]
	z_filamentstart = z_flinestarts1_9s[i]
	x_filamentend = x_flineends1_9s[i]
	y_filamentend = y_flineends1_9s[i]
	z_filamentend = z_flineends1_9s[i]
	x_filamentstarts.append(x_filamentstart)
	y_filamentstarts.append(y_filamentstart)
	z_filamentstarts.append(z_filamentstart)
	x_filamentends.append(x_filamentend)
	y_filamentends.append(y_filamentend)
	z_filamentends.append(z_filamentend)
print len(x_filamentstarts)
print len(y_filamentstarts)
print len(z_filamentstarts)
print len(x_filamentends)
print len(y_filamentends)
print len(z_filamentends)
for i in range(len(x_arplinestarts1_9s)):
	if y_arplineends1_9s[i] >= y_arplinestarts1_9s[i]: # 判断和确定区间
		y_big = y_arplineends1_9s[i]+0
		y_small = y_arplinestarts1_9s[i]+0
	else:
		y_big = y_arplinestarts1_9s[i]+0
		y_small = y_arplineends1_9s[i]+0
	if x_arplineends1_9s[i] >= x_arplinestarts1_9s[i]:
		x_big = x_arplineends1_9s[i]+0
		x_small = x_arplinestarts1_9s[i]+0
	else:
		x_big = x_arplinestarts1_9s[i]+0
		x_small = x_arplineends1_9s[i]+0
	delta_x = x_arplineends1_9s[i] - x_arplinestarts1_9s[i]
	delta_y = y_arplineends1_9s[i] - y_arplinestarts1_9s[i]
	delta_z = z_arplineends1_9s[i] - z_arplinestarts1_9s[i]
	y_x0000 = delta_y*(0-x_arplinestarts1_9s[i])/delta_x+y_arplinestarts1_9s[i] 
	y_x1000 = delta_y*(1000-x_arplinestarts1_9s[i])/delta_x+y_arplinestarts1_9s[i]
	x_y0000 = delta_x*(0-y_arplinestarts1_9s[i])/delta_y+x_arplinestarts1_9s[i] 
	x_y1000 = delta_x*(1000-y_arplinestarts1_9s[i])/delta_y+x_arplinestarts1_9s[i]
	if 0 <= x_arplinestarts1_9s[i] <= 1000 and 0 <= y_arplinestarts1_9s[i] <= 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000: 
			z_arplineends1_9s[i] = delta_z*(0-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
			x_arplineends1_9s[i] = 0
			y_arplineends1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000:
			z_arplineends1_9s[i] = delta_z*(1000-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
			x_arplineends1_9s[i] = 1000
			y_arplineends1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000: 
			z_arplineends1_9s[i] = delta_z*(0-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
			y_arplineends1_9s[i] = 0
			x_arplineends1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_arplineends1_9s[i] = delta_z*(1000-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
			y_arplineends1_9s[i] = 1000
			x_arplineends1_9s[i] = x_y1000
		else:
			a=1
	elif  0 <= x_arplineends1_9s[i] <= 1000 and 0 <= y_arplineends1_9s[i] <= 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000:
			z_arplinestarts1_9s[i] = delta_z*(0-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
			x_arplinestarts1_9s[i] = 0
			y_arplinestarts1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000: 
			z_arplinestarts1_9s[i] = delta_z*(1000-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
			x_arplinestarts1_9s[i] = 1000
			y_arplinestarts1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000: 
			z_arplinestarts1_9s[i] = delta_z*(0-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
			y_arplinestarts1_9s[i] = 0
			x_arplinestarts1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000:
			z_arplinestarts1_9s[i] = delta_z*(1000-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
			y_arplinestarts1_9s[i] = 1000
			x_arplinestarts1_9s[i] = x_y1000
		else:
			a=1
	elif x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000 and y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000: 
		z_arplinestarts1_9s_z = delta_z*(0-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
		z_arplineends1_9s_z = delta_z*(0-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
		y_arplinestarts1_9s[i] = 0
		x_arplinestarts1_9s[i] = x_y0000
		z_arplinestarts1_9s[i] = z_arplinestarts1_9s_z
		x_arplineends1_9s[i] = 0
		y_arplineends1_9s[i] = y_x0000
		z_arplineends1_9s[i] = z_arplineends1_9s_z
	elif y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000 and x_small <= x_y1000 <= x_big and  0<= x_y1000 <=1000:  
		z_arplineends1_9s_z = delta_z*(1000-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
		z_arplinestarts1_9s_z = delta_z*(0-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
		x_arplinestarts1_9s[i] = 0
		y_arplinestarts1_9s[i] = y_x0000
		z_arplinestarts1_9s[i] = z_arplinestarts1_9s_z
		y_arplineends1_9s[i] = 1000
		x_arplineends1_9s[i] = x_y1000
		z_arplineends1_9s[i] = z_arplineends1_9s_z
	elif x_small <= x_y1000 <= x_big and 0<= x_y1000 <=1000 and y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000:
		z_arplinestarts1_9s_z = delta_z*(1000-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
		z_arplineends1_9s_z = delta_z*(1000-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
		y_arplinestarts1_9s[i] = 1000
		x_arplinestarts1_9s[i] = x_y1000
		z_arplinestarts1_9s[i] = z_arplinestarts1_9s_z
		x_arplineends1_9s[i] = 1000
		y_arplineends1_9s[i] = y_x1000
		z_arplineends1_9s[i] = z_arplineends1_9s_z
	elif y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000 and x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000: 
		z_arplinestarts1_9s_z = delta_z*(1000-x_arplinestarts1_9s[i])/delta_x+z_arplinestarts1_9s[i]
		z_arplineends1_9s_z = delta_z*(0-y_arplinestarts1_9s[i])/delta_y+z_arplinestarts1_9s[i]
		x_arplinestarts1_9s[i] = 1000
		y_arplinestarts1_9s[i] = y_x1000
		z_arplinestarts1_9s[i] = z_arplinestarts1_9s_z
		y_arplineends1_9s[i] = 0
		x_arplineends1_9s[i] = x_y0000
		z_arplineends1_9s[i] = z_arplineends1_9s_z
	else:
		a=1
num_arpscenter = [] 
for i in range(len(x_arplinestarts1_9s)):
	if 0<=x_arplinestarts1_9s[i]<=1000 and 0<=y_arplinestarts1_9s[i]<=1000 and 0<=z_arplinestarts1_9s[i]<=200 and 0<=x_arplineends1_9s[i]<=1000 and 0<=y_arplineends1_9s[i]<=1000 and 0<=z_arplineends1_9s[i]<=200:
		num_arpcenter = i
		num_arpscenter.append(num_arpcenter)
x_arp23starts = []
y_arp23starts = []
z_arp23starts = []
x_arp23ends = []
y_arp23ends = []
z_arp23ends = []
for i in num_arpscenter:
	x_arp23start = x_arplinestarts1_9s[i]
	y_arp23start = y_arplinestarts1_9s[i]
	z_arp23start = z_arplinestarts1_9s[i]
	x_arp23end = x_arplineends1_9s[i]
	y_arp23end = y_arplineends1_9s[i]
	z_arp23end = z_arplineends1_9s[i]
	x_arp23starts.append(x_arp23start)
	y_arp23starts.append(y_arp23start)
	z_arp23starts.append(z_arp23start)
	x_arp23ends.append(x_arp23end)
	y_arp23ends.append(y_arp23end)
	z_arp23ends.append(z_arp23end)
print len(x_arp23starts)
print len(y_arp23starts)
print len(z_arp23starts)
print len(x_arp23ends)
print len(y_arp23ends)
print len(z_arp23ends)
for i in range(len(x_filinestarts1_9s)):
	if y_filineends1_9s[i] >= y_filinestarts1_9s[i]: 
		y_big = y_filineends1_9s[i]+0
		y_small = y_filinestarts1_9s[i]+0
	else:
		y_big = y_filinestarts1_9s[i]+0
		y_small = y_filineends1_9s[i]+0
	if x_filineends1_9s[i] >= x_filinestarts1_9s[i]:
		x_big = x_filineends1_9s[i]+0
		x_small = x_filinestarts1_9s[i]+0
	else:
		x_big = x_filinestarts1_9s[i]+0
		x_small = x_filineends1_9s[i]+0
	delta_x = x_filineends1_9s[i] - x_filinestarts1_9s[i]
	delta_y = y_filineends1_9s[i] - y_filinestarts1_9s[i]
	delta_z = z_filineends1_9s[i] - z_filinestarts1_9s[i]
	y_x0000 = delta_y*(0-x_filinestarts1_9s[i])/delta_x+y_filinestarts1_9s[i] 
	y_x1000 = delta_y*(1000-x_filinestarts1_9s[i])/delta_x+y_filinestarts1_9s[i] 
	x_y0000 = delta_x*(0-y_filinestarts1_9s[i])/delta_y+x_filinestarts1_9s[i] 
	x_y1000 = delta_x*(1000-y_filinestarts1_9s[i])/delta_y+x_filinestarts1_9s[i] 
	if 0 <= x_filinestarts1_9s[i] <= 1000 and 0 <= y_filinestarts1_9s[i] <= 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000: 
			z_filineends1_9s[i] = delta_z*(0-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
			x_filineends1_9s[i] = 0
			y_filineends1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000: 
			z_filineends1_9s[i] = delta_z*(1000-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
			x_filineends1_9s[i] = 1000
			y_filineends1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000: 
			z_filineends1_9s[i] = delta_z*(0-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
			y_filineends1_9s[i] = 0
			x_filineends1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_filineends1_9s[i] = delta_z*(1000-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
			y_filineends1_9s[i] = 1000
			x_filineends1_9s[i] = x_y1000
		else:
			a=1
	elif  0 <= x_filineends1_9s[i] <= 1000 and 0 <= y_filineends1_9s[i] <= 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000: 
			z_filinestarts1_9s[i] = delta_z*(0-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
			x_filinestarts1_9s[i] = 0
			y_filinestarts1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000:
			z_filinestarts1_9s[i] = delta_z*(1000-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
			x_filinestarts1_9s[i] = 1000
			y_filinestarts1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000:
			z_filinestarts1_9s[i] = delta_z*(0-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
			y_filinestarts1_9s[i] = 0
			x_filinestarts1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_filinestarts1_9s[i] = delta_z*(1000-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
			y_filinestarts1_9s[i] = 1000
			x_filinestarts1_9s[i] = x_y1000
		else:
			a=1
	elif x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000 and y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000:
		z_filinestarts1_9s_z = delta_z*(0-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
		z_filineends1_9s_z = delta_z*(0-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
		y_filinestarts1_9s[i] = 0
		x_filinestarts1_9s[i] = x_y0000
		z_filinestarts1_9s[i] = z_filinestarts1_9s_z
		x_filineends1_9s[i] = 0
		y_filineends1_9s[i] = y_x0000
		z_filineends1_9s[i] = z_filineends1_9s_z
	elif y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000 and x_small <= x_y1000 <= x_big and  0<= x_y1000 <=1000: 
		z_filineends1_9s_z = delta_z*(1000-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
		z_filinestarts1_9s_z = delta_z*(0-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
		x_filinestarts1_9s[i] = 0
		y_filinestarts1_9s[i] = y_x0000
		z_filinestarts1_9s[i] = z_filinestarts1_9s_z
		y_filineends1_9s[i] = 1000
		x_filineends1_9s[i] = x_y1000
		z_filineends1_9s[i] = z_filineends1_9s_z
	elif x_small <= x_y1000 <= x_big and 0<= x_y1000 <=1000 and y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000: 
		z_filinestarts1_9s_z = delta_z*(1000-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
		z_filineends1_9s_z = delta_z*(1000-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
		y_filinestarts1_9s[i] = 1000
		x_filinestarts1_9s[i] = x_y1000
		z_filinestarts1_9s[i] = z_filinestarts1_9s_z
		x_filineends1_9s[i] = 1000
		y_filineends1_9s[i] = y_x1000
		z_filineends1_9s[i] = z_filineends1_9s_z
	elif y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000 and x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000: 
		z_filinestarts1_9s_z = delta_z*(1000-x_filinestarts1_9s[i])/delta_x+z_filinestarts1_9s[i]
		z_filineends1_9s_z = delta_z*(0-y_filinestarts1_9s[i])/delta_y+z_filinestarts1_9s[i]
		x_filinestarts1_9s[i] = 1000
		y_filinestarts1_9s[i] = y_x1000
		z_filinestarts1_9s[i] = z_filinestarts1_9s_z
		y_filineends1_9s[i] = 0
		x_filineends1_9s[i] = x_y0000
		z_filineends1_9s[i] = z_filineends1_9s_z
	else:
		a=1
num_fiscenter = [] 
for i in range(len(x_filinestarts1_9s)):
	if 0<=x_filinestarts1_9s[i]<=1000 and 0<=y_filinestarts1_9s[i]<=1000 and 0<=z_filinestarts1_9s[i]<=200 and 0<=x_filineends1_9s[i]<=1000 and 0<=y_filineends1_9s[i]<=1000 and 0<=z_filineends1_9s[i]<=200:
		num_ficenter = i
		num_fiscenter.append(num_ficenter)
x_filaminstarts = []
y_filaminstarts = []
z_filaminstarts = []
x_filaminends = []
y_filaminends = []
z_filaminends = []
for i in num_fiscenter:
	x_filaminstart = x_filinestarts1_9s[i]
	y_filaminstart = y_filinestarts1_9s[i]
	z_filaminstart = z_filinestarts1_9s[i]
	x_filaminend = x_filineends1_9s[i]
	y_filaminend = y_filineends1_9s[i]
	z_filaminend = z_filineends1_9s[i]
	x_filaminstarts.append(x_filaminstart)
	y_filaminstarts.append(y_filaminstart)
	z_filaminstarts.append(z_filaminstart)
	x_filaminends.append(x_filaminend)
	y_filaminends.append(y_filaminend)
	z_filaminends.append(z_filaminend)
for i in range(len(x_ailinestarts1_9s)):
	if y_ailineends1_9s[i] >= y_ailinestarts1_9s[i]: # 判断和确定区间
		y_big = y_ailineends1_9s[i]+0
		y_small = y_ailinestarts1_9s[i]+0
	else:
		y_big = y_ailinestarts1_9s[i]+0
		y_small = y_ailineends1_9s[i]+0
	if x_ailineends1_9s[i] >= x_ailinestarts1_9s[i]:
		x_big = x_ailineends1_9s[i]+0
		x_small = x_ailinestarts1_9s[i]+0
	else:
		x_big = x_ailinestarts1_9s[i]+0
		x_small = x_ailineends1_9s[i]+0
	delta_x = x_ailineends1_9s[i] - x_ailinestarts1_9s[i]
	delta_y = y_ailineends1_9s[i] - y_ailinestarts1_9s[i]
	delta_z = z_ailineends1_9s[i] - z_ailinestarts1_9s[i]
	y_x0000 = delta_y*(0-x_ailinestarts1_9s[i])/delta_x+y_ailinestarts1_9s[i]
	y_x1000 = delta_y*(1000-x_ailinestarts1_9s[i])/delta_x+y_ailinestarts1_9s[i]
	x_y0000 = delta_x*(0-y_ailinestarts1_9s[i])/delta_y+x_ailinestarts1_9s[i] 
	x_y1000 = delta_x*(1000-y_ailinestarts1_9s[i])/delta_y+x_ailinestarts1_9s[i]
	if 0 <= x_ailinestarts1_9s[i] <= 1000 and 0 <= y_ailinestarts1_9s[i] <= 1000:
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000:
			z_ailineends1_9s[i] = delta_z*(0-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
			x_ailineends1_9s[i] = 0
			y_ailineends1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000: 
			z_ailineends1_9s[i] = delta_z*(1000-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
			x_ailineends1_9s[i] = 1000
			y_ailineends1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000:
			z_ailineends1_9s[i] = delta_z*(0-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
			y_ailineends1_9s[i] = 0
			x_ailineends1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_ailineends1_9s[i] = delta_z*(1000-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
			y_ailineends1_9s[i] = 1000
			x_ailineends1_9s[i] = x_y1000
		else:
			a=1
	elif  0 <= x_ailineends1_9s[i] <= 1000 and 0 <= y_ailineends1_9s[i] <= 1000:
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000:
			z_ailinestarts1_9s[i] = delta_z*(0-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
			x_ailinestarts1_9s[i] = 0
			y_ailinestarts1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000:
			z_ailinestarts1_9s[i] = delta_z*(1000-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
			x_ailinestarts1_9s[i] = 1000
			y_ailinestarts1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000:
			z_ailinestarts1_9s[i] = delta_z*(0-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
			y_ailinestarts1_9s[i] = 0
			x_ailinestarts1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_ailinestarts1_9s[i] = delta_z*(1000-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
			y_ailinestarts1_9s[i] = 1000
			x_ailinestarts1_9s[i] = x_y1000
		else:
			a=1
	elif x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000 and y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000:
		z_ailinestarts1_9s_z = delta_z*(0-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
		z_ailineends1_9s_z = delta_z*(0-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
		y_ailinestarts1_9s[i] = 0
		x_ailinestarts1_9s[i] = x_y0000
		z_ailinestarts1_9s[i] = z_ailinestarts1_9s_z
		x_ailineends1_9s[i] = 0
		y_ailineends1_9s[i] = y_x0000
		z_ailineends1_9s[i] = z_ailineends1_9s_z
	elif y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000 and x_small <= x_y1000 <= x_big and  0<= x_y1000 <=1000: 
		z_ailineends1_9s_z = delta_z*(1000-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
		z_ailinestarts1_9s_z = delta_z*(0-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
		x_ailinestarts1_9s[i] = 0
		y_ailinestarts1_9s[i] = y_x0000
		z_ailinestarts1_9s[i] = z_ailinestarts1_9s_z
		y_ailineends1_9s[i] = 1000
		x_ailineends1_9s[i] = x_y1000
		z_ailineends1_9s[i] = z_ailineends1_9s_z
	elif x_small <= x_y1000 <= x_big and 0<= x_y1000 <=1000 and y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000: 
		z_ailinestarts1_9s_z = delta_z*(1000-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
		z_ailineends1_9s_z = delta_z*(1000-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
		y_ailinestarts1_9s[i] = 1000
		x_ailinestarts1_9s[i] = x_y1000
		z_ailinestarts1_9s[i] = z_ailinestarts1_9s_z
		x_ailineends1_9s[i] = 1000
		y_ailineends1_9s[i] = y_x1000
		z_ailineends1_9s[i] = z_ailineends1_9s_z
	elif y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000 and x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000:
		z_ailinestarts1_9s_z = delta_z*(1000-x_ailinestarts1_9s[i])/delta_x+z_ailinestarts1_9s[i]
		z_ailineends1_9s_z = delta_z*(0-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
		x_ailinestarts1_9s[i] = 1000
		y_ailinestarts1_9s[i] = y_x1000
		z_ailinestarts1_9s[i] = z_ailinestarts1_9s_z
		y_ailineends1_9s[i] = 0
		x_ailineends1_9s[i] = x_y0000
		z_ailineends1_9s[i] = z_ailineends1_9s_z
	else:
		a=1
num_aiscenter = [] 
for i in range(len(x_ailinestarts1_9s)):
	if 0<=x_ailinestarts1_9s[i]<=1000 and 0<=y_ailinestarts1_9s[i]<=1000 and 0<=z_ailinestarts1_9s[i]<=200 and 0<=x_ailineends1_9s[i]<=1000 and 0<=y_ailineends1_9s[i]<=1000 and 0<=z_ailineends1_9s[i]<=200:
		num_aicenter = i
		num_aiscenter.append(num_aicenter)
x_actininstarts = []
y_actininstarts = []
z_actininstarts = []
x_actininends = []
y_actininends = []
z_actininends = []
for i in num_aiscenter:
	x_actininstart = x_ailinestarts1_9s[i]
	y_actininstart = y_ailinestarts1_9s[i]
	z_actininstart = z_ailinestarts1_9s[i]
	x_actininend = x_ailineends1_9s[i]
	y_actininend = y_ailineends1_9s[i]
	z_actininend = z_ailineends1_9s[i]
	x_actininstarts.append(x_actininstart)
	y_actininstarts.append(y_actininstart)
	z_actininstarts.append(z_actininstart)
	x_actininends.append(x_actininend)
	y_actininends.append(y_actininend)
	z_actininends.append(z_actininend)
print len(x_actininstarts)
print len(y_actininstarts)
print len(z_actininstarts)
print len(x_actininends)
print len(y_actininends)
print len(z_actininends)
for i in range(len(x_etlinestarts1_9s)):
	if y_etlineends1_9s[i] >= y_etlinestarts1_9s[i]:
		y_big = y_etlineends1_9s[i]+0
		y_small = y_etlinestarts1_9s[i]+0
	else:
		y_big = y_etlinestarts1_9s[i]+0
		y_small = y_etlineends1_9s[i]+0
	if x_etlineends1_9s[i] >= x_etlinestarts1_9s[i]:
		x_big = x_etlineends1_9s[i]+0
		x_small = x_etlinestarts1_9s[i]+0
	else:
		x_big = x_etlinestarts1_9s[i]+0
		x_small = x_etlineends1_9s[i]+0
	delta_x = x_etlineends1_9s[i] - x_etlinestarts1_9s[i]
	delta_y = y_etlineends1_9s[i] - y_etlinestarts1_9s[i]
	delta_z = z_etlineends1_9s[i] - z_etlinestarts1_9s[i]
	y_x0000 = delta_y*(0-x_etlinestarts1_9s[i])/delta_x+y_etlinestarts1_9s[i]
	y_x1000 = delta_y*(1000-x_etlinestarts1_9s[i])/delta_x+y_etlinestarts1_9s[i]
	x_y0000 = delta_x*(0-y_etlinestarts1_9s[i])/delta_y+x_etlinestarts1_9s[i]
	x_y1000 = delta_x*(1000-y_etlinestarts1_9s[i])/delta_y+x_etlinestarts1_9s[i]	
	if 0 <= x_etlinestarts1_9s[i] <= 1000 and 0 <= y_etlinestarts1_9s[i] <= 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000:
			z_etlineends1_9s[i] = delta_z*(0-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
			x_etlineends1_9s[i] = 0
			y_etlineends1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000:
			z_etlineends1_9s[i] = delta_z*(1000-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
			x_etlineends1_9s[i] = 1000
			y_etlineends1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000:
			z_ailineends1_9s[i] = delta_z*(0-y_ailinestarts1_9s[i])/delta_y+z_ailinestarts1_9s[i]
			y_ailineends1_9s[i] = 0
			x_ailineends1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000: 
			z_etlineends1_9s[i] = delta_z*(1000-y_etlinestarts1_9s[i])/delta_y+z_etlinestarts1_9s[i]
			y_etlineends1_9s[i] = 1000
			x_etlineends1_9s[i] = x_y1000
		else:
			a=1
	elif  0 <= x_etlineends1_9s[i] <= 1000 and 0 <= y_etlineends1_9s[i] <= 1000: 
		if y_small <= y_x0000 <= y_big and 0 <= y_x0000 <= 1000:
			z_etlinestarts1_9s[i] = delta_z*(0-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
			x_etlinestarts1_9s[i] = 0
			y_etlinestarts1_9s[i] = y_x0000
		elif y_small <= y_x1000 <= y_big and 0 <= y_x1000 <= 1000:
			z_etlinestarts1_9s[i] = delta_z*(1000-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
			x_etlinestarts1_9s[i] = 1000
			y_etlinestarts1_9s[i] = y_x1000
		elif x_small <= x_y0000 <= x_big and 0 <= x_y0000 <= 1000:
			z_etlinestarts1_9s[i] = delta_z*(0-y_etlinestarts1_9s[i])/delta_y+z_etlinestarts1_9s[i]
			y_etlinestarts1_9s[i] = 0
			x_etlinestarts1_9s[i] = x_y0000
		elif x_small <= x_y1000 <= x_big and 0 <= x_y1000 <= 1000:
			z_etlinestarts1_9s[i] = delta_z*(1000-y_etlinestarts1_9s[i])/delta_y+z_etlinestarts1_9s[i]
			y_etlinestarts1_9s[i] = 1000
			x_etlinestarts1_9s[i] = x_y1000
		else:
			a=1
	elif x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000 and y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000:
		z_etlinestarts1_9s_z = delta_z*(0-y_etlinestarts1_9s[i])/delta_y+z_etlinestarts1_9s[i]
		z_etlineends1_9s_z = delta_z*(0-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
		y_etlinestarts1_9s[i] = 0
		x_etlinestarts1_9s[i] = x_y0000
		z_etlinestarts1_9s[i] = z_etlinestarts1_9s_z
		x_etlineends1_9s[i] = 0
		y_etlineends1_9s[i] = y_x0000
		z_etlineends1_9s[i] = z_etlineends1_9s_z
	elif y_small <= y_x0000 <= y_big and  0<= y_x0000 <=1000 and x_small <= x_y1000 <= x_big and  0<= x_y1000 <=1000: 
		z_etlineends1_9s_z = delta_z*(1000-y_etlinestarts1_9s[i])/delta_y+z_etlinestarts1_9s[i]
		z_etlinestarts1_9s_z = delta_z*(0-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
		x_etlinestarts1_9s[i] = 0
		y_etlinestarts1_9s[i] = y_x0000
		z_etlinestarts1_9s[i] = z_etlinestarts1_9s_z
		y_etlineends1_9s[i] = 1000
		x_etlineends1_9s[i] = x_y1000
		z_etlineends1_9s[i] = z_etlineends1_9s_z
	elif x_small <= x_y1000 <= x_big and 0<= x_y1000 <=1000 and y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000:
		z_etlinestarts1_9s_z = delta_z*(1000-y_etlinestarts1_9s[i])/delta_y+z_etlinestarts1_9s[i]
		z_etlineends1_9s_z = delta_z*(1000-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
		y_etlinestarts1_9s[i] = 1000
		x_etlinestarts1_9s[i] = x_y1000
		z_etlinestarts1_9s[i] = z_etlinestarts1_9s_z
		x_etlineends1_9s[i] = 1000
		y_etlineends1_9s[i] = y_x1000
		z_etlineends1_9s[i] = z_etlineends1_9s_z
	elif y_small <= y_x1000 <= y_big and 0<= y_x1000 <=1000 and x_small <= x_y0000 <= x_big and 0<= x_y0000 <=1000:
		z_etlinestarts1_9s_z = delta_z*(1000-x_etlinestarts1_9s[i])/delta_x+z_etlinestarts1_9s[i]
		z_etlineends1_9s_z = delta_z*(0-y_etlinestarts1_9s[i])/delta_y+z_etlinestarts1_9s[i]
		x_etlinestarts1_9s[i] = 1000
		y_etlinestarts1_9s[i] = y_x1000
		z_etlinestarts1_9s[i] = z_etlinestarts1_9s_z
		y_etlineends1_9s[i] = 0
		x_etlineends1_9s[i] = x_y0000
		z_etlineends1_9s[i] = z_etlineends1_9s_z
	else:
		a=1
num_etscenter = [] 
for i in range(len(x_etlinestarts1_9s)):
	if 0<=x_etlinestarts1_9s[i]<=1000 and 0<=y_etlinestarts1_9s[i]<=1000 and 0<=z_etlinestarts1_9s[i]<=200 and 0<=x_etlineends1_9s[i]<=1000 and 0<=y_etlineends1_9s[i]<=1000 and 0<=z_etlineends1_9s[i]<=200:
		num_etcenter = i
		num_etscenter.append(num_etcenter)
x_entanglementstarts = []
y_entanglementstarts = []
z_entanglementstarts = []
x_entanglementends = []
y_entanglementends = []
z_entanglementends = []
for i in num_etscenter:
	x_entanglementstart = x_etlinestarts1_9s[i]
	y_entanglementstart = y_etlinestarts1_9s[i]
	z_entanglementstart = z_etlinestarts1_9s[i]
	x_entanglementend = x_etlineends1_9s[i]
	y_entanglementend = y_etlineends1_9s[i]
	z_entanglementend = z_etlineends1_9s[i]
	x_entanglementstarts.append(x_entanglementstart)
	y_entanglementstarts.append(y_entanglementstart)
	z_entanglementstarts.append(z_entanglementstart)
	x_entanglementends.append(x_entanglementend)
	y_entanglementends.append(y_entanglementend)
	z_entanglementends.append(z_entanglementend)
print len(x_entanglementstarts)
print len(y_entanglementstarts)
print len(z_entanglementstarts)
print len(x_entanglementends)
print len(y_entanglementends)
print len(z_entanglementends)
index_filamins = []
for i in range(len(x_filaminstarts)):
	index_filamin = i
	index_filamins.append(index_filamin)
numb_del_filamins_percent = int((1-crosslinkers_possibility)*len(x_filaminstarts))
del_filamins_percent = random.sample(index_filamins, numb_del_filamins_percent)
del_filamins_percent.sort()
del_filamins_percent.reverse()
for i in del_filamins_percent:
	del x_filaminstarts[i] 
	del y_filaminstarts[i]
	del z_filaminstarts[i]
	del x_filaminends[i]
	del y_filaminends[i]
	del z_filaminends[i]
index_actinins = []
for i in range(len(x_actininstarts)):
	index_actinin = i
	index_actinins.append(index_actinin)
numb_del_actinins_percent = int((1-crosslinkers_possibility)*len(x_actininstarts)) 
del_actinins_percent = random.sample(index_actinins, numb_del_actinins_percent)
del_actinins_percent.sort()
del_actinins_percent.reverse()
for i in del_actinins_percent:
	del x_actininstarts[i] 
	del y_actininstarts[i]
	del z_actininstarts[i]
	del x_actininends[i]
	del y_actininends[i]
	del z_actininends[i]
x_crosslinkerstarts = x_arp23starts + x_filaminstarts + x_actininstarts
y_crosslinkerstarts = y_arp23starts + y_filaminstarts + y_actininstarts
z_crosslinkerstarts = z_arp23starts + z_filaminstarts + z_actininstarts
x_crosslinkerends = x_arp23ends + x_filaminends + x_actininends
y_crosslinkerends = y_arp23ends + y_filaminends + y_actininends
z_crosslinkerends = z_arp23ends + z_filaminends + z_actininends
xyz_filamentstarts = []   # to generate the start xyz coordinates of the filaments
xyz_filamentends = []     # to generate the end xyz coordinates of the filaments
for i in range(len(x_filamentstarts)):
	xyz_filamentstart = ((x_filamentstarts[i]),(y_filamentstarts[i]),(z_filamentstarts[i]))
	xyz_filamentstarts.append(xyz_filamentstart)
	xyz_filamentend = ((x_filamentends[i]),(y_filamentends[i]),(z_filamentends[i]))
	xyz_filamentends.append(xyz_filamentend)
xyz_filamentpoints = xyz_filamentstarts + xyz_filamentends
for j in range(len(xyz_filamentstarts)):
	myPart.WirePolyLine(mergeType=IMPRINT, meshable=ON, points=(xyz_filamentstarts[j], xyz_filamentends[j]))
xyz_arp23starts = []   # to generate the start xyz coordinates of the filaments
xyz_arp23ends = []     # to generate the end xyz coordinates of the filaments
for i in range(len(x_arp23starts)):
	xyz_arp23start = ((x_arp23starts[i]),(y_arp23starts[i]),(z_arp23starts[i]))
	xyz_arp23starts.append(xyz_arp23start)
	xyz_arp23end = ((x_arp23ends[i]),(y_arp23ends[i]),(z_arp23ends[i]))
	xyz_arp23ends.append(xyz_arp23end)
for j in range(len(xyz_arp23starts)):
	myPart.WirePolyLine(mergeType=IMPRINT, meshable=ON, points=(xyz_arp23starts[j], xyz_arp23ends[j]))
xyz_filaminstarts = []   # to generate the start xyz coordinates of the filaments
xyz_filaminends = []     # to generate the end xyz coordinates of the filaments
for i in range(len(x_filaminstarts)):
	xyz_filaminstart = ((x_filaminstarts[i]),(y_filaminstarts[i]),(z_filaminstarts[i]))
	xyz_filaminstarts.append(xyz_filaminstart)
	xyz_filaminend = ((x_filaminends[i]),(y_filaminends[i]),(z_filaminends[i]))
	xyz_filaminends.append(xyz_filaminend)
for j in range(len(xyz_filaminstarts)):
	myPart.WirePolyLine(mergeType=IMPRINT, meshable=ON, points=(xyz_filaminstarts[j], xyz_filaminends[j]))
xyz_actininstarts = []   # to generate the start xyz coordinates of the filaments
xyz_actininends = []     # to generate the end xyz coordinates of the filaments
for i in range(len(x_actininstarts)):
	xyz_actininstart = ((x_actininstarts[i]),(y_actininstarts[i]),(z_actininstarts[i]))
	xyz_actininstarts.append(xyz_actininstart)
	xyz_actininend = ((x_actininends[i]),(y_actininends[i]),(z_actininends[i]))
	xyz_actininends.append(xyz_actininend)
for j in range(len(xyz_actininstarts)):
	myPart.WirePolyLine(mergeType=IMPRINT, meshable=ON, points=(xyz_actininstarts[j], xyz_actininends[j]))
len(xyz_actininstarts)
len(xyz_actininends)
yf_zuojin_x000=[]
for i in range(len(x_filamentstarts)):
	if abs(x_filamentstarts[i]-0)<10e-6:
		y_zj=y_filamentstarts[i]
		yf_zuojin_x000.append(y_zj)
yf_zuochu_x000=[]
for i in range(len(x_filamentends)):
	if abs(x_filamentends[i]-0)<10e-6:
		skkkk=y_filamentends[i]
		yf_zuochu_x000.append(skkkk)
yf_youjin_x1000=[]
for i in range(len(x_filamentstarts)):
	if abs(x_filamentstarts[i]-1000)<10e-6:
		skkkk=y_filamentstarts[i]
		yf_youjin_x1000.append(skkkk)
yf_youchu_x1000=[]
for i in range(len(x_filamentends)):
	if abs(x_filamentends[i]-1000)<10e-6:
		skkkk=y_filamentends[i]
		yf_youchu_x1000.append(skkkk)
yf_zuopoints = yf_zuojin_x000 + yf_zuochu_x000
yf_youpoints = yf_youjin_x1000 + yf_youchu_x1000
print len(yf_zuopoints) 
print len(yf_youpoints) 
sorted(yf_zuopoints)
sorted(yf_youpoints)
xf_shangchu_y1000=[]
index_fl_shangchu=[]
for i in range(len(y_filamentends)):
	if abs(y_filamentends[i]-1000)<10e-6:
		xddddd=x_filamentends[i]
		index_fl_shangchuy1000 = i
		xf_shangchu_y1000.append(xddddd)
		index_fl_shangchu.append(index_fl_shangchuy1000)
angles_ydirection = []
cos_angles_ydirection = []
for i in index_fl_shangchu:
	delta_x_shangchu = x_filamentends[i]-x_filamentstarts[i]
	delta_y_shangchu = y_filamentends[i]-y_filamentstarts[i]
	delta_z_shangchu = z_filamentends[i]-z_filamentstarts[i]
	len_fl_shangchu = (delta_x_shangchu**2 + delta_y_shangchu**2 + delta_z_shangchu**2)**0.5
	cos_angle_ydirection = (delta_x_shangchu*0+delta_y_shangchu*1+delta_z_shangchu*0)/(len_fl_shangchu*1)
	angle_ydirection = math.acos(cos_angle_ydirection)*180/3.1415926
	angles_ydirection.append(angle_ydirection)
	cos_angles_ydirection.append(cos_angle_ydirection)
forces_per_filament = []
for i in cos_angles_ydirection:
	force_per_filament = 1*i
	forces_per_filament.append(force_per_filament)
protrusion_force_filaments = sum(forces_per_filament)
protrusion_stress_leading_xzplane = protrusion_force_filaments*(1e-12)/(200*1000*(1e-18))/1000
len(index_fl_shangchu)
len(angles_ydirection)
len(forces_per_filament)
print angles_ydirection
print forces_per_filament
print protrusion_force_filaments
print protrusion_stress_leading_xzplane
xf_shangjin_y1000=[] 
for i in range(len(y_filamentstarts)):
	if abs(y_filamentstarts[i]-1000)<10e-6:
		ddddd=x_filamentstarts[i]
		xf_shangjin_y1000.append(ddddd)
xf_xiachu_y0000=[] 
for i in range(len(y_filamentends)):
	if abs(y_filamentends[i]-0)<10e-6:
		skkkk=x_filamentends[i]
		xf_xiachu_y0000.append(skkkk)
xf_xiajin_y0000=[] 
for i in range(len(y_filamentstarts)):
	if abs(y_filamentstarts[i]-0)<10e-6:
		skkkk=x_filamentstarts[i]
		xf_xiajin_y0000.append(skkkk)
xf_shangpoints= xf_shangchu_y1000 + xf_shangjin_y1000
xf_xiapoints = xf_xiachu_y0000 + xf_xiajin_y0000
print len(xf_shangpoints)  
print len(xf_xiapoints)  
sorted(xf_shangpoints)
sorted(xf_xiapoints)
yarp_zuojin_x000=[]
for i in range(len(x_arp23starts)):
	if abs(x_arp23starts[i]-0)<10e-6:
		y_zj=y_arp23starts[i]
		yarp_zuojin_x000.append(y_zj)
yarp_zuochu_x000=[]
for i in range(len(x_arp23ends)):
	if abs(x_arp23ends[i]-0)<10e-6:
		skkkk=y_arp23ends[i]
		yarp_zuochu_x000.append(skkkk)
yarp_youjin_x1000=[]
for i in range(len(x_arp23starts)):
	if abs(x_arp23starts[i]-1000)<10e-6:
		skkkk=y_arp23starts[i]
		yarp_youjin_x1000.append(skkkk)
yarp_youchu_x1000=[]
for i in range(len(x_arp23ends)):
	if abs(x_arp23ends[i]-1000)<10e-6:
		skkkk=y_arp23ends[i]
		yarp_youchu_x1000.append(skkkk)
yarp_zuopoints = yarp_zuojin_x000 + yarp_zuochu_x000
yarp_youpoints = yarp_youjin_x1000 + yarp_youchu_x1000
print len(yarp_zuopoints) 
print len(yarp_youpoints) 
sorted(yarp_zuopoints)
sorted(yarp_youpoints)
xarp_shangchu_y1000=[]
for i in range(len(y_arp23ends)):
	if abs(y_arp23ends[i]-1000)<10e-6:
		xddddd=x_arp23ends[i]
		xarp_shangchu_y1000.append(xddddd)
xarp_shangjin_y1000=[] 
for i in range(len(y_arp23starts)):
	if abs(y_arp23starts[i]-1000)<10e-6:
		ddddd=x_arp23starts[i]
		xarp_shangjin_y1000.append(ddddd)
xarp_xiachu_y0000=[] 
for i in range(len(y_arp23ends)):
	if abs(y_arp23ends[i]-0)<10e-6:
		skkkk=x_arp23ends[i]
		xarp_xiachu_y0000.append(skkkk)
xarp_xiajin_y0000=[] 
for i in range(len(y_arp23starts)):
	if abs(y_arp23starts[i]-0)<10e-6:
		skkkk=x_arp23starts[i]
		xarp_xiajin_y0000.append(skkkk)
xarp_shangpoints= xarp_shangchu_y1000 + xarp_shangjin_y1000
xarp_xiapoints = xarp_xiachu_y0000 + xarp_xiajin_y0000
print len(xarp_shangpoints) 
print len(xarp_xiapoints) 
sorted(xarp_shangpoints)
sorted(xarp_xiapoints)
yfi_zuojin_x000=[]
for i in range(len(x_filaminstarts)):
	if abs(x_filaminstarts[i]-0)<10e-6:
		y_zj=y_filaminstarts[i]
		yfi_zuojin_x000.append(y_zj)
yfi_zuochu_x000=[]
for i in range(len(x_filaminends)):
	if abs(x_filaminends[i]-0)<10e-6:
		skkkk=y_filaminends[i]
		yfi_zuochu_x000.append(skkkk)
yfi_youjin_x1000=[]
for i in range(len(x_filaminstarts)):
	if abs(x_filaminstarts[i]-1000)<10e-6:
		skkkk=y_filaminstarts[i]
		yfi_youjin_x1000.append(skkkk)
yfi_youchu_x1000=[]
for i in range(len(x_filaminends)):
	if abs(x_filaminends[i]-1000)<10e-6:
		skkkk=y_filaminends[i]
		yfi_youchu_x1000.append(skkkk)
yfi_zuopoints = yfi_zuojin_x000 + yfi_zuochu_x000
yfi_youpoints = yfi_youjin_x1000 + yfi_youchu_x1000
print len(yfi_zuopoints) 
print len(yfi_youpoints)
sorted(yfi_zuopoints)
sorted(yfi_youpoints)
xfi_shangchu_y1000=[]
for i in range(len(y_filaminends)):
	if abs(y_filaminends[i]-1000)<10e-6:
		xddddd=x_filaminends[i]
		xfi_shangchu_y1000.append(xddddd)
xfi_shangjin_y1000=[] 
for i in range(len(y_filaminstarts)):
	if abs(y_filaminstarts[i]-1000)<10e-6:
		ddddd=x_filaminstarts[i]
		xfi_shangjin_y1000.append(ddddd)
xfi_xiachu_y0000=[] 
for i in range(len(y_filaminends)):
	if abs(y_filaminends[i]-0)<10e-6:
		skkkk=x_filaminends[i]
		xfi_xiachu_y0000.append(skkkk)
xfi_xiajin_y0000=[]
for i in range(len(y_filaminstarts)):
	if abs(y_filaminstarts[i]-0)<10e-6:
		skkkk=x_filaminstarts[i]
		xfi_xiajin_y0000.append(skkkk)
xfi_shangpoints= xfi_shangchu_y1000 + xfi_shangjin_y1000
xfi_xiapoints = xfi_xiachu_y0000 + xfi_xiajin_y0000
print len(xfi_shangpoints)  
print len(xfi_xiapoints)  
sorted(xfi_shangpoints)
sorted(xfi_xiapoints)
yai_zuojin_x000=[]
for i in range(len(x_actininstarts)):
	if abs(x_actininstarts[i]-0)<10e-6:
		y_zj=y_actininstarts[i]
		yai_zuojin_x000.append(y_zj)
yai_zuochu_x000=[]
for i in range(len(x_actininends)):
	if abs(x_actininends[i]-0)<10e-6:
		skkkk=y_actininends[i]
		yai_zuochu_x000.append(skkkk)
yai_youjin_x1000=[]
for i in range(len(x_actininstarts)):
	if abs(x_actininstarts[i]-1000)<10e-6:
		skkkk=y_actininstarts[i]
		yai_youjin_x1000.append(skkkk)
yai_youchu_x1000=[]
for i in range(len(x_actininends)):
	if abs(x_actininends[i]-1000)<10e-6:
		skkkk=y_actininends[i]
		yai_youchu_x1000.append(skkkk)
yai_zuopoints = yai_zuojin_x000 + yai_zuochu_x000
yai_youpoints = yai_youjin_x1000 + yai_youchu_x1000
print len(yai_zuopoints)
print len(yai_youpoints) 
sorted(yai_zuopoints)
sorted(yai_youpoints)
xai_shangchu_y1000=[]
for i in range(len(y_actininends)):
	if y_actininends[i]==1000:
		xddddd=x_actininends[i]
		xai_shangchu_y1000.append(xddddd)
xai_shangjin_y1000=[] 
for i in range(len(y_actininstarts)):
	if y_actininstarts[i]==1000:
		ddddd=x_actininstarts[i]
		xai_shangjin_y1000.append(ddddd)
xai_xiachu_y0000=[] 
for i in range(len(y_actininends)):
	if y_actininends[i]==0:
		skkkk=x_actininends[i]
		xai_xiachu_y0000.append(skkkk)
xai_xiajin_y0000=[] 
for i in range(len(y_actininstarts)):
	if y_actininstarts[i]==0:
		skkkk=x_actininstarts[i]
		xai_xiajin_y0000.append(skkkk)
xai_shangpoints= xai_shangchu_y1000 + xai_shangjin_y1000
xai_xiapoints = xai_xiachu_y0000 + xai_xiajin_y0000
print len(xai_shangpoints)  
print len(xai_xiapoints) 
sorted(xai_shangpoints)
sorted(xai_xiapoints)
print (len(xyz_arp23starts))
print len(xyz_filaminstarts)
print len(xyz_actininstarts)
len_filaments = []
for i in range(len(x_filamentstarts)):
	len_filament = ((x_filamentends[i]-x_filamentstarts[i])**2+(y_filamentends[i]-y_filamentstarts[i])**2+(z_filamentends[i]-z_filamentstarts[i])**2)**0.5
	len_filaments.append(len_filament)
len_filaments_whole = sum(len_filaments)*0.001 
print len_filaments_whole
deltax_filaments = []
deltay_filaments = []
for i in range(len(x_filamentstarts)):
	deltax_filament = x_filamentends[i] - x_filamentstarts[i]
	deltay_filament = y_filamentends[i] - y_filamentstarts[i]
	deltax_filaments.append(deltax_filament)
	deltay_filaments.append(deltay_filament)
theta_filaments = []
for i in range(len(x_filamentstarts)):
	if deltax_filaments[i] >= 0: 
		if deltay_filaments[i] > 0:
			theta_rad = math.atan(deltax_filaments[i]/deltay_filaments[i])
			theta_filament = theta_rad*180/3.14
		elif deltay_filaments[i] < 0:
			theta_rad = math.atan(deltax_filaments[i]/deltay_filaments[i])
			theta_filament = theta_rad*180/3.14 + 180
		else:
			theta_filament = 90
	else:
		if deltay_filaments[i] > 0:
			theta_rad = math.atan(deltax_filaments[i]/deltay_filaments[i])
			theta_filament = theta_rad*180/3.14
		elif deltay_filaments[i] < 0:
			theta_rad = math.atan(deltax_filaments[i]/deltay_filaments[i])
			theta_filament = theta_rad*180/3.14 - 180
		else:
			theta_filament = -90
	theta_filaments.append(theta_filament)
print len(theta_filaments)
myModel.Material(name='filament_material')
myModel.materials['filament_material'].Elastic(table=((2.0e9, 0.3), ))
myModel.Material(name='arp_material')
myModel.materials['arp_material'].Elastic(table=((2.0e9, 0.3), ))
myModel.Material(name='filamin_material')
myModel.materials['filamin_material'].Elastic(table=((6.0e7, 0.3), ))
myModel.Material(name='actinin_material')
myModel.materials['actinin_material'].Elastic(table=((6.0e7, 0.3), ))
myModel.CircularProfile(name='filaments_circular', r=3.5)
myModel.BeamSection(consistentMassMatrix=False, integration=DURING_ANALYSIS, material='filament_material', name='filament_section', poissonRatio=0.3, profile='filaments_circular', temperatureVar=LINEAR)
myModel.CircularProfile(name='arp_circular', r=3.5)
myModel.BeamSection(consistentMassMatrix=False, integration=DURING_ANALYSIS, material='arp_material', name='arp_section', poissonRatio=0.3, profile='arp_circular', temperatureVar=LINEAR)
myModel.CircularProfile(name='filamin_circular', r=2.0)
myModel.BeamSection(consistentMassMatrix=False, integration=DURING_ANALYSIS, material='filamin_material', name='filamin_section', poissonRatio=0.3, profile='filamin_circular', temperatureVar=LINEAR)
myModel.CircularProfile(name='actinin_circular', r=2.0)
myModel.BeamSection(consistentMassMatrix=False, integration=DURING_ANALYSIS, material='actinin_material', name='actinin_section', poissonRatio=0.3, profile='actinin_circular', temperatureVar=LINEAR)
edges_midpoints = []
for i in range(len(myPart.edges)):
	edges_midpoint = myPart.edges[i].pointOn
	edges_midpoints.append(edges_midpoint)
tolerance_edge = 2e-3
fledges_midpoints = []
arpedges_midpoints = []
fiedges_midpoints = []
aiedges_midpoints = []
for i in range(len(edges_midpoints)):
	for j in range(len(x_filamentstarts)):
		delta_flx = x_filamentends[j]-x_filamentstarts[j]
		delta_fly = y_filamentends[j]-y_filamentstarts[j]
		delta_flz = z_filamentends[j]-z_filamentstarts[j]
		delta_edgeflx = edges_midpoints[i][0][0]-x_filamentstarts[j]
		delta_edgefly = edges_midpoints[i][0][1]-y_filamentstarts[j]
		delta_edgeflz = edges_midpoints[i][0][2]-z_filamentstarts[j]
		x_flratio = delta_edgeflx/delta_flx
		y_flratio = delta_edgefly/delta_fly
		z_flratio = delta_edgeflz/delta_flz
		delta1 = abs(x_flratio-y_flratio)
		delta2 = abs(y_flratio-z_flratio)
		if -0.0001<=x_flratio<=1.0001 and delta1<tolerance_edge and delta2<tolerance_edge:
			fledges_midpoint = myPart.edges[i]
			fledges_midpoints.append(fledges_midpoint)
	for k in range(len(x_arp23starts)):
		delta_arpx = x_arp23ends[k]-x_arp23starts[k]
		delta_arpy = y_arp23ends[k]-y_arp23starts[k]
		delta_arpz = z_arp23ends[k]-z_arp23starts[k]
		delta_edgearpx = edges_midpoints[i][0][0]-x_arp23starts[k]
		delta_edgearpy = edges_midpoints[i][0][1]-y_arp23starts[k]
		delta_edgearpz = edges_midpoints[i][0][2]-z_arp23starts[k]
		x_arpratio = delta_edgearpx/delta_arpx
		y_arpratio = delta_edgearpy/delta_arpy
		z_arpratio = delta_edgearpz/delta_arpz
		delta1 = abs(x_arpratio-y_arpratio)
		delta2 = abs(y_arpratio-z_arpratio)
		if 0<=x_arpratio<=1 and delta1<tolerance_edge and delta2<tolerance_edge:
			arpedges_midpoint = myPart.edges[i]
			arpedges_midpoints.append(arpedges_midpoint)
	for m in range(len(x_filaminstarts)):
		delta_fix = x_filaminends[m]-x_filaminstarts[m]
		delta_fiy = y_filaminends[m]-y_filaminstarts[m]
		delta_fiz = z_filaminends[m]-z_filaminstarts[m]
		delta_edgefix = edges_midpoints[i][0][0]-x_filaminstarts[m]
		delta_edgefiy = edges_midpoints[i][0][1]-y_filaminstarts[m]
		delta_edgefiz = edges_midpoints[i][0][2]-z_filaminstarts[m]
		x_firatio = delta_edgefix/delta_fix
		y_firatio = delta_edgefiy/delta_fiy
		z_firatio = delta_edgefiz/delta_fiz
		delta1 = abs(x_firatio-y_firatio)
		delta2 = abs(y_firatio-z_firatio)
		if 0<=x_firatio<=1 and delta1<tolerance_edge and delta2<tolerance_edge:
			fiedges_midpoint = myPart.edges[i]
			fiedges_midpoints.append(fiedges_midpoint)
	for n in range(len(x_actininstarts)):
		delta_aix = x_actininends[n]-x_actininstarts[n]
		delta_aiy = y_actininends[n]-y_actininstarts[n]
		delta_aiz = z_actininends[n]-z_actininstarts[n]
		delta_edgeaix = edges_midpoints[i][0][0]-x_actininstarts[n]
		delta_edgeaiy = edges_midpoints[i][0][1]-y_actininstarts[n]
		delta_edgeaiz = edges_midpoints[i][0][2]-z_actininstarts[n]
		x_airatio = delta_edgeaix/delta_aix
		y_airatio = delta_edgeaiy/delta_aiy
		z_airatio = delta_edgeaiz/delta_aiz
		delta1 = abs(x_airatio-y_airatio)
		delta2 = abs(y_airatio-z_airatio)
		if 0<=x_airatio<=1 and delta1<tolerance_edge and delta2<tolerance_edge:
			aiedges_midpoint = myPart.edges[i]
			aiedges_midpoints.append(aiedges_midpoint)
len(fledges_midpoints) # after division, they all become edges
len(arpedges_midpoints)
len(fiedges_midpoints)
len(aiedges_midpoints)
filament_edgepionts = []
arp_edgepoints = []
filamin_edgepoints = []
actinin_edgepoints = []
for i in range(len(fledges_midpoints)):
	filament_edgepiont = fledges_midpoints[i].pointOn
	filament_edgepionts.append(filament_edgepiont)
for i in range(len(arpedges_midpoints)):
	arp_edgepoint = arpedges_midpoints[i].pointOn
	arp_edgepoints.append(arp_edgepoint)
for i in range(len(fiedges_midpoints)):
	filamin_edgepiont = fiedges_midpoints[i].pointOn
	filamin_edgepoints.append(filamin_edgepiont)
for i in range(len(aiedges_midpoints)):
	actinin_edgepiont = aiedges_midpoints[i].pointOn
	actinin_edgepoints.append(actinin_edgepiont)
edges = myPart.edges.findAt(*filament_edgepionts) 
region = myPart.Set(edges=edges, name='filament_region')
myPart.SectionAssignment(region=region, sectionName='filament_section', offset=0.0, offsetType=MIDDLE_SURFACE, offsetField='', thicknessAssignment=FROM_SECTION)
edges = myPart.edges.findAt(*arp_edgepoints) 
region = myPart.Set(edges=edges, name='arp_region')
myPart.SectionAssignment(region=region, sectionName='arp_section', offset=0.0, offsetType=MIDDLE_SURFACE, offsetField='', thicknessAssignment=FROM_SECTION)
edges = myPart.edges.findAt(*filamin_edgepoints) 
region = myPart.Set(edges=edges, name='filamin_region')
myPart.SectionAssignment(region=region, sectionName='filamin_section', offset=0.0, offsetType=MIDDLE_SURFACE, offsetField='', thicknessAssignment=FROM_SECTION)
edges = myPart.edges.findAt(*actinin_edgepoints) 
region = myPart.Set(edges=edges, name='actinin_region')
myPart.SectionAssignment(region=region, sectionName='actinin_section', offset=0.0, offsetType=MIDDLE_SURFACE, offsetField='', thicknessAssignment=FROM_SECTION)
len(myPart.edges)
len(edges_midpoints)
len(filament_edgepionts)
len(arp_edgepoints)
len(filamin_edgepoints)
len(actinin_edgepoints)
len(xyz_filamentstarts)
len(xyz_arp23starts)
len(xyz_filaminstarts)
len(xyz_actininstarts)
myAssembly = myModel.rootAssembly
myInstance = myAssembly.Instance(name = 'bafnInstance', part = myPart, dependent = ON) # dependent means myPart is associated with myAssembly. to generated mesh on myPart and so myAssembly also has mesh
pickedEdges = myPart.edges.findAt(*filament_edgepionts)
myPart.seedEdgeByNumber(edges=pickedEdges, number=6, constraint=FINER) # two methods to generate seeds on edges: p.seedEdgeByNumber(edges=pickedEdges, number=4, constraint=FINER)/myPart.seedEdgeBySize(edges=pickedEdges, size=10.0, deviationFactor=0.1)
pickedEdges = myPart.edges.findAt(*arp_edgepoints)
myPart.seedEdgeByNumber(edges=pickedEdges, number=2, constraint=FINER)
pickedEdges = myPart.edges.findAt(*filamin_edgepoints)
myPart.seedEdgeByNumber(edges=pickedEdges, number=6, constraint=FINER)
pickedEdges = myPart.edges.findAt(*actinin_edgepoints)
myPart.seedEdgeByNumber(edges=pickedEdges, number=4, constraint=FINER) # another mehtod to seed is on myAssembly: myAssembly.seedPartInstance(regions = (myInstance,), size = 4.0)
myPart.generateMesh() # two methods for generates mesh: myPart.generateMesh() & myAssembly.generateMesh(regions = (myInstance,))
filament_elemType = mesh.ElemType(elemCode=B32, elemLibrary=STANDARD)
edges = myPart.edges.findAt(*filament_edgepionts)
pickedRegions =(edges, )
myPart.setElementType(regions=pickedRegions, elemTypes=(filament_elemType, ))
arp_elemType = mesh.ElemType(elemCode=B32, elemLibrary=STANDARD)
edges = myPart.edges.findAt(*arp_edgepoints)
pickedRegions =(edges, )
myPart.setElementType(regions=pickedRegions, elemTypes=(arp_elemType, ))
filamin_elemType = mesh.ElemType(elemCode=B32, elemLibrary=STANDARD)
edges = myPart.edges.findAt(*filamin_edgepoints)
pickedRegions =(edges, )
myPart.setElementType(regions=pickedRegions, elemTypes=(filamin_elemType, ))
actinin_elemType = mesh.ElemType(elemCode=B32, elemLibrary=STANDARD)
edges = myPart.edges.findAt(*actinin_edgepoints)
pickedRegions =(edges, )
myPart.setElementType(regions=pickedRegions, elemTypes=(actinin_elemType, ))
edges = myPart.edges
region=myPart.Set(edges=edges, name='all_orientation')
myPart.assignBeamSectionOrientation(region=region, method=N1_COSINES, n1=(0.0, 0.0, -1.0))
tolerance_coords_inboundary = 10e-6
x0000_nodesset = [] # the nodes in the left plane(x=0)
x1000_nodesset = [] # the nodes in the right plane(x=1000)
y0000_nodesset = [] # the nodes in the bottom plane(y=0)
y1000_nodesset = [] # the nodes in the top plane(y=1000)
z000_nodesset = []  # the nodes in the back plane(z=0)
z200_nodesset = []  # the nodes in the front plane(z=200)
for i in range(len(myPart.nodes)):
	if abs(myPart.nodes[i].coordinates[0]-0)<=tolerance_coords_inboundary:
		x0000_nodeset = myPart.nodes[i].coordinates
		x0000_nodesset.append(x0000_nodeset)
	if abs(myPart.nodes[i].coordinates[0]-1000)<=tolerance_coords_inboundary:
		x1000_nodeset = myPart.nodes[i].coordinates
		x1000_nodesset.append(x1000_nodeset)
	if abs(myPart.nodes[i].coordinates[1]-0)<=tolerance_coords_inboundary:
		y0000_nodeset = myPart.nodes[i].coordinates
		y0000_nodesset.append(y0000_nodeset)
	if abs(myPart.nodes[i].coordinates[1]-1000)<=tolerance_coords_inboundary:
		y1000_nodeset = myPart.nodes[i].coordinates
		y1000_nodesset.append(y1000_nodeset)
	if abs(myPart.nodes[i].coordinates[2]-0)<=tolerance_coords_inboundary:
		z000_nodeset = myPart.nodes[i].coordinates
		z000_nodesset.append(z000_nodeset)
	if abs(myPart.nodes[i].coordinates[2]-200)<=tolerance_coords_inboundary:
		z200_nodeset = myPart.nodes[i].coordinates
		z200_nodesset.append(z200_nodeset)
len(myPart.nodes)
len(x0000_nodesset)
len(x1000_nodesset)
len(y0000_nodesset)
len(y1000_nodesset)
len(z000_nodesset)
len(z200_nodesset)
tolerance_inboundary = 10e-6
tolerance_zboundary =0.01
x0000_nodeslabel_set = []  # the label of nodes in the left plane(x=0)
x1000_nodeslabel_set = []  # the label of nodes in the right plane(x=1000)
y0000_nodeslabel_set = []  # the label of nodes in the bottom plane(y=0)
y1000_nodeslabel_set = []  # the label of nodes in the top plane(y=1000)
z000_nodeslabel_set = []  # the label of nodes in the back plane(z=0)
z200_nodeslabel_set = []  # the label of nodes in the front plane(z=200)
for i in range(len(myPart.nodes)):
	if abs(myPart.nodes[i].coordinates[0]-0) < tolerance_inboundary:
		x0000_nodeset = myPart.nodes[i].label
		x0000_nodeslabel_set.append(x0000_nodeset)
	if abs(myPart.nodes[i].coordinates[0]-1000) < tolerance_inboundary:
		x1000_nodeset = myPart.nodes[i].label
		x1000_nodeslabel_set.append(x1000_nodeset)
	if abs(myPart.nodes[i].coordinates[1]-0) < tolerance_inboundary:
		y0000_nodeset = myPart.nodes[i].label
		y0000_nodeslabel_set.append(y0000_nodeset)
	if abs(myPart.nodes[i].coordinates[1]-1000) < tolerance_inboundary:
		y1000_nodeset = myPart.nodes[i].label
		y1000_nodeslabel_set.append(y1000_nodeset)
	if abs(myPart.nodes[i].coordinates[2]-0) < tolerance_zboundary:
		z000_nodeset = myPart.nodes[i].label
		z000_nodeslabel_set.append(z000_nodeset)
	if abs(myPart.nodes[i].coordinates[2]-200) < tolerance_zboundary:
		z200_nodeset = myPart.nodes[i].label
		z200_nodeslabel_set.append(z200_nodeset)
len(x0000_nodeslabel_set)
len(x1000_nodeslabel_set)
len(y0000_nodeslabel_set)
len(y1000_nodeslabel_set)
len(z000_nodeslabel_set)
len(z200_nodeslabel_set)
tolerance_withorder = 10e-5
x0000_nodeslabel_setorder = []
x1000_nodeslabel_setorder = []
for i in x0000_nodeslabel_set:
	for j in x1000_nodeslabel_set:
		delta_y = abs(myPart.nodes[i-1].coordinates[1]-myPart.nodes[j-1].coordinates[1]) # the labels of nodes are bigger 1 than the their items
		delta_z = abs(myPart.nodes[i-1].coordinates[2]-myPart.nodes[j-1].coordinates[2]) # the labels of nodes are bigger 1 than the their items
		if delta_y < tolerance_withorder and delta_z < tolerance_withorder:
			x0000_nodelabel_setorder = i
			x1000_nodelabel_setorder = j
			x0000_nodeslabel_setorder.append(x0000_nodelabel_setorder)
			x1000_nodeslabel_setorder.append(x1000_nodelabel_setorder)
			break
len(x0000_nodeslabel_setorder)
len(x1000_nodeslabel_setorder)
y0000_nodeslabel_setorder = []
y1000_nodeslabel_setorder = []
for i in y0000_nodeslabel_set:
	for j in y1000_nodeslabel_set:
		delta_x = abs(myPart.nodes[i-1].coordinates[0]-myPart.nodes[j-1].coordinates[0])
		delta_z = abs(myPart.nodes[i-1].coordinates[2]-myPart.nodes[j-1].coordinates[2])
		if delta_x < tolerance_withorder and delta_z < tolerance_withorder:
			y0000_nodelabel_setorder = i
			y1000_nodelabel_setorder = j
			y0000_nodeslabel_setorder.append(y0000_nodelabel_setorder)
			y1000_nodeslabel_setorder.append(y1000_nodelabel_setorder)
			break
len(y0000_nodeslabel_setorder)
len(y1000_nodeslabel_setorder)
len(y0000_nodeslabel_setorder)
len(y1000_nodeslabel_setorder)
len(x_etlinestarts1_9s)
len(myPart.edges)
len(edges_midpoints)
len(filament_edgepionts)
len(arp_edgepoints)
len(filamin_edgepoints)
len(actinin_edgepoints)
connectivity = len(xyz_filaminstarts) + len(xyz_actininstarts)
volument_ratio = len_filaments_whole*1000*3.1415926*3.5*3.5/(1000*1000*200)
print angles_ydirection
print forces_per_filament
print filaments_length_element1
print len_filaments_whole
print volument_ratio
print connectivity
len(xyz_filamentstarts)
len(xyz_arp23starts)
len(xyz_filaminstarts)
len(xyz_actininstarts)
len(xf_shangchu_y1000)
print protrusion_force_filaments
print protrusion_stress_leading_xzplane
print filaments_totallength_element1
print filaments_averagelength_element1
tolerance_inboundary = 10e-6
p = mdb.models['bafn-1'].parts['filaments'] # to create reference/master nodes, which is out of the model.
p.Node(coordinates=(-1.0, 0.0, 0.0))
p = mdb.models['bafn-1'].parts['filaments']
p.Node(coordinates=(0.0, -1.0, 0.0))
p = mdb.models['bafn-1'].parts['filaments']
p.Node(coordinates=(0.0, 0.0, -1.0))
p = mdb.models['bafn-1'].parts['filaments']
p.Node(coordinates=(1001.0, 0.0, 0.0))
p = mdb.models['bafn-1'].parts['filaments']
p.Node(coordinates=(0.0, 1001.0, 0.0))
p = mdb.models['bafn-1'].parts['filaments']
p.Node(coordinates=(0.0, 0.0, 201.0))
for i in range(len(myPart.nodes)):
	if abs(myPart.nodes[i].coordinates[0]+1) < tolerance_inboundary:
		left_noderef_label = myPart.nodes[i].label
	if abs(myPart.nodes[i].coordinates[0]-1001) < tolerance_inboundary:
		right_noderef_label = myPart.nodes[i].label
	if abs(myPart.nodes[i].coordinates[1]+1) < tolerance_inboundary:
		bottom_noderef_label = myPart.nodes[i].label
	if abs(myPart.nodes[i].coordinates[1]-1001) < tolerance_inboundary:
		up_noderef_label = myPart.nodes[i].label
	if abs(myPart.nodes[i].coordinates[2]+1) < tolerance_zboundary:
		back_noderef_label = myPart.nodes[i].label
	if abs(myPart.nodes[i].coordinates[2]-201) < tolerance_zboundary:
		front_noderef_label = myPart.nodes[i].label
print left_noderef_label
print right_noderef_label
print bottom_noderef_label
print up_noderef_label
print back_noderef_label
print front_noderef_label
mdb.models['bafn-1'].StaticStep(name='Step-1', previous='Initial', initialInc=0.1)
p1 = mdb.models['bafn-1'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p1)
mdb.Model(name='bafn-1-Copy1', objectToCopy=mdb.models['bafn-1'])
p = mdb.models['bafn-1-Copy1'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
p1 = mdb.models['bafn-1'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p1)
mdb.Model(name='bafn-1-Copy2', objectToCopy=mdb.models['bafn-1'])
p = mdb.models['bafn-1-Copy2'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
p1 = mdb.models['bafn-1'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p1)
mdb.Model(name='bafn-1-Copy3', objectToCopy=mdb.models['bafn-1'])
p = mdb.models['bafn-1-Copy3'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
p1 = mdb.models['bafn-1'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p1)
mdb.Model(name='bafn-1-Copy4', objectToCopy=mdb.models['bafn-1'])
p = mdb.models['bafn-1-Copy4'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
p1 = mdb.models['bafn-1'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p1)
mdb.Model(name='bafn-1-Copy5', objectToCopy=mdb.models['bafn-1'])
p = mdb.models['bafn-1-Copy5'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
p1 = mdb.models['bafn-1'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p1)
mdb.Model(name='bafn-1-Copy6', objectToCopy=mdb.models['bafn-1'])
p = mdb.models['bafn-1-Copy6'].parts['filaments']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
################################################################################################
##############################################################################################
m1 = mdb.models['bafn-1-Copy1'] 
a1 = mdb.models['bafn-1-Copy1'].rootAssembly
myInstance = a1.Instance(name = 'bafnInstance', part = myPart, dependent = ON) # dependent means myPart is associated with myAssembly. to generated mesh on myPart and so myAssembly also has mesh
myNodes = myInstance.nodes
len(myInstance.nodes)
len(myNodes)
print myNodes[0:1]
left_noderef = myNodes[left_noderef_label-1:left_noderef_label]
a1.Set(nodes = left_noderef, name = 'set-left_refnode')
right_noderef = myNodes[right_noderef_label-1:right_noderef_label]
a1.Set(nodes = right_noderef, name = 'set-right_refnode')
for i in range(len(x0000_nodeslabel_setorder)):
	left_node = myNodes[x0000_nodeslabel_setorder[i]-1:x0000_nodeslabel_setorder[i]] 
	set_left_node = 'set_left_node' + str(i)
	a1.Set(nodes=left_node, name=set_left_node)
	right_node = myNodes[x1000_nodeslabel_setorder[i]-1:x1000_nodeslabel_setorder[i]]
	set_right_node = 'set_right_node' + str(i)
	a1.Set(nodes=right_node, name=set_right_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'left_right_constraintxeq' + str(i)
	constraint_yeqname = 'left_right_constraintyeq' + str(i)
	constraint_zeqname = 'left_right_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_left_node, 1),(-1.0, 'set-left_refnode', 1),(-1.0, set_right_node, 1),(1.0, 'set-right_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_left_node, 2),(-1.0, 'set-left_refnode', 2),(-1.0, set_right_node, 2),(1.0, 'set-right_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_left_node, 3),(-1.0, 'set-left_refnode', 3),(-1.0, set_right_node, 3),(1.0, 'set-right_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'left_right_constraintxreq' + str(i)
	constraint_yreqname = 'left_right_constraintyreq' + str(i)
	constraint_zreqname = 'left_right_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_left_node, 4),(-1.0, set_right_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_left_node, 5),(-1.0, set_right_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_left_node, 6),(-1.0, set_right_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_left_right_constraintxreq' ######### to add constraint equation for the x-rotation of two related left-right reference nodes
constraint_yreqname = 'ref_left_right_constraintyreq' ######### to add constraint equation for the y-rotation of two related left-right reference nodes
constraint_zreqname = 'ref_left_right_constraintzreq' ######### to add constraint equation for the z-rotation of two related left-right reference nodes
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-left_refnode', 4),(-1.0, 'set-right_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-left_refnode', 5),(-1.0, 'set-right_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-left_refnode', 6),(-1.0, 'set-right_refnode', 6))) # zr-rotational equation		
bottom_noderef = myNodes[bottom_noderef_label-1:bottom_noderef_label]
a1.Set(nodes = bottom_noderef, name = 'set-bottom_refnode')
up_noderef = myNodes[up_noderef_label-1:up_noderef_label]
a1.Set(nodes = up_noderef, name = 'set-up_refnode')
for i in range(len(y0000_nodeslabel_setorder)):
	bottom_node = myNodes[y0000_nodeslabel_setorder[i]-1:y0000_nodeslabel_setorder[i]] 
	set_bottom_node = 'set_bottom_node' + str(i)
	a1.Set(nodes=bottom_node, name=set_bottom_node) 
	up_node = myNodes[y1000_nodeslabel_setorder[i]-1:y1000_nodeslabel_setorder[i]] 
	set_up_node = 'set_up_node' + str(i)
	a1.Set(nodes=up_node, name=set_up_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'bottom_up_constraintxeq' + str(i)
	constraint_yeqname = 'bottom_up_constraintyeq' + str(i)
	constraint_zeqname = 'bottom_up_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_bottom_node, 1),(-1.0, 'set-bottom_refnode', 1),(-1.0, set_up_node, 1),(1.0, 'set-up_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_bottom_node, 2),(-1.0, 'set-bottom_refnode', 2),(-1.0, set_up_node, 2),(1.0, 'set-up_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_bottom_node, 3),(-1.0, 'set-bottom_refnode', 3),(-1.0, set_up_node, 3),(1.0, 'set-up_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'bottom_up_constraintxreq' + str(i)
	constraint_yreqname = 'bottom_up_constraintyreq' + str(i)
	constraint_zreqname = 'bottom_up_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_bottom_node, 4),(-1.0, set_up_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_bottom_node, 5),(-1.0, set_up_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_bottom_node, 6),(-1.0, set_up_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_bottom_up_constraintxreq' ######### to add constraint equation for the x-rotation of two related bottom-up reference nodes
constraint_yreqname = 'ref_bottom_up_constraintyreq' ######### to add constraint equation for the y-rotation of two related bottom-up reference nodes
constraint_zreqname = 'ref_bottom_up_constraintzreq' ######### to add constraint equation for the z-rotation of two related bottom-up reference nodes
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-bottom_refnode', 4),(-1.0, 'set-up_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-bottom_refnode', 5),(-1.0, 'set-up_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-bottom_refnode', 6),(-1.0, 'set-up_refnode', 6))) # zr-rotational equation
back_node_ref = myNodes[back_noderef_label-1:back_noderef_label]
a1.Set(nodes = back_node_ref, name = 'set-back_refnode')
front_node_ref = myNodes[front_noderef_label-1:front_noderef_label]
a1.Set(nodes = front_node_ref, name = 'set-front_refnode')
for i in range(len(z000_nodeslabel_set)):
	back_node = myNodes[z000_nodeslabel_set[i]-1:z000_nodeslabel_set[i]]
	set_back_node = 'set_back_node' + str(i)
	a1.Set(nodes=back_node, name=set_back_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'back_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_back_node, 3),(-1.0, 'set-back_refnode', 3))) # z-displacement equation
for i in range(len(z200_nodeslabel_set)):
	front_node = myNodes[z200_nodeslabel_set[i]-1:z200_nodeslabel_set[i]]
	set_front_node = 'set_front_node' + str(i)
	a1.Set(nodes=front_node, name=set_front_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'front_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_front_node, 3),(-1.0, 'set-front_refnode', 3))) # z-displacement equation
##############################################################################################
##################################################################################################
m1 = mdb.models['bafn-1-Copy2']
a1 = m1.rootAssembly
myInstance = a1.Instance(name = 'bafnInstance', part = myPart, dependent = ON) # dependent means myPart is associated with myAssembly. to generated mesh on myPart and so myAssembly also has mesh
myNodes = myInstance.nodes
len(myInstance.nodes)
len(myNodes)
print myNodes[0:1]
left_noderef = myNodes[left_noderef_label-1:left_noderef_label]
a1.Set(nodes = left_noderef, name = 'set-left_refnode')
right_noderef = myNodes[right_noderef_label-1:right_noderef_label]
a1.Set(nodes = right_noderef, name = 'set-right_refnode')
for i in range(len(x0000_nodeslabel_setorder)):
	left_node = myNodes[x0000_nodeslabel_setorder[i]-1:x0000_nodeslabel_setorder[i]] # have to point out the node use this way:myPart.nodes[i-1:i], can the list 'left_nodes' be used to create nodes set!!!!!
	set_left_node = 'set_left_node' + str(i)
	a1.Set(nodes=left_node, name=set_left_node) # to create the reference node for the left nodes(x=0000)
	right_node = myNodes[x1000_nodeslabel_setorder[i]-1:x1000_nodeslabel_setorder[i]] # have to point out the node use this way:myPart.nodes[i-1:i], can the list 'left_nodes' be used to create nodes set!!!!!
	set_right_node = 'set_right_node' + str(i)
	a1.Set(nodes=right_node, name=set_right_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'left_right_constraintxeq' + str(i)
	constraint_yeqname = 'left_right_constraintyeq' + str(i)
	constraint_zeqname = 'left_right_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_left_node, 1),(-1.0, 'set-left_refnode', 1),(-1.0, set_right_node, 1),(1.0, 'set-right_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_left_node, 2),(-1.0, 'set-left_refnode', 2),(-1.0, set_right_node, 2),(1.0, 'set-right_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_left_node, 3),(-1.0, 'set-left_refnode', 3),(-1.0, set_right_node, 3),(1.0, 'set-right_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'left_right_constraintxreq' + str(i)
	constraint_yreqname = 'left_right_constraintyreq' + str(i)
	constraint_zreqname = 'left_right_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_left_node, 4),(-1.0, set_right_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_left_node, 5),(-1.0, set_right_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_left_node, 6),(-1.0, set_right_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_left_right_constraintxreq'
constraint_yreqname = 'ref_left_right_constraintyreq'
constraint_zreqname = 'ref_left_right_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-left_refnode', 4),(-1.0, 'set-right_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-left_refnode', 5),(-1.0, 'set-right_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-left_refnode', 6),(-1.0, 'set-right_refnode', 6))) # zr-rotational equation			
bottom_noderef = myNodes[bottom_noderef_label-1:bottom_noderef_label]
a1.Set(nodes = bottom_noderef, name = 'set-bottom_refnode')
up_noderef = myNodes[up_noderef_label-1:up_noderef_label]
a1.Set(nodes = up_noderef, name = 'set-up_refnode')
for i in range(len(y0000_nodeslabel_setorder)):
	bottom_node = myNodes[y0000_nodeslabel_setorder[i]-1:y0000_nodeslabel_setorder[i]] 
	set_bottom_node = 'set_bottom_node' + str(i)
	a1.Set(nodes=bottom_node, name=set_bottom_node) # to create the reference node for the left nodes(x=0000)
	up_node = myNodes[y1000_nodeslabel_setorder[i]-1:y1000_nodeslabel_setorder[i]] 
	set_up_node = 'set_up_node' + str(i)
	a1.Set(nodes=up_node, name=set_up_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'bottom_up_constraintxeq' + str(i)
	constraint_yeqname = 'bottom_up_constraintyeq' + str(i)
	constraint_zeqname = 'bottom_up_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_bottom_node, 1),(-1.0, 'set-bottom_refnode', 1),(-1.0, set_up_node, 1),(1.0, 'set-up_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_bottom_node, 2),(-1.0, 'set-bottom_refnode', 2),(-1.0, set_up_node, 2),(1.0, 'set-up_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_bottom_node, 3),(-1.0, 'set-bottom_refnode', 3),(-1.0, set_up_node, 3),(1.0, 'set-up_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'bottom_up_constraintxreq' + str(i)
	constraint_yreqname = 'bottom_up_constraintyreq' + str(i)
	constraint_zreqname = 'bottom_up_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_bottom_node, 4),(-1.0, set_up_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_bottom_node, 5),(-1.0, set_up_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_bottom_node, 6),(-1.0, set_up_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_bottom_up_constraintxreq'
constraint_yreqname = 'ref_bottom_up_constraintyreq'
constraint_zreqname = 'ref_bottom_up_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-bottom_refnode', 4),(-1.0, 'set-up_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-bottom_refnode', 5),(-1.0, 'set-up_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-bottom_refnode', 6),(-1.0, 'set-up_refnode', 6))) # zr-rotational equation
back_node_ref = myNodes[back_noderef_label-1:back_noderef_label]
a1.Set(nodes = back_node_ref, name = 'set-back_refnode')
front_node_ref = myNodes[front_noderef_label-1:front_noderef_label]
a1.Set(nodes = front_node_ref, name = 'set-front_refnode')
for i in range(len(z000_nodeslabel_set)):
	back_node = myNodes[z000_nodeslabel_set[i]-1:z000_nodeslabel_set[i]]
	set_back_node = 'set_back_node' + str(i)
	a1.Set(nodes=back_node, name=set_back_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'back_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_back_node, 3),(-1.0, 'set-back_refnode', 3))) # z-displacement equation
for i in range(len(z200_nodeslabel_set)):
	front_node = myNodes[z200_nodeslabel_set[i]-1:z200_nodeslabel_set[i]]
	set_front_node = 'set_front_node' + str(i)
	a1.Set(nodes=front_node, name=set_front_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'front_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_front_node, 3),(-1.0, 'set-front_refnode', 3))) # z-displacement equation
###########################################################################################
##################################################################################################
m1 = mdb.models['bafn-1-Copy3']
a1 = m1.rootAssembly
myInstance = a1.Instance(name = 'bafnInstance', part = myPart, dependent = ON) # dependent means myPart is associated with myAssembly. to generated mesh on myPart and so myAssembly also has mesh
myNodes = myInstance.nodes
len(myInstance.nodes)
len(myNodes)
print myNodes[0:1]
left_noderef = myNodes[left_noderef_label-1:left_noderef_label]
a1.Set(nodes = left_noderef, name = 'set-left_refnode')
right_noderef = myNodes[right_noderef_label-1:right_noderef_label]
a1.Set(nodes = right_noderef, name = 'set-right_refnode')
for i in range(len(x0000_nodeslabel_setorder)):
	left_node = myNodes[x0000_nodeslabel_setorder[i]-1:x0000_nodeslabel_setorder[i]] 
	set_left_node = 'set_left_node' + str(i)
	a1.Set(nodes=left_node, name=set_left_node) # to create the reference node for the left nodes(x=0000)
	right_node = myNodes[x1000_nodeslabel_setorder[i]-1:x1000_nodeslabel_setorder[i]] 
	set_right_node = 'set_right_node' + str(i)
	a1.Set(nodes=right_node, name=set_right_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'left_right_constraintxeq' + str(i)
	constraint_yeqname = 'left_right_constraintyeq' + str(i)
	constraint_zeqname = 'left_right_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_left_node, 1),(-1.0, 'set-left_refnode', 1),(-1.0, set_right_node, 1),(1.0, 'set-right_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_left_node, 2),(-1.0, 'set-left_refnode', 2),(-1.0, set_right_node, 2),(1.0, 'set-right_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_left_node, 3),(-1.0, 'set-left_refnode', 3),(-1.0, set_right_node, 3),(1.0, 'set-right_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'left_right_constraintxreq' + str(i)
	constraint_yreqname = 'left_right_constraintyreq' + str(i)
	constraint_zreqname = 'left_right_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_left_node, 4),(-1.0, set_right_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_left_node, 5),(-1.0, set_right_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_left_node, 6),(-1.0, set_right_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_left_right_constraintxreq'
constraint_yreqname = 'ref_left_right_constraintyreq'
constraint_zreqname = 'ref_left_right_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-left_refnode', 4),(-1.0, 'set-right_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-left_refnode', 5),(-1.0, 'set-right_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-left_refnode', 6),(-1.0, 'set-right_refnode', 6))) # zr-rotational equation		
bottom_noderef = myNodes[bottom_noderef_label-1:bottom_noderef_label]
a1.Set(nodes = bottom_noderef, name = 'set-bottom_refnode')
up_noderef = myNodes[up_noderef_label-1:up_noderef_label]
a1.Set(nodes = up_noderef, name = 'set-up_refnode')
for i in range(len(y0000_nodeslabel_setorder)):
	bottom_node = myNodes[y0000_nodeslabel_setorder[i]-1:y0000_nodeslabel_setorder[i]] 
	set_bottom_node = 'set_bottom_node' + str(i)
	a1.Set(nodes=bottom_node, name=set_bottom_node) # to create the reference node for the left nodes(x=0000)
	up_node = myNodes[y1000_nodeslabel_setorder[i]-1:y1000_nodeslabel_setorder[i]] 
	set_up_node = 'set_up_node' + str(i)
	a1.Set(nodes=up_node, name=set_up_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'bottom_up_constraintxeq' + str(i)
	constraint_yeqname = 'bottom_up_constraintyeq' + str(i)
	constraint_zeqname = 'bottom_up_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_bottom_node, 1),(-1.0, 'set-bottom_refnode', 1),(-1.0, set_up_node, 1),(1.0, 'set-up_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_bottom_node, 2),(-1.0, 'set-bottom_refnode', 2),(-1.0, set_up_node, 2),(1.0, 'set-up_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_bottom_node, 3),(-1.0, 'set-bottom_refnode', 3),(-1.0, set_up_node, 3),(1.0, 'set-up_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'bottom_up_constraintxreq' + str(i)
	constraint_yreqname = 'bottom_up_constraintyreq' + str(i)
	constraint_zreqname = 'bottom_up_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_bottom_node, 4),(-1.0, set_up_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_bottom_node, 5),(-1.0, set_up_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_bottom_node, 6),(-1.0, set_up_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_bottom_up_constraintxreq'
constraint_yreqname = 'ref_bottom_up_constraintyreq'
constraint_zreqname = 'ref_bottom_up_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-bottom_refnode', 4),(-1.0, 'set-up_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-bottom_refnode', 5),(-1.0, 'set-up_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-bottom_refnode', 6),(-1.0, 'set-up_refnode', 6))) # zr-rotational equation
back_node_ref = myNodes[back_noderef_label-1:back_noderef_label]
a1.Set(nodes = back_node_ref, name = 'set-back_refnode')
front_node_ref = myNodes[front_noderef_label-1:front_noderef_label]
a1.Set(nodes = front_node_ref, name = 'set-front_refnode')
for i in range(len(z000_nodeslabel_set)):
	back_node = myNodes[z000_nodeslabel_set[i]-1:z000_nodeslabel_set[i]]
	set_back_node = 'set_back_node' + str(i)
	a1.Set(nodes=back_node, name=set_back_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'back_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_back_node, 3),(-1.0, 'set-back_refnode', 3))) # z-displacement equation
for i in range(len(z200_nodeslabel_set)):
	front_node = myNodes[z200_nodeslabel_set[i]-1:z200_nodeslabel_set[i]]
	set_front_node = 'set_front_node' + str(i)
	a1.Set(nodes=front_node, name=set_front_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'front_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_front_node, 3),(-1.0, 'set-front_refnode', 3))) # z-displacement equation
###############################################################################################
###################################################################################################		
m1 = mdb.models['bafn-1-Copy4']
a1 = m1.rootAssembly
myInstance = a1.Instance(name = 'bafnInstance', part = myPart, dependent = ON) # dependent means myPart is associated with myAssembly. to generated mesh on myPart and so myAssembly also has mesh
myNodes = myInstance.nodes
len(myInstance.nodes)
len(myNodes)
print myNodes[0:1]
left_noderef = myNodes[left_noderef_label-1:left_noderef_label]
a1.Set(nodes = left_noderef, name = 'set-left_refnode')
right_noderef = myNodes[right_noderef_label-1:right_noderef_label]
a1.Set(nodes = right_noderef, name = 'set-right_refnode')
for i in range(len(x0000_nodeslabel_setorder)):
	left_node = myNodes[x0000_nodeslabel_setorder[i]-1:x0000_nodeslabel_setorder[i]] 
	set_left_node = 'set_left_node' + str(i)
	a1.Set(nodes=left_node, name=set_left_node) # to create the reference node for the left nodes(x=0000)
	right_node = myNodes[x1000_nodeslabel_setorder[i]-1:x1000_nodeslabel_setorder[i]] 
	set_right_node = 'set_right_node' + str(i)
	a1.Set(nodes=right_node, name=set_right_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'left_right_constraintxeq' + str(i)
	constraint_yeqname = 'left_right_constraintyeq' + str(i)
	constraint_zeqname = 'left_right_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_left_node, 1),(-1.0, 'set-left_refnode', 1),(-1.0, set_right_node, 1),(1.0, 'set-right_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_left_node, 2),(-1.0, 'set-left_refnode', 2),(-1.0, set_right_node, 2),(1.0, 'set-right_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_left_node, 3),(-1.0, 'set-left_refnode', 3),(-1.0, set_right_node, 3),(1.0, 'set-right_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'left_right_constraintxreq' + str(i)
	constraint_yreqname = 'left_right_constraintyreq' + str(i)
	constraint_zreqname = 'left_right_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_left_node, 4),(-1.0, set_right_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_left_node, 5),(-1.0, set_right_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_left_node, 6),(-1.0, set_right_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_left_right_constraintxreq'
constraint_yreqname = 'ref_left_right_constraintyreq'
constraint_zreqname = 'ref_left_right_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-left_refnode', 4),(-1.0, 'set-right_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-left_refnode', 5),(-1.0, 'set-right_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-left_refnode', 6),(-1.0, 'set-right_refnode', 6))) # zr-rotational equation		
bottom_noderef = myNodes[bottom_noderef_label-1:bottom_noderef_label]
a1.Set(nodes = bottom_noderef, name = 'set-bottom_refnode')
up_noderef = myNodes[up_noderef_label-1:up_noderef_label]
a1.Set(nodes = up_noderef, name = 'set-up_refnode')
for i in range(len(y0000_nodeslabel_setorder)):
	bottom_node = myNodes[y0000_nodeslabel_setorder[i]-1:y0000_nodeslabel_setorder[i]] #
	set_bottom_node = 'set_bottom_node' + str(i)
	a1.Set(nodes=bottom_node, name=set_bottom_node) # to create the reference node for the left nodes(x=0000)
	up_node = myNodes[y1000_nodeslabel_setorder[i]-1:y1000_nodeslabel_setorder[i]]
	set_up_node = 'set_up_node' + str(i)
	a1.Set(nodes=up_node, name=set_up_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'bottom_up_constraintxeq' + str(i)
	constraint_yeqname = 'bottom_up_constraintyeq' + str(i)
	constraint_zeqname = 'bottom_up_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_bottom_node, 1),(-1.0, 'set-bottom_refnode', 1),(-1.0, set_up_node, 1),(1.0, 'set-up_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_bottom_node, 2),(-1.0, 'set-bottom_refnode', 2),(-1.0, set_up_node, 2),(1.0, 'set-up_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_bottom_node, 3),(-1.0, 'set-bottom_refnode', 3),(-1.0, set_up_node, 3),(1.0, 'set-up_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'bottom_up_constraintxreq' + str(i)
	constraint_yreqname = 'bottom_up_constraintyreq' + str(i)
	constraint_zreqname = 'bottom_up_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_bottom_node, 4),(-1.0, set_up_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_bottom_node, 5),(-1.0, set_up_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_bottom_node, 6),(-1.0, set_up_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_bottom_up_constraintxreq'
constraint_yreqname = 'ref_bottom_up_constraintyreq'
constraint_zreqname = 'ref_bottom_up_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-bottom_refnode', 4),(-1.0, 'set-up_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-bottom_refnode', 5),(-1.0, 'set-up_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-bottom_refnode', 6),(-1.0, 'set-up_refnode', 6))) # zr-rotational equation
back_node_ref = myNodes[back_noderef_label-1:back_noderef_label]
a1.Set(nodes = back_node_ref, name = 'set-back_refnode')
front_node_ref = myNodes[front_noderef_label-1:front_noderef_label]
a1.Set(nodes = front_node_ref, name = 'set-front_refnode')
for i in range(len(z000_nodeslabel_set)):
	back_node = myNodes[z000_nodeslabel_set[i]-1:z000_nodeslabel_set[i]]
	set_back_node = 'set_back_node' + str(i)
	a1.Set(nodes=back_node, name=set_back_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'back_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_back_node, 3),(-1.0, 'set-back_refnode', 3))) # z-displacement equation
for i in range(len(z200_nodeslabel_set)):
	front_node = myNodes[z200_nodeslabel_set[i]-1:z200_nodeslabel_set[i]]
	set_front_node = 'set_front_node' + str(i)
	a1.Set(nodes=front_node, name=set_front_node) # to create the reference node for the left nodes(x=0000)
	constraint_zeqname = 'front_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_front_node, 3),(-1.0, 'set-front_refnode', 3)))
#################################################################################################
##############################################################################################
m1 = mdb.models['bafn-1-Copy5']
a1 = m1.rootAssembly
myInstance = a1.Instance(name = 'bafnInstance', part = myPart, dependent = ON) # dependent means myPart is associated with myAssembly. to generated mesh on myPart and so myAssembly also has mesh
myNodes = myInstance.nodes
len(myInstance.nodes)
len(myNodes)
print myNodes[0:1]
left_noderef = myNodes[left_noderef_label-1:left_noderef_label]
a1.Set(nodes = left_noderef, name = 'set-left_refnode')
right_noderef = myNodes[right_noderef_label-1:right_noderef_label]
a1.Set(nodes = right_noderef, name = 'set-right_refnode')
for i in range(len(x0000_nodeslabel_setorder)):
	left_node = myNodes[x0000_nodeslabel_setorder[i]-1:x0000_nodeslabel_setorder[i]]
	set_left_node = 'set_left_node' + str(i)
	a1.Set(nodes=left_node, name=set_left_node) # to create the reference node for the left nodes(x=0000)
	right_node = myNodes[x1000_nodeslabel_setorder[i]-1:x1000_nodeslabel_setorder[i]] 
	set_right_node = 'set_right_node' + str(i)
	a1.Set(nodes=right_node, name=set_right_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'left_right_constraintxeq' + str(i)
	constraint_yeqname = 'left_right_constraintyeq' + str(i)
	constraint_zeqname = 'left_right_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_left_node, 1),(-1.0, 'set-left_refnode', 1),(-1.0, set_right_node, 1),(1.0, 'set-right_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_left_node, 2),(-1.0, 'set-left_refnode', 2),(-1.0, set_right_node, 2),(1.0, 'set-right_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_left_node, 3),(-1.0, 'set-left_refnode', 3),(-1.0, set_right_node, 3),(1.0, 'set-right_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'left_right_constraintxreq' + str(i)
	constraint_yreqname = 'left_right_constraintyreq' + str(i)
	constraint_zreqname = 'left_right_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_left_node, 4),(-1.0, set_right_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_left_node, 5),(-1.0, set_right_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_left_node, 6),(-1.0, set_right_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_left_right_constraintxreq'
constraint_yreqname = 'ref_left_right_constraintyreq'
constraint_zreqname = 'ref_left_right_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-left_refnode', 4),(-1.0, 'set-right_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-left_refnode', 5),(-1.0, 'set-right_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-left_refnode', 6),(-1.0, 'set-right_refnode', 6))) # zr-rotational equation		
bottom_noderef = myNodes[bottom_noderef_label-1:bottom_noderef_label]
a1.Set(nodes = bottom_noderef, name = 'set-bottom_refnode')
up_noderef = myNodes[up_noderef_label-1:up_noderef_label]
a1.Set(nodes = up_noderef, name = 'set-up_refnode')
for i in range(len(y0000_nodeslabel_setorder)):
	bottom_node = myNodes[y0000_nodeslabel_setorder[i]-1:y0000_nodeslabel_setorder[i]] 
	set_bottom_node = 'set_bottom_node' + str(i)
	a1.Set(nodes=bottom_node, name=set_bottom_node) # to create the reference node for the left nodes(x=0000)
	up_node = myNodes[y1000_nodeslabel_setorder[i]-1:y1000_nodeslabel_setorder[i]]
	set_up_node = 'set_up_node' + str(i)
	a1.Set(nodes=up_node, name=set_up_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'bottom_up_constraintxeq' + str(i)
	constraint_yeqname = 'bottom_up_constraintyeq' + str(i)
	constraint_zeqname = 'bottom_up_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_bottom_node, 1),(-1.0, 'set-bottom_refnode', 1),(-1.0, set_up_node, 1),(1.0, 'set-up_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_bottom_node, 2),(-1.0, 'set-bottom_refnode', 2),(-1.0, set_up_node, 2),(1.0, 'set-up_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_bottom_node, 3),(-1.0, 'set-bottom_refnode', 3),(-1.0, set_up_node, 3),(1.0, 'set-up_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'bottom_up_constraintxreq' + str(i)
	constraint_yreqname = 'bottom_up_constraintyreq' + str(i)
	constraint_zreqname = 'bottom_up_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_bottom_node, 4),(-1.0, set_up_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_bottom_node, 5),(-1.0, set_up_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_bottom_node, 6),(-1.0, set_up_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_bottom_up_constraintxreq'
constraint_yreqname = 'ref_bottom_up_constraintyreq'
constraint_zreqname = 'ref_bottom_up_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-bottom_refnode', 4),(-1.0, 'set-up_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-bottom_refnode', 5),(-1.0, 'set-up_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-bottom_refnode', 6),(-1.0, 'set-up_refnode', 6))) # zr-rotational equation
#################### negelect z-direction constraint equation, only add y-direction constraint equation for applying displacement##############
back_node_ref = myNodes[back_noderef_label-1:back_noderef_label]
a1.Set(nodes = back_node_ref, name = 'set-back_refnode')
front_node_ref = myNodes[front_noderef_label-1:front_noderef_label]
a1.Set(nodes = front_node_ref, name = 'set-front_refnode')
for i in range(len(z000_nodeslabel_set)):
	back_node = myNodes[z000_nodeslabel_set[i]-1:z000_nodeslabel_set[i]]
	set_back_node = 'set_back_node' + str(i)
	a1.Set(nodes=back_node, name=set_back_node) # to create the reference node for the left nodes(x=0000)
	constraint_yeqname = 'back_constraintyeq' + str(i)
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_back_node, 2),(-1.0, 'set-back_refnode', 2))) # y-displacement equation
for i in range(len(z200_nodeslabel_set)):
	front_node = myNodes[z200_nodeslabel_set[i]-1:z200_nodeslabel_set[i]]
	set_front_node = 'set_front_node' + str(i)
	a1.Set(nodes=front_node, name=set_front_node) # to create the reference node for the left nodes(x=0000)
	constraint_yeqname = 'front_constraintyeq' + str(i)
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_front_node, 2),(-1.0, 'set-front_refnode', 2))) # y-displacement equation
###########################################################################################
#################################################################################################
m1 = mdb.models['bafn-1-Copy6']
a1 = m1.rootAssembly
myInstance = a1.Instance(name = 'bafnInstance', part = myPart, dependent = ON) # dependent means myPart is associated with myAssembly. to generated mesh on myPart and so myAssembly also has mesh
myNodes = myInstance.nodes
len(myInstance.nodes)
len(myNodes)
print myNodes[0:1]
left_noderef = myNodes[left_noderef_label-1:left_noderef_label]
a1.Set(nodes = left_noderef, name = 'set-left_refnode')
right_noderef = myNodes[right_noderef_label-1:right_noderef_label]
a1.Set(nodes = right_noderef, name = 'set-right_refnode')
for i in range(len(x0000_nodeslabel_setorder)):
	left_node = myNodes[x0000_nodeslabel_setorder[i]-1:x0000_nodeslabel_setorder[i]] 
	set_left_node = 'set_left_node' + str(i)
	a1.Set(nodes=left_node, name=set_left_node) # to create the reference node for the left nodes(x=0000)
	right_node = myNodes[x1000_nodeslabel_setorder[i]-1:x1000_nodeslabel_setorder[i]] 
	set_right_node = 'set_right_node' + str(i)
	a1.Set(nodes=right_node, name=set_right_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'left_right_constraintxeq' + str(i)
	constraint_yeqname = 'left_right_constraintyeq' + str(i)
	constraint_zeqname = 'left_right_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_left_node, 1),(-1.0, 'set-left_refnode', 1),(-1.0, set_right_node, 1),(1.0, 'set-right_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_left_node, 2),(-1.0, 'set-left_refnode', 2),(-1.0, set_right_node, 2),(1.0, 'set-right_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_left_node, 3),(-1.0, 'set-left_refnode', 3),(-1.0, set_right_node, 3),(1.0, 'set-right_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'left_right_constraintxreq' + str(i)
	constraint_yreqname = 'left_right_constraintyreq' + str(i)
	constraint_zreqname = 'left_right_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_left_node, 4),(-1.0, set_right_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_left_node, 5),(-1.0, set_right_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_left_node, 6),(-1.0, set_right_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_left_right_constraintxreq'
constraint_yreqname = 'ref_left_right_constraintyreq'
constraint_zreqname = 'ref_left_right_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-left_refnode', 4),(-1.0, 'set-right_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-left_refnode', 5),(-1.0, 'set-right_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-left_refnode', 6),(-1.0, 'set-right_refnode', 6))) # zr-rotational equation		
bottom_noderef = myNodes[bottom_noderef_label-1:bottom_noderef_label]
a1.Set(nodes = bottom_noderef, name = 'set-bottom_refnode')
up_noderef = myNodes[up_noderef_label-1:up_noderef_label]
a1.Set(nodes = up_noderef, name = 'set-up_refnode')
for i in range(len(y0000_nodeslabel_setorder)):
	bottom_node = myNodes[y0000_nodeslabel_setorder[i]-1:y0000_nodeslabel_setorder[i]] # have to point out the node use this way:myPart.nodes[i-1:i], can the list 'left_nodes' be used to create nodes set!!!!!
	set_bottom_node = 'set_bottom_node' + str(i)
	a1.Set(nodes=bottom_node, name=set_bottom_node) # to create the reference node for the left nodes(x=0000)
	up_node = myNodes[y1000_nodeslabel_setorder[i]-1:y1000_nodeslabel_setorder[i]] # have to point out the node use this way:myPart.nodes[i-1:i], can the list 'left_nodes' be used to create nodes set!!!!!
	set_up_node = 'set_up_node' + str(i)
	a1.Set(nodes=up_node, name=set_up_node) # to create the reference node for the left nodes(x=0000)
	constraint_xeqname = 'bottom_up_constraintxeq' + str(i)
	constraint_yeqname = 'bottom_up_constraintyeq' + str(i)
	constraint_zeqname = 'bottom_up_constraintzeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_bottom_node, 1),(-1.0, 'set-bottom_refnode', 1),(-1.0, set_up_node, 1),(1.0, 'set-up_refnode', 1))) # x-displacement equation
	m1.Equation(name = constraint_yeqname,terms = ((1.0, set_bottom_node, 2),(-1.0, 'set-bottom_refnode', 2),(-1.0, set_up_node, 2),(1.0, 'set-up_refnode', 2))) # y-displacement equation
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_bottom_node, 3),(-1.0, 'set-bottom_refnode', 3),(-1.0, set_up_node, 3),(1.0, 'set-up_refnode', 3))) # z-displacement equation
	constraint_xreqname = 'bottom_up_constraintxreq' + str(i)
	constraint_yreqname = 'bottom_up_constraintyreq' + str(i)
	constraint_zreqname = 'bottom_up_constraintzreq' + str(i)
	m1.Equation(name = constraint_xreqname,terms = ((1.0, set_bottom_node, 4),(-1.0, set_up_node, 4))) # xr-rotational equation
	m1.Equation(name = constraint_yreqname,terms = ((1.0, set_bottom_node, 5),(-1.0, set_up_node, 5))) # yr-rotational equation
	m1.Equation(name = constraint_zreqname,terms = ((1.0, set_bottom_node, 6),(-1.0, set_up_node, 6))) # zr-rotational equation
constraint_xreqname = 'ref_bottom_up_constraintxreq'
constraint_yreqname = 'ref_bottom_up_constraintyreq'
constraint_zreqname = 'ref_bottom_up_constraintzreq'
m1.Equation(name = constraint_xreqname,terms = ((1.0, 'set-bottom_refnode', 4),(-1.0, 'set-up_refnode', 4))) # xr-rotational equation
m1.Equation(name = constraint_yreqname,terms = ((1.0, 'set-bottom_refnode', 5),(-1.0, 'set-up_refnode', 5))) # yr-rotational equation
m1.Equation(name = constraint_zreqname,terms = ((1.0, 'set-bottom_refnode', 6),(-1.0, 'set-up_refnode', 6))) # zr-rotational equation
##############################
back_node_ref = myNodes[back_noderef_label-1:back_noderef_label]
a1.Set(nodes = back_node_ref, name = 'set-back_refnode')
front_node_ref = myNodes[front_noderef_label-1:front_noderef_label]
a1.Set(nodes = front_node_ref, name = 'set-front_refnode')
for i in range(len(z000_nodeslabel_set)):
	back_node = myNodes[z000_nodeslabel_set[i]-1:z000_nodeslabel_set[i]]
	set_back_node = 'set_back_node' + str(i)
	a1.Set(nodes=back_node, name=set_back_node)
	constraint_xeqname = 'back_constraintxeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_back_node, 1),(-1.0, 'set-back_refnode', 1)))
	"""
	constraint_zeqname = 'back_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_back_node, 3),(-1.0, 'set-back_refnode', 3))) # z-displacement equation
	"""
for i in range(len(z200_nodeslabel_set)):
	front_node = myNodes[z200_nodeslabel_set[i]-1:z200_nodeslabel_set[i]]
	set_front_node = 'set_front_node' + str(i)
	a1.Set(nodes=front_node, name=set_front_node)
	constraint_xeqname = 'front_constraintxeq' + str(i)
	m1.Equation(name = constraint_xeqname,terms = ((1.0, set_front_node, 1),(-1.0, 'set-front_refnode', 1)))
	"""
	constraint_zeqname = 'front_constraintzeq' + str(i)
	m1.Equation(name = constraint_zeqname,terms = ((1.0, set_front_node, 3),(-1.0, 'set-front_refnode', 3))) # z-displacement equation
	"""
###########################################################
##########################################################
a = mdb.models['bafn-1-Copy1'].rootAssembly
region = a.sets['set-left_refnode'] # this is to select the set 'set-bottom_refnode' to establish the region for displacement Boundary Condition
mdb.models['bafn-1-Copy1'].DisplacementBC(name='BC-0-1', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET,
	amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
################## it is hard better to also constraint x,y and z freedom for calculation convergence, even though they seems has little effects on results of E
k = 1.0
a = mdb.models['bafn-1-Copy1'].rootAssembly
region = a.sets['set-right_refnode']
mdb.models['bafn-1-Copy1'].DisplacementBC(name='BC-1', createStepName='Step-1', region=region, u1=k, u2=UNSET, u3=UNSET, ur1=UNSET, ur2=UNSET, ur3=UNSET,
	amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### due to the constraint equations, boundary constraints are unneccessary to set again
mdb.Job(name='bafn-job1-Copy1', model='bafn-1-Copy1', description='', type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
	memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF,
	modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
mdb.jobs['bafn-job1-Copy1'].submit(consistencyChecking=OFF)
a=1
while a==1:
	time.sleep(second);
	a = mdb.models['bafn-1-Copy2'].rootAssembly
	region = a.sets['set-bottom_refnode'] # this is to select the set 'set-bottom_refnode' to establish the region for displacement Boundary Condition
	mdb.models['bafn-1-Copy2'].DisplacementBC(name='BC-0-1', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET, 
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	############## it is hard better to also constraint x,y and z freedom for calculation convergence, even though they seems has little effects on results of E
	k = -1.0
	a = mdb.models['bafn-1-Copy2'].rootAssembly
	region = a.sets['set-up_refnode']
	mdb.models['bafn-1-Copy2'].DisplacementBC(name='BC-1', createStepName='Step-1', region=region, u1=UNSET, u2=k, u3=UNSET, ur1=UNSET, ur2=UNSET, ur3=UNSET, 
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### due to the constraint equations, boundary constraints are unneccessary to set again
	mdb.Job(name='bafn-job1-Copy2', model='bafn-1-Copy2', description='', type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
		memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
		modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
	mdb.jobs['bafn-job1-Copy2'].submit(consistencyChecking=OFF)
	a=2
a=1
while a==1:
	time.sleep(second);
	a = mdb.models['bafn-1-Copy3'].rootAssembly
	region = a.sets['set-back_refnode'] # this is to select the set 'set-bottom_refnode' to establish the region for displacement Boundary Condition
	mdb.models['bafn-1-Copy3'].DisplacementBC(name='BC-0-1', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	############## it is hard better to also constraint x,y and z freedom for calculation convergence, even though they seems has little effects on results of E
	k = -0.2
	a = mdb.models['bafn-1-Copy3'].rootAssembly
	region = a.sets['set-front_refnode']
	mdb.models['bafn-1-Copy3'].DisplacementBC(name='BC-1', createStepName='Step-1', region=region, u1=UNSET, u2=UNSET, u3=k, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### due to the constraint equations, boundary constraints are unneccessary to set again
	mdb.Job(name='bafn-job1-Copy3', model='bafn-1-Copy3', description='', type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
		memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
		modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
	mdb.jobs['bafn-job1-Copy3'].submit(consistencyChecking=OFF)
	a=2
a=1
while a==1: # to calculate G12: for shear calculations of networks(not solid element), all freedom of reference nodes should be setted
	time.sleep(second);
	a = mdb.models['bafn-1-Copy4'].rootAssembly
	region = a.sets['set-left_refnode'] # this is to select the set 'set-bottom_refnode' to establish the region for displacement Boundary Condition
	mdb.models['bafn-1-Copy4'].DisplacementBC(name='BC-0-1', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	a = mdb.models['bafn-1-Copy4'].rootAssembly
	region = a.sets['set-bottom_refnode'] # this is to select the set 'set-bottom_refnode' to establish the region for displacement Boundary Condition
	mdb.models['bafn-1-Copy4'].DisplacementBC(name='BC-0-2', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	k = 1.0
	a = mdb.models['bafn-1-Copy4'].rootAssembly
	region = a.sets['set-right_refnode']
	mdb.models['bafn-1-Copy4'].DisplacementBC(name='BC-1-1', createStepName='Step-1', region=region, u1=SET, u2=k, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET,
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### due to the constraint equations, rotation boundary constraints are unneccessary to set again
	a = mdb.models['bafn-1-Copy4'].rootAssembly
	region = a.sets['set-up_refnode']
	mdb.models['bafn-1-Copy4'].DisplacementBC(name='BC-1-2', createStepName='Step-1', region=region, u1=k, u2=SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET,
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### due to the constraint equations, rotation boundary constraints are unneccessary to set again
	mdb.Job(name='bafn-job1-Copy4', model='bafn-1-Copy4', description='', type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90,
		memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF,
		modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
	mdb.jobs['bafn-job1-Copy4'].submit(consistencyChecking=OFF)
	a=2
a=1
while a==1: # to calculate G23: for shear calculations of networks(not solid element), all freedom of reference nodes should be setted
	time.sleep(second);
	a = mdb.models['bafn-1-Copy5'].rootAssembly
	region = a.sets['set-bottom_refnode']
	mdb.models['bafn-1-Copy5'].DisplacementBC(name='BC-0-1', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	region = a.sets['set-back_refnode']
	mdb.models['bafn-1-Copy5'].DisplacementBC(name='BC-0-2', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	k = 1.0
	region = a.sets['set-up_refnode']
	mdb.models['bafn-1-Copy5'].DisplacementBC(name='BC-1-1', createStepName='Step-1', region=region, u1=SET, u2=SET, u3=1, ur1=UNSET, ur2=UNSET, ur3=UNSET, 
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### due to the constraint equations, rotation boundary constraints are unneccessary to set again
	region = a.sets['set-front_refnode']
	mdb.models['bafn-1-Copy5'].DisplacementBC(name='BC-1-2', createStepName='Step-1', region=region, u1=SET, u2=0.2, u3=SET, ur1=SET, ur2=SET, ur3=SET, 
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### HERE, the rotation boundary of z-200 should be setted, because there are not this constraint equations
	mdb.Job(name='bafn-job1-Copy5', model='bafn-1-Copy5', description='', type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
		memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
		modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
	mdb.jobs['bafn-job1-Copy5'].submit(consistencyChecking=OFF)
	a=2
a=1
while a==1: # to calculate G31: for shear calculations of networks(not solid element), all freedom of reference nodes should be setted
	time.sleep(second);
	a = mdb.models['bafn-1-Copy6'].rootAssembly
	region = a.sets['set-left_refnode']
	mdb.models['bafn-1-Copy6'].DisplacementBC(name='BC-0-1', createStepName='Initial', region=region, u1=SET, u2=SET, u3=SET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	region = a.sets['set-back_refnode']
	mdb.models['bafn-1-Copy6'].DisplacementBC(name='BC-0-2', createStepName='Initial', region=region, u1=SET, u2=SET, u3=UNSET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, distributionType=UNIFORM, fieldName='', localCsys=None)#### for network (not solid element), the rotations have to be constraints!!!!!
	k = 1.0
	region = a.sets['set-right_refnode']
	mdb.models['bafn-1-Copy6'].DisplacementBC(name='BC-1-1', createStepName='Step-1', region=region, u1=SET, u2=SET, u3=1, ur1=UNSET, ur2=UNSET, ur3=UNSET,
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### due to the constraint equations, rotation boundary constraints are unneccessary to set again
	region = a.sets['set-front_refnode']
	mdb.models['bafn-1-Copy6'].DisplacementBC(name='BC-1-2', createStepName='Step-1', region=region, u1=0.2, u2=SET, u3=UNSET, ur1=SET, ur2=SET, ur3=SET,
		amplitude=UNSET, fixed=OFF, distributionType=UNIFORM, fieldName='', localCsys=None)#### HERE, the rotation boundary of z-200 should be setted, because there are not this constraint equations
	mdb.Job(name='bafn-job1-Copy6', model='bafn-1-Copy6', description='', type=ANALYSIS, atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90,
		memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF,
		modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, numGPUs=0)
	mdb.jobs['bafn-job1-Copy6'].submit(consistencyChecking=OFF)
	a=2
a=1
while a==1:
	time.sleep(second);
	#############################################################
	#######################################################
	a = mdb.models['bafn-1-Copy1'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	o3 = session.openOdb(name='D:/temp/bafn-job1-Copy1.odb')
	session.viewports['Viewport: 1'].setValues(displayedObject=o3)
	a = mdb.models['bafn-1-Copy1'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	session.viewports['Viewport: 1'].setValues(displayedObject=session.odbs['D:/temp/bafn-job1-Copy1.odb'])
	session.viewports['Viewport: 1'].assemblyDisplay.setValues(optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
	odb = session.odbs['D:/temp/bafn-job1-Copy1.odb']
	lastFrame=odb.steps['Step-1'].frames[-1]
	rightref_rf1=odb.rootAssembly.nodeSets['SET-RIGHT_REFNODE']
	bottomref_dp2=odb.rootAssembly.nodeSets['SET-BOTTOM_REFNODE']
	upref_dp2=odb.rootAssembly.nodeSets['SET-UP_REFNODE']
	backref_dp3=odb.rootAssembly.nodeSets['SET-BACK_REFNODE']
	frontref_dp3=odb.rootAssembly.nodeSets['SET-FRONT_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	displacement=lastFrame.fieldOutputs['U']
	rightref_rf1_data=reactionforce.getSubset(region=rightref_rf1)
	bottomref_dp2_data=displacement.getSubset(region=bottomref_dp2)
	upref_dp2_data=displacement.getSubset(region=upref_dp2)
	backref_dp3_data=displacement.getSubset(region=backref_dp3)
	frontref_dp3_data=displacement.getSubset(region=frontref_dp3)
	rightref_rf1_value=rightref_rf1_data.values[0].data[0]
	bottomref_dp2_value=bottomref_dp2_data.values[0].data[1]
	upref_dp2_value=upref_dp2_data.values[0].data[1]
	backref_dp3_value=backref_dp3_data.values[0].data[2]
	frontref_dp3_value=frontref_dp3_data.values[0].data[2]
	stress_1=rightref_rf1_value/200000
	strain_2=(upref_dp2_value - bottomref_dp2_value)/1000
	strain_3=(frontref_dp3_value - backref_dp3_value)/200
	e11=stress_1/0.001/1000
	u21=-strain_2/(0.001)
	u31=-strain_3/(0.001)
	########################################################
	##########################################################
	a = mdb.models['bafn-1-Copy2'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	o3 = session.openOdb(name='D:/temp/bafn-job1-Copy2.odb')
	session.viewports['Viewport: 1'].setValues(displayedObject=o3)
	a = mdb.models['bafn-1-Copy2'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	session.viewports['Viewport: 1'].setValues(displayedObject=session.odbs['D:/temp/bafn-job1-Copy2.odb'])
	session.viewports['Viewport: 1'].assemblyDisplay.setValues(optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
	odb = session.odbs['D:/temp/bafn-job1-Copy2.odb']
	lastFrame=odb.steps['Step-1'].frames[-1]
	upref_rf2=odb.rootAssembly.nodeSets['SET-UP_REFNODE']
	leftref_dp1=odb.rootAssembly.nodeSets['SET-LEFT_REFNODE']
	rightref_dp1=odb.rootAssembly.nodeSets['SET-RIGHT_REFNODE']
	backref_dp3=odb.rootAssembly.nodeSets['SET-BACK_REFNODE']
	frontref_dp3=odb.rootAssembly.nodeSets['SET-FRONT_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	displacement=lastFrame.fieldOutputs['U']
	upref_rf2_data=reactionforce.getSubset(region=upref_rf2)
	leftref_dp1_data=displacement.getSubset(region=leftref_dp1)
	rightref_dp1_data=displacement.getSubset(region=rightref_dp1)
	backref_dp3_data=displacement.getSubset(region=backref_dp3)
	frontref_dp3_data=displacement.getSubset(region=frontref_dp3)
	upref_rf2_value=upref_rf2_data.values[0].data[1]
	leftref_dp1_value=leftref_dp1_data.values[0].data[0]
	rightref_dp1_value=rightref_dp1_data.values[0].data[0]
	backref_dp3_value=backref_dp3_data.values[0].data[2]
	frontref_dp3_value=frontref_dp3_data.values[0].data[2]
	stress_2=upref_rf2_value/200000
	strain_1=(rightref_dp1_value - leftref_dp1_value)/1000
	strain_3=(frontref_dp3_value - backref_dp3_value)/200
	e22=-stress_2/0.001/1000
	u12=-strain_1/(-0.001)
	u32=-strain_3/(-0.001)
	###########################################################
	#########################################################
	a = mdb.models['bafn-1-Copy3'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	o3 = session.openOdb(name='D:/temp/bafn-job1-Copy3.odb')
	session.viewports['Viewport: 1'].setValues(displayedObject=o3)
	a = mdb.models['bafn-1-Copy3'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	session.viewports['Viewport: 1'].setValues(displayedObject=session.odbs['D:/temp/bafn-job1-Copy3.odb'])
	session.viewports['Viewport: 1'].assemblyDisplay.setValues(optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
	odb = session.odbs['D:/temp/bafn-job1-Copy3.odb']
	lastFrame=odb.steps['Step-1'].frames[-1]
	frontref_rf3=odb.rootAssembly.nodeSets['SET-FRONT_REFNODE']
	leftref_dp1=odb.rootAssembly.nodeSets['SET-LEFT_REFNODE']
	rightref_dp1=odb.rootAssembly.nodeSets['SET-RIGHT_REFNODE']
	bottomref_dp2=odb.rootAssembly.nodeSets['SET-BOTTOM_REFNODE']
	upref_dp2=odb.rootAssembly.nodeSets['SET-UP_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	displacement=lastFrame.fieldOutputs['U']
	frontref_rf3_data=reactionforce.getSubset(region=frontref_rf3)
	leftref_dp1_data=displacement.getSubset(region=leftref_dp1)
	rightref_dp1_data=displacement.getSubset(region=rightref_dp1)
	bottomref_dp2_data=displacement.getSubset(region=bottomref_dp2)
	upref_dp2_data=displacement.getSubset(region=upref_dp2)
	frontref_rf3_value=frontref_rf3_data.values[0].data[2]
	leftref_dp1_value=leftref_dp1_data.values[0].data[0]
	rightref_dp1_value=rightref_dp1_data.values[0].data[0]
	bottomref_dp2_value=bottomref_dp2_data.values[0].data[1]
	upref_dp2_value=upref_dp2_data.values[0].data[1]
	stress_3=frontref_rf3_value/1000000
	strain_1=(rightref_dp1_value - leftref_dp1_value)/1000
	strain_2=(upref_dp2_value - bottomref_dp2_value)/1000
	e33=-stress_3/0.001/1000
	u13=-strain_1/(-0.001)
	u23=-strain_2/(-0.001)
	############################################################################
	#############################################################################
	a = mdb.models['bafn-1-Copy4'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	o3 = session.openOdb(name='D:/temp/bafn-job1-Copy4.odb')
	session.viewports['Viewport: 1'].setValues(displayedObject=o3)
	a = mdb.models['bafn-1-Copy4'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	session.viewports['Viewport: 1'].setValues(displayedObject=session.odbs['D:/temp/bafn-job1-Copy4.odb'])
	session.viewports['Viewport: 1'].assemblyDisplay.setValues(optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
	odb = session.odbs['D:/temp/bafn-job1-Copy4.odb']
	lastFrame=odb.steps['Step-1'].frames[-1]
	rightref_rf2=odb.rootAssembly.nodeSets['SET-RIGHT_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	rightref_rf2_data=reactionforce.getSubset(region=rightref_rf2)
	rightref_rf2_value=rightref_rf2_data.values[0].data[1]
	stress_2=rightref_rf2_value/200000
	g12_1=stress_2/(0.001+0.001)/1000 
	upref_rf1=odb.rootAssembly.nodeSets['SET-UP_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	upref_rf1_data=reactionforce.getSubset(region=upref_rf1)
	upref_rf1_value=upref_rf1_data.values[0].data[0]
	stress_1=upref_rf1_value/200000
	g12_2=stress_1/(0.001+0.001)/1000 ######
	##############################################################################
	###########################################################################
	a = mdb.models['bafn-1-Copy5'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	o3 = session.openOdb(name='D:/temp/bafn-job1-Copy5.odb')
	session.viewports['Viewport: 1'].setValues(displayedObject=o3)
	a = mdb.models['bafn-1-Copy5'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	session.viewports['Viewport: 1'].setValues(displayedObject=session.odbs['D:/temp/bafn-job1-Copy5.odb'])
	session.viewports['Viewport: 1'].assemblyDisplay.setValues(optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
	odb = session.odbs['D:/temp/bafn-job1-Copy5.odb']
	lastFrame=odb.steps['Step-1'].frames[-1]
	upref_rf3=odb.rootAssembly.nodeSets['SET-UP_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	upref_rf3_data=reactionforce.getSubset(region=upref_rf3)
	upref_rf3_value=upref_rf3_data.values[0].data[2]
	stress_3=upref_rf3_value/200000
	g23_1=stress_3/(0.001+0.001)/1000 
	frontref_rf2=odb.rootAssembly.nodeSets['SET-FRONT_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	frontref_rf2_data=reactionforce.getSubset(region=frontref_rf2)
	frontref_rf2_value=frontref_rf2_data.values[0].data[1]
	stress_2=frontref_rf2_value/1000000
	g23_2=stress_2/(0.001+0.001)/1000 
	######################################################################
	#########################################################################
	a = mdb.models['bafn-1-Copy6'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	o3 = session.openOdb(name='D:/temp/bafn-job1-Copy6.odb')
	session.viewports['Viewport: 1'].setValues(displayedObject=o3)
	a = mdb.models['bafn-1-Copy6'].rootAssembly
	session.viewports['Viewport: 1'].setValues(displayedObject=a)
	session.viewports['Viewport: 1'].setValues(displayedObject=session.odbs['D:/temp/bafn-job1-Copy6.odb'])
	session.viewports['Viewport: 1'].assemblyDisplay.setValues(optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
	odb = session.odbs['D:/temp/bafn-job1-Copy6.odb']
	lastFrame=odb.steps['Step-1'].frames[-1]
	frontref_rf1=odb.rootAssembly.nodeSets['SET-FRONT_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	frontref_rf1_data=reactionforce.getSubset(region=frontref_rf1)
	frontref_rf1_value=frontref_rf1_data.values[0].data[0]
	stress_1=frontref_rf1_value/1000000
	g31_1=stress_1/(0.001+0.001)/1000
	rightref_rf3=odb.rootAssembly.nodeSets['SET-RIGHT_REFNODE']
	reactionforce=lastFrame.fieldOutputs['RF']
	rightref_rf3_data=reactionforce.getSubset(region=rightref_rf3)
	rightref_rf3_value=rightref_rf3_data.values[0].data[2]
	stress_3=rightref_rf3_value/200000
	g31_2=stress_3/(0.001+0.001)/1000 
	a=2
u21_e11=u21/e11
u12_e22=u12/e22
u31_e11=u31/e11
u13_e33=u13/e33
u32_e22=u32/e22
u23_e33=u23/e33

print len_filaments_whole
print volument_ratio
print connectivity
len(xyz_filamentstarts)
len(xyz_arp23starts)
print models_num
len(xyz_filaminstarts)
len(xyz_actininstarts)
len(xf_shangchu_y1000)
print protrusion_force_filaments
print protrusion_stress_leading_xzplane
print filaments_totallength_element1
print filaments_averagelength_element1
len(angles_ydirection)
print filaments_length_element1
print filaments_yorientation_element1
mdb.saveAs(pathName=savepath)




